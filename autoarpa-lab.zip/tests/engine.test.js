/* Pruebas del motor (node tests/engine.test.js). Sin dependencias. */
'use strict';
const path = require('path');
['theory', 'i18n', 'felts', 'instrument', 'engine', 'optimizer', 'arranger', 'player', 'practice'].forEach(f => require(path.join(__dirname, '..', 'src', f + '.js')));
const { theory: T, instrument: I, engine: E, optimizer: O } = globalThis.AH;
let fails = 0, n = 0;
function ok(cond, msg) { n++; if (!cond) { fails++; console.error('FALLA:', msg); } else console.log('ok -', msg); }

const L = I.buildLayout(I.LAYOUT_DEFS[0]);
ok(L.tuning.length === 36, 'afinación de 36 cuerdas');
ok(L.tuning[0].name === 'F2' && L.tuning[35].name === 'C6', 'rango F2–C6');
ok(L.tuning.every((s, i) => i === 0 || s.midi > L.tuning[i - 1].midi), 'afinación ascendente');
ok(L.rows.flat().length === 21, 'OS21 tiene 21 barras');

const bar = l => L.rows.flat().find(b => b.label === l);
const strings = m => { const o = []; m.forEach((v, i) => { if (v) o.push(i); }); return o; };
const pcsOf = s => Array.from(new Set(s.map(i => L.tuning[i].pc))).sort((a, b) => a - b);

// Intersección: C ∩ Am = {C, E}
const inter = pcsOf(strings(E.andMasks([bar('C'), bar('Am')], 36)));
ok(JSON.stringify(inter) === JSON.stringify([0, 4]), 'C ∩ Am deja C y E');

// Cada barra generada identifica su propio acorde al 100 %
for (const b of L.rows.flat()) {
  const id = E.identify(strings(b.mask), L.tuning, 1)[0];
  ok(id.chord.name === T.parseChord(b.label).name && id.sc.S === 1, `barra ${b.label} se identifica como ${b.label} 100%`);
}

// Fieltros reales (Race 15): todos dan su acorde exacto
const R = I.buildLayout(I.LAYOUT_DEFS.find(d => d.id === 'race15'));
for (const b of R.rows.flat()) {
  const s = strings(b.mask);
  const sc = E.score(E.features(s, R.tuning), T.parseChord(b.label));
  ok(sc.exact, `fieltro real ${b.label} contiene exactamente sus notas`);
}

// La regla de bajo reproduce al menos 19 de 20 fieltros reales
let same = 0; const keys = Object.keys(AH.FELTS);
keys.forEach(k => { const g = I.barFromChord(k.split(':')[1], L.tuning); if (strings(g.mask).map(i => i + 1).join() === AH.FELTS[k].join()) same++; });
ok(same >= 19, `regla de bajo reproduce ${same}/${keys.length} fieltros reales`);

// Búsqueda
const cache = E.buildCache(L);
const best = (c, o) => E.search(T.parseChord(c), cache, Object.assign({ top: 1 }, o))[0];
ok(best('G').sc.S === 1 && best('G').bars.length === 1, 'G existente: 1 barra, 100%');
ok(best('F#m').bars.map(b => b.label).sort().join('+') === 'B7+D', 'F#m sin pinch: B7 ∩ D (F#, A)');
ok(best('Am7', { pinches: true }).pinches.length >= 1, 'Am7 con pinch agrega una cuerda');
ok(best('Am7', { pinches: true }).sc.S < 1, 'pinch nunca puntúa 100% (arpegiado)');
ok(!best('C#', {}) || best('C#').sc.S < 0.7, 'C# no alcanzable en OS21 sin re-fieltrar');

// Puntaje: notas ajenas bajan, faltantes bajan
const f = s => E.features(s, L.tuning);
const cMaj = T.parseChord('C');
const sC = strings(bar('C').mask), sC7 = strings(bar('C7').mask);
ok(E.score(f(sC7), cMaj).S < 1 && E.score(f(sC7), cMaj).S > 0.7, 'C7 como sustituto de C: entre 70 y 100');
ok(E.score(f(sC), T.parseChord('Cm')).S < E.score(f(sC), cMaj).S, 'C se parece más a C que a Cm');

// Parser
['F#m7', 'Bbmaj7', 'Ebdim7', 'G/B', 'Dm7b5', 'Caug', 'Asus4'].forEach(x => ok(!!T.parseChord(x), 'parsea ' + x));
ok(T.parseChord('Xq7') === null && T.parseChord('Czz') === null, 'rechaza acorde inválido');

// Serialización ida y vuelta
const L2 = I.deserializeLayout(JSON.parse(JSON.stringify(I.serializeLayout(L))));
ok(L2.rows.flat().every((b, i) => b.mask.join() === L.rows.flat()[i].mask.join()), 'serializar/deserializar conserva fieltros');

// Optimizador: repertorio en La mejora
const rep = O.parseRepertoire('A:4 E:3 F#m:2 Bm:1 C#m:1').items;
const r = O.optimize(L, rep, { steps: 2 });
ok(r.after.value > r.before.value, `optimizador mejora cobertura ${r.before.value.toFixed(2)} → ${r.after.value.toFixed(2)}`);
ok(r.changes.every(c => c.from !== 'B7'), 'optimizador respeta barra bloqueada B7');

// Cobertura completa
const grid = E.coverage(cache);
ok(grid.length === T.TYPES.length && grid[0].cells.length === 12, 'mapa de cobertura 16×12');

// Reacomodo de botones
const A = globalThis.AH.arranger;
const prog = 'G C D Em G C D G\nC Am F G C Am F G\nG Em C D7 G';
const ar = A.arrange(L, { progressions: prog, withinRows: true, locked: new Set(['B7']) });
ok(ar.after.travelAvg <= ar.before.travelAvg + 1e-9, `reacomodo no empeora el recorrido ${ar.before.travelAvg.toFixed(2)} → ${ar.after.travelAvg.toFixed(2)}`);
ok(ar.layout.rows.every((r, i) => r.length === L.rows[i].length), 'reacomodo conserva la forma de la botonera');
ok(ar.layout.rows.flat().map(b => b.label).sort().join() === L.rows.flat().map(b => b.label).sort().join(), 'reacomodo no pierde ni duplica barras');
ok(ar.layout.rows.every((r, i) => r.every(b => L.rows[i].some(x => x.label === b.label))), 'modo "dentro de filas" no cambia barras de fila');
ok(ar.moves.every(m => m.label !== 'B7'), 'reacomodo respeta barra fija B7');
const shuffled = I.buildLayout({ id: 'x', name: 'x', rows: [['G', 'Eb', 'A', 'C', 'Bb', 'D', 'F']] });
const ar2 = A.arrange(shuffled, {});
ok(ar2.layout.rows[0].map(b => b.label).join(' ') === 'Eb Bb F C G D A', 'sin repertorio ordena por quintas: ' + ar2.layout.rows[0].map(b => b.label).join(' '));

// ---- Animación de ejemplo v2 (pasos, línea de tiempo, reproductor) ----
{
  const cache = E.buildCache(L);
  const res = E.search(T.parseChord('Bm'), cache, { top: 12, pinches: true, maxButtons: 3 });
  const withPin = res.find(r => r.pinches.length && r.bars.length === 2), noPin = res.find(r => !r.pinches.length);
  [withPin, noPin].filter(Boolean).forEach((r, k) => {
    const plan = AH.player.build(L, r, { label: 'Bm', pct: r.sc.S, className: 'x' });
    const ev = plan.events, tag = k ? 'sin pinch' : 'con pinch';
    ok(ev.every((e, i) => i === 0 || e.t >= ev[i - 1].t), 'guion ordenado en el tiempo (' + tag + ')');
    ok(plan.steps.length === (r.pinches.length ? 4 : 2), 'pasos: presionar, rasguear' + (r.pinches.length ? ', soltar, pulsar' : '') + ' (' + tag + ')');
    ok(plan.steps.every((s, i) => s.t1 > s.t0 && (i === 0 || s.t0 === plan.steps[i - 1].t1)), 'pasos contiguos y con duración (' + tag + ')');
    ok(plan.steps.every(s => s.text.length > 20 && s.hand.length > 3), 'cada paso dice qué mano y qué hacer (' + tag + ')');
    const flat = L.rows.flat();
    ok(plan.lanes.bars.length === r.bars.length && plan.lanes.bars.every(l => r.bars.includes(flat[l.idx])), 'una fila de línea de tiempo por barra (' + tag + ')');
    const strum = ev.filter(e => e.type === 'pluck' && e.kind === 'strum').map(e => e.s);
    const m = E.andMasks(r.bars, 36);
    ok(strum.length > 0 && strum.every(s => m[s] && s >= r.range[0] && s <= r.range[1]), 'rasgueo solo en cuerdas libres de la zona (' + tag + ')');
    ok(strum.every((s, i) => i === 0 || s > strum[i - 1]), 'rasgueo de grave a agudo (' + tag + ')');
    const pins = ev.filter(e => e.type === 'pluck' && e.kind === 'pinch').map(e => e.s);
    ok(JSON.stringify(pins) === JSON.stringify(r.pinches), 'pinch pulsa las cuerdas de la receta (' + tag + ')');
    if (pins.length) {
      const relT = plan.lanes.bars[0].t1, firstPin = ev.find(e => e.kind === 'pinch');
      ok(relT > ev.filter(e => e.kind === 'strum').pop().t && firstPin.t > relT, 'las barras se sueltan después del rasgueo y antes del pinch');
    }
    ok(plan.result.indexOf('Bm') >= 0 || plan.result.indexOf('Sim') >= 0 || plan.result.length > 5, 'texto de resultado (' + tag + ')');
    // reproductor: modo paso a paso se detiene al final de cada paso y no pierde sonidos
    const heard = []; let pressed = [];
    const run = new AH.player.Runner(plan, { press: b => { pressed = b; }, pluck: s => heard.push(s) }, { stepMode: true });
    let pauses = 0;
    for (let i = 0; i < 2000 && !run.done(); i++) { run.tick(16); if (!run.playing && !run.done()) { pauses++; ok(run.t === plan.steps[run.step()].t1 - 1, 'pausa justo al final del paso ' + (run.step() + 1) + ' (' + tag + ')'); run.toggle(); } }
    ok(pauses === plan.steps.length - 1, 'una pausa por paso intermedio (' + tag + ')');
    ok(JSON.stringify(heard) === JSON.stringify(ev.filter(e => e.type === 'pluck').map(e => e.s)), 'todos los sonidos se reproducen en orden (' + tag + ')');
    run.seek(plan.steps[1].t0 + 10);
    ok(JSON.stringify(pressed) === JSON.stringify(plan.lanes.bars.map(l => l.idx)), 'saltar a un paso aplica las barras de ese momento (' + tag + ')');
    run.goStep(0); ok(run.step() === 0 && run.playing, 'ir al paso 1 (' + tag + ')');
  });
}
// ---- Idiomas y notación ----
{
  const L10 = AH.i18n;
  const missing = Object.keys(L10.K).filter(k => L10.K[k].length !== 5 || L10.K[k].some(x => typeof x !== 'string' || !x.length));
  ok(!missing.length, 'todas las claves tienen los 5 idiomas' + (missing.length ? ': ' + missing.join(', ') : ''));
  ok(L10.NATIVE_KEYS.every(k => L10.K[k]), 'textos nativos de Android existen');
  const keysUsed = require('fs').readFileSync(require('path').join(__dirname, '..', 'src', 'ui.js'), 'utf8').match(/\bt\('([\w.]+)'/g).map(x => x.slice(3, -1));
  const html = require('fs').readFileSync(require('path').join(__dirname, '..', 'index.html'), 'utf8').match(/data-i18n(?:-title)?="([\w.]+)"/g).map(x => x.split('"')[1]);
  const unknown = Array.from(new Set(keysUsed.concat(html))).filter(k => !k.endsWith('.') && !L10.K[k]);
  ok(!unknown.length, 'la interfaz no usa claves inexistentes' + (unknown.length ? ': ' + unknown.join(', ') : ''));
  L10.setLang('es'); ok(L10.chord('Bb7') === 'Sib7' && L10.note('F#3') === 'Fa#3', 'solfeo en español');
  ok(T.parseChord('Sol7').name === 'G7' && T.parseChord('Lab').name === 'Ab' && T.parseChord('Do7').name === 'C7', 'acepta solfeo al escribir');
  L10.setLang('de'); ok(L10.chord('B7') === 'H7' && L10.chord('Bb') === 'B' && T.parseChord('H7').name === 'B7' && T.parseChord('Fis').name === 'F#', 'notación alemana');
  L10.setLang('en'); ok(L10.chord('Bb7') === 'Bb7' && T.parseChord('Am7').name === 'Am7', 'letras en inglés');
  L10.setNotation('solfege'); ok(L10.chord('C') === 'Do', 'notación elegida a mano'); L10.setNotation('auto'); L10.setLang('es');
}
// ---- Tu turno y Modo canción ----
{
  const cache = E.buildCache(L);
  const r = E.search(T.parseChord('Bm'), cache, { top: 12, pinches: true, maxButtons: 3 }).find(x => x.pinches.length && x.bars.length === 2);
  const tg = AH.practice.target(L, r, 'Bm');
  let log = [{ t: 0, type: 'press', bars: tg.barIdx }];
  tg.strum.forEach((s, k) => log.push({ t: 100 + k * 30, type: 'pluck', s, sounded: true }));
  log.push({ t: 800, type: 'press', bars: [] }); tg.pinches.forEach((s, k) => log.push({ t: 1200 + k * 400, type: 'pluck', s, sounded: true }));
  const good = AH.practice.evaluate(L, tg, log);
  ok(good.verdict === 'good' && good.items.every(i => i.ok), 'Tu turno: ejecución correcta se aprueba');
  log = [{ t: 0, type: 'press', bars: [tg.barIdx[0]] }]; for (let s = 0; s < 36; s++) log.push({ t: 100 + s * 10, type: 'pluck', s, sounded: !!L.rows.flat()[tg.barIdx[0]].mask[s] });
  const bad = AH.practice.evaluate(L, tg, log);
  ok(bad.verdict !== 'good' && bad.items.some(i => !i.ok), 'Tu turno: barra faltante y zona equivocada se señalan');
  ok(AH.practice.evaluate(L, tg, []).verdict === 'none', 'Tu turno: sin sonido no evalúa');
  const song = AH.practice.resolveSong('G C D7 Em Xyz Sol:2', L, cache);
  ok(song.bad.length === 1 && song.items.length === 6 && song.items.every(i => i.playable && i.barIdx.length), 'Modo canción: acordes, repeticiones y forma de tocar');
}

console.log(`\n${n - fails}/${n} pruebas correctas`);
process.exit(fails ? 1 : 0);
