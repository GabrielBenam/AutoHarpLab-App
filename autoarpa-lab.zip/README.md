# Autoarpa Lab

Autoarpa digital de 36 cuerdas con motor para obtener acordes que no existen en los layouts clásicos de 12, 15 y 21 barras. El motor combina intersección de barras, zona de rasgueo y pinch. Incluye buscador con porcentaje de parecido, mapa de cobertura, optimizador de re-fieltrado y editor de barras cuerda por cuerda.

- Lógica y correcciones: `docs/LOGICA.md`
- Fuentes: `docs/BIBLIOGRAFIA.md` y `docs/referencias/`
- Pruebas del motor: `node tests/engine.test.js`

## Novedades de la versión 0.4

- **Idiomas:** español, inglés, portugués, francés y alemán, con notación de acordes en letras (C D E), solfeo (Do Re Mi) o alemana (… A H). Por defecto sigue el idioma, y se cambia en **Ajustes**. Al escribir acordes se aceptan las tres notaciones.
- **Animación paso a paso:** el botón **Ver animación** de cada forma de tocar abre una franja superior.
  - Muestra Anterior, Play/Pausa (un solo botón), Siguiente y la velocidad.
  - El texto de cada paso queda fijo y dice qué mano hace qué.
  - El modo **Paso a paso** se detiene al final de cada paso.
  - La barra de pasos y la **línea de tiempo** muestran cuándo se presiona y se suelta cada barra, qué hace la otra mano y qué suena. Al tocar la línea se salta a ese momento.
- **Tu turno:** te pide tocar la forma elegida. Después revisa barras, zona de rasgueo y pinch, y dice qué tanto se parece a lo pedido.
- **Modo canción:** escribes la progresión y la app marca la barra actual y la siguiente. Avanza sola cuando rasgueas con las barras correctas. También puede reacomodar los botones para esa canción.
- **Optimizador con imágenes de fieltrado:** cada barra a cambiar muestra su fieltro antes y después, con las muescas que hay que cortar y las cuerdas que hay que cubrir. Las imágenes se descargan en PNG, y hay una hoja de fieltrado completa.
- **Estilos de cuerdas:**
  - **Clásica:** Do rojo y Fa azul como guía, con leyenda.
  - **Sobria:** todas iguales.
  - **Alto contraste.**
- **Recorrido guiado:** aparece la primera vez y se repite desde Ajustes.
- **Ícono propio.**

## Estructura

```
index.html, styles.css      interfaz (funciona abriendo index.html con doble clic)
src/theory.js               notas y diccionario de 16 tipos de acorde con funciones armónicas
src/felts.js                fieltros reales documentados (hojas Harpers Guild / P. D. Race)
src/instrument.js           afinación, barras (máscaras por cuerda), regla de bajo, layouts
src/engine.js               métrica de parecido, búsqueda, identificación, cobertura
src/optimizer.js            optimizador de re-fieltrado por repertorio
src/arranger.js             reacomodo de botones (recorrido de mano + patrón armónico)
src/audio.js                síntesis Karplus-Strong y apagado por fieltro
src/i18n.js                 idiomas y notación (letras, solfeo, alemana)
src/help.js                 Ayuda en los cinco idiomas
src/player.js               guion de la animación: pasos, línea de tiempo y reproductor
src/practice.js             evaluación de Tu turno y preparación del Modo canción
src/icon.svg, build/icon.png ícono
src/ui.js                   interfaz
electron/main.js            envoltorio de escritorio para Windows
.github/workflows/build.yml compilación en GitHub Actions
```

## Compilar en GitHub (sin instalar nada en tu equipo)

Para subir el código:

1. En github.com, presiona **New** (repositorio nuevo), ponle de nombre `autoarpa-lab` y presiona **Create repository**.
2. En la página del repositorio, entra a **uploading an existing file**, arrastra **todo el contenido** de la carpeta descomprimida (no la carpeta misma) y presiona **Commit changes**.
3. Si la carpeta `.github` no se subió (Windows a veces la oculta), entra a **Add file → Create new file**, escribe como nombre `.github/workflows/build.yml`, pega el contenido del workflow y presiona **Commit changes**.

Para publicar la versión web:

4. Entra a **Settings → Pages**, y en **Source** elige **GitHub Actions**.

Para obtener el programa:

5. En la pestaña **Actions** verás la ejecución "Compilar Autoarpa Lab". Al terminar con la marca verde, entra a ella. En **Artifacts**, descarga **AutoarpaLab-Windows**: trae el instalador y la versión portable (.exe).
6. La versión web queda en `https://<tu-usuario>.github.io/autoarpa-lab/`.

Opcional, para crear una release con los .exe adjuntos: entra a **Releases → Draft a new release**, crea la etiqueta `v0.1.0` y publica.

Windows SmartScreen mostrará "Windows protegió su PC" porque el .exe no está firmado. Presiona **Más información → Ejecutar de todas formas**.
