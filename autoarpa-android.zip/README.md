# Autoarpa Android (v0.3)

Pantalla Tocar nativa (audio C++ con Oboe y multitáctil por roles). Funciona en horizontal y vertical, y en teléfono o tableta. El laboratorio completo va dentro de un WebView.

- **Arriba:** Menú y Tabla de acordes. Cuando hay un ejemplo, una práctica o una canción activa, aparece la franja de control y esos botones bajan.
- **Ejemplo animado:**
  - Anterior, Play/Pausa, Siguiente, velocidad y modo paso a paso.
  - Barra de pasos.
  - Línea de tiempo nativa, con un botón para desplegarla en horizontal; en vertical siempre está visible.
- **Tu turno:** la app registra lo que tocas y el laboratorio lo evalúa.
- **Canción:** marca la barra actual y la siguiente, y avanza sola.
- **Recorrido guiado:** aparece la primera vez.
- **Márgenes del sistema:** se reservan los de la barra de navegación, los gestos y la cámara.
- **Ícono adaptable** propio.

Archivos:

- `app/src/main/cpp`: audio.
- `app/src/main/java/lab/autoarpa`: Kotlin (HarpView, Example, StepBarView, Str, MainActivity).
- `app/src/main/assets/web`: copia del laboratorio web.
- `app/src/main/res`: ícono.
- `tests/synth_test.cpp`: prueba del audio.

`tools/sync_web.js` y `tools/export_layout.js` regeneran las copias desde la carpeta `autoharp-lab`; no hacen falta para compilar.
