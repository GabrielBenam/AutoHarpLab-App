package lab.autoarpa

import org.json.JSONObject

/** Textos de la parte nativa. Llegan traducidos desde el laboratorio web (src/i18n.js); aquí solo hay respaldo en español. */
object Str {
    private val map = HashMap<String, String>()
    private val def = mapOf(
        "n.menu" to "Menú", "tab.coverage" to "Tabla de acordes", "an.prev" to "Anterior", "an.next" to "Siguiente",
        "an.play" to "Play", "an.pause" to "Pausa", "an.repeat" to "Repetir", "an.stepMode" to "Paso a paso",
        "an.timeline" to "Línea de tiempo", "an.close" to "Cerrar", "an.speed" to "Velocidad", "an.stepOf" to "Paso {i} de {n}",
        "an.sound" to "Suena", "an.strings" to "Cuerdas", "an.seekHint" to "Toca la línea para ir a ese momento.",
        "an.bar" to "Barra {b}", "an.pressed" to "presiona", "an.released" to "suelta", "an.ringing" to "siguen sonando",
        "hand.left" to "Mano izquierda", "hand.right" to "Mano derecha", "leg.felt" to "tapada (fieltro)",
        "leg.c" to "Do (guía)", "leg.f" to "Fa (guía)", "pr.again" to "Otra vez", "pr.example" to "Ver ejemplo",
        "song.auto" to "Avanzar solo",
        "tour.1t" to "Botonera", "tour.1" to "Mantén una barra para tocar su acorde. Con varias a la vez solo suenan las cuerdas que todas dejan libres.",
        "tour.2t" to "Cuerdas", "tour.2" to "Desliza para rasguear, toca una cuerda para pulsarla y deja el dedo quieto para apagarla.",
        "tour.3t" to "Tabla de acordes", "tour.3" to "Encuentra cualquier acorde con su porcentaje de parecido, mira la animación y practícalo.",
        "tour.4t" to "Menú", "tour.4" to "Buscador, Optimizador, Modo canción, Editor de barras y Ajustes.",
        "tour.next" to "Siguiente", "tour.prev" to "Anterior", "tour.skip" to "Saltar", "tour.done" to "Listo",
        "n.latSw" to "Toque a motor", "n.latOut" to "Salida", "n.force" to "Fuerza táctil", "n.forceOn" to "detectada",
        "n.forceOff" to "sin datos útiles (se usa la velocidad)", "n.forceDis" to "desactivada"
    )

    fun set(json: String) {
        try { val o = JSONObject(json); val it = o.keys(); while (it.hasNext()) { val k = it.next(); map[k] = o.optString(k) } } catch (e: Exception) { }
    }

    fun t(k: String, vararg p: Pair<String, Any>): String {
        var s = map[k] ?: def[k] ?: k
        for ((a, b) in p) s = s.replace("{$a}", b.toString())
        return s
    }
}
