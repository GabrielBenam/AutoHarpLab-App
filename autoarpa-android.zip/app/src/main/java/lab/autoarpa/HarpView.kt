package lab.autoarpa

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.text.Layout as TextLayout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Autoarpa tocable (horizontal y vertical). Cada dedo toma un rol según dónde baja:
 * botones Menú/Tabla, línea de tiempo (saltar), botonera (mantener barras) o cuerdas (rasguear, pulsar, apagar).
 * Presionar una barra apaga al instante lo que vibra bajo su fieltro; soltarla no cambia nada.
 * Modos: ejemplo animado (Runner), Tu turno (registro para evaluar) y canción (marca y avanza).
 */
class HarpView(ctx: Context) : View(ctx) {
    companion object {
        const val REST_MS = 120L
        const val REST_SLOP_DP = 6f
        const val MIN_RETRIGGER_MS = 18L
        const val MAX_OFFSET_US = 60_000
        const val N = 36
    }

    private class Ptr(val id: Int) {
        var role = 0                  // 1 barra, 2 cuerdas, 3 botón de cabecera, 4 línea de tiempo
        var bar = -1
        var lastV = 0f; var lastT = 0L
        var downV = 0f; var downT = 0L
        var restDone = false; var moved = false
        var header = 0
    }

    class SongItem(val chord: String, val barIdx: Set<Int>, val range: IntArray?, val playable: Boolean, val how: String)
    class Song(val name: String, val items: List<SongItem>) { var i = 0; val hits = ArrayList<Long>(); var block = 0L }
    private class Practice(val barIdx: Set<Int>, val range: IntArray?) { var log = JSONArray(); var lastPluck = 0L; var pending = false }

    // ---- ajustes y retrollamadas ----
    var latch = false
    var mirror = false
    var studio = true
    var showLatency = false
    var useForce = true
    var style = "classic"
    var hints = true
    var autoAdvance = true
    var onMenu: (() -> Unit)? = null
    var onTable: (() -> Unit)? = null
    var onModeChanged: (() -> Unit)? = null
    var onFrame: (() -> Unit)? = null
    var onPracticeLog: ((String) -> Unit)? = null
    var onTourEnd: (() -> Unit)? = null

    // ---- estado ----
    private val ptrs = HashMap<Int, Ptr>()
    private var layout: Layout? = null
    private var flatBars = ArrayList<Bar>()
    private val barRects = ArrayList<RectF>()
    private val latched = HashSet<Int>()
    private var animPressed: Set<Int> = emptySet()
    private val lastStringT = LongArray(N)
    private val levels = FloatArray(N)
    private val stats = DoubleArray(11)
    private var statsAt = 0L
    private var curMask = (1L shl N) - 1
    private var audioOn = false
    private var downHeader = 0
    private var lastFrame = 0L
    var runner: Runner? = null; private set
    var timelineOpen = false
    private var practice: Practice? = null
    var song: Song? = null; private set
    var tourStep = -1; private set

    // fuerza táctil
    private var pMin = 1f; private var pMax = 0f; private var pCount = 0
    private fun forceOk() = useForce && pCount >= 25 && (pMax - pMin) > 0.12f
    private fun pNorm(p: Float) = ((p - pMin) / max(0.0001f, pMax - pMin)).coerceIn(0f, 1f)
    private fun seePressure(p: Float) { if (p > 0f) { pMin = min(pMin, p); pMax = max(pMax, p); pCount++ } }

    private val host = object : RunnerHost {
        override fun onPress(bars: List<Int>) { animPressed = bars.toSet(); applyMask(false) }
        override fun onPluck(s: Int, vel: Float, delayMs: Double) { Native.pluck(s, vel, (delayMs * 1000).toInt().coerceIn(0, 400000), 0.0) }
        override fun onStop() { for (i in 0 until N) Native.damp(i, 0) }
    }

    // ---- geometría ----
    private val dp = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val sp = FloatArray(N)              // posición de cada cuerda sobre su eje (x en horizontal, y en vertical)
    private var portrait = false
    private var barsPanel = RectF(); private var strPanel = RectF(); private var strip = RectF(); private val tlRect = RectF()
    private val menuRect = RectF(); private val tableRect = RectF()
    private var lineA = 0f; private var lineB = 0f   // extremos de cada cuerda (y en horizontal, x en vertical)
    private var spacing = 10f
    private val tourNext = RectF(); private val tourSkip = RectF(); private val tourPrev = RectF()

    private val cBg = Color.parseColor("#17130f"); private val cPanel = Color.parseColor("#261f18")
    private val cBtn = Color.parseColor("#30271f"); private val cOn = Color.parseColor("#e0a35a")
    private val cStr = Color.parseColor("#d9d2c5"); private val cOff = Color.parseColor("#4a4036")
    private val cAcc2 = Color.parseColor("#7cc4b0"); private val cText = Color.parseColor("#f1e8dc")
    private val cMuted = Color.parseColor("#a8998a"); private val cDark = Color.parseColor("#10201b")
    private val dash by lazy { DashPathEffect(floatArrayOf(5 * dp, 4 * dp), 0f) }

    fun setLayout(l: Layout) {
        val sameShape = layout?.let { it.rows.map { r -> r.size } == l.rows.map { r -> r.size } } ?: false
        layout = l
        flatBars = ArrayList(l.rows.flatten())
        if (!sameShape) { latched.clear(); ptrs.clear() }
        Native.setTuning(l.midi)
        relayout(); applyMask(false)
        invalidate()
    }
    fun currentMidi(): IntArray? = layout?.midi
    fun clearLatched() { latched.clear(); applyMask(true); invalidate() }
    fun relayout() { onSizeChanged(width, height, width, height); invalidate() }
    fun startAudio() { audioOn = layout?.let { Native.setTuning(it.midi); Native.start() } ?: false; postInvalidateOnAnimation() }
    fun stopAudio() { Native.stop(); audioOn = false; ptrs.clear() }
    fun mode(): String = when { runner != null -> "example"; practice != null -> "practice"; song != null -> "song"; else -> "none" }

    // ---------- modos ----------
    private fun stopModes() {
        if (runner != null) { host.onStop(); runner = null; animPressed = emptySet() }
        practice = null; song = null
    }
    fun startExample(json: String): Boolean {
        val pl = Plan.parse(json) ?: return false
        stopModes()
        runner = Runner(pl, host)
        timelineOpen = false; lastFrame = SystemClock.uptimeMillis()
        relayout(); applyMask(false); onModeChanged?.invoke(); return true
    }
    fun closeExample() { if (runner == null) return; host.onStop(); runner = null; animPressed = emptySet(); applyMask(false); relayout(); onModeChanged?.invoke() }
    fun exampleToggle() { runner?.toggle(); lastFrame = SystemClock.uptimeMillis(); onModeChanged?.invoke() }
    fun exampleStep(dir: Int) { val r = runner ?: return; if (dir > 0) r.nextStep() else r.prevStep(); lastFrame = SystemClock.uptimeMillis(); onModeChanged?.invoke() }
    fun exampleGoStep(i: Int) { runner?.goStep(i); lastFrame = SystemClock.uptimeMillis(); onModeChanged?.invoke() }

    fun startPractice(target: JSONObject) {
        stopModes()
        val bi = target.optJSONArray("barIdx"); val set = HashSet<Int>(); if (bi != null) for (i in 0 until bi.length()) set.add(bi.getInt(i))
        val rg = target.optJSONArray("range")
        practice = Practice(set, if (rg != null && rg.length() == 2) intArrayOf(rg.getInt(0), rg.getInt(1)) else null)
        practiceAgain()
        relayout(); onModeChanged?.invoke()
    }
    fun practiceAgain() {
        val pr = practice ?: return
        pr.log = JSONArray(); pr.log.put(JSONObject().put("t", SystemClock.uptimeMillis()).put("type", "press").put("bars", JSONArray(userPressed().toList())))
        pr.pending = false
    }
    fun closePractice() { if (practice == null) return; practice = null; relayout(); onModeChanged?.invoke() }

    fun startSong(name: String, items: List<SongItem>) {
        stopModes(); song = Song(name, items); relayout(); onModeChanged?.invoke()
    }
    fun songGo(i: Int) { val s = song ?: return; s.i = i.coerceIn(0, s.items.size - 1); s.hits.clear(); onModeChanged?.invoke(); invalidate() }
    fun closeSong() { if (song == null) return; song = null; relayout(); onModeChanged?.invoke() }

    fun startTour() { tourStep = 0; invalidate() }
    private fun endTour() { tourStep = -1; onTourEnd?.invoke(); invalidate() }

    // ---------- geometría ----------
    private fun timelineHeight(): Float {
        val nb = runner?.plan?.bars?.size ?: 1
        return (26 + 16 + nb * 28 + 16 + 48 + 26 + 20) * dp
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val l = layout ?: return
        if (w == 0 || h == 0) return
        val pad = 8 * dp
        portrait = h > w
        tlRect.setEmpty()
        if (portrait) {
            var top = pad
            if (runner != null) { val th = min(timelineHeight(), h * 0.36f); tlRect.set(pad, top, w - pad, top + th); top += th + 6 * dp }
            menuRect.set(pad, top, pad + 92 * dp, top + 34 * dp)
            tableRect.set(menuRect.right + 8 * dp, top, menuRect.right + 8 * dp + 168 * dp, top + 34 * dp)
            top += 42 * dp
            val barsH = min(l.rows.size * 56 * dp, h * 0.30f)
            barsPanel = RectF(pad, top, w - pad, top + barsH)
            top += barsH + 8 * dp
            strPanel = RectF(pad, top, w - pad, h - pad)
            strip = if (studio) RectF(strPanel.right - 24 * dp, strPanel.top, strPanel.right, strPanel.bottom) else RectF(strPanel.right, strPanel.top, strPanel.right, strPanel.bottom)
            lineA = strPanel.left + 6 * dp; lineB = strip.left - 6 * dp
            spacing = (strPanel.height() - 16 * dp) / (N - 1)
            for (i in 0 until N) sp[i] = strPanel.bottom - 8 * dp - i * spacing     // grave abajo
        } else {
            val barsW = w * 0.40f - pad
            val strW = w * 0.60f - 2 * pad
            // zurdo: solo cambia de lado la botonera; las cuerdas conservan su sentido (grave a la izquierda)
            if (mirror) { strPanel = RectF(pad, pad, pad + strW, h - pad); barsPanel = RectF(w - pad - barsW, pad, w - pad, h - pad) }
            else { barsPanel = RectF(pad, pad, pad + barsW, h - pad); strPanel = RectF(w - pad - strW, pad, w - pad, h - pad) }
            val bt = strPanel.top + 4 * dp; val bb = bt + 34 * dp
            menuRect.set(strPanel.left, bt, strPanel.left + 92 * dp, bb)
            tableRect.set(menuRect.right + 8 * dp, bt, menuRect.right + 8 * dp + 168 * dp, bb)
            val stripTop = bb + 6 * dp
            strip = RectF(strPanel.left, stripTop, strPanel.right, stripTop + if (studio) 40 * dp else 0f)
            if (runner != null && timelineOpen) tlRect.set(strPanel.left, stripTop, strPanel.right, strPanel.bottom)
            lineA = strip.bottom + 8 * dp; lineB = strPanel.bottom - 22 * dp
            val left = strPanel.left + 6 * dp; val right = strPanel.right - 6 * dp
            spacing = (right - left) / (N - 1)
            for (i in 0 until N) sp[i] = left + i * spacing
        }
        // botonera escalonada
        barRects.clear()
        val rows = l.rows; val maxCols = rows.maxOf { it.size }
        val stagger = 0.5f
        val cw = barsPanel.width() / (maxCols + stagger * (rows.size - 1))
        val rh = barsPanel.height() / rows.size
        for (r in rows.indices) {
            val off = r * stagger * cw
            for (c in rows[r].indices) {
                val bx = barsPanel.left + off + c * cw
                barRects.add(RectF(bx + 2 * dp, barsPanel.top + r * rh + 3 * dp, bx + cw - 2 * dp, barsPanel.top + (r + 1) * rh - 3 * dp))
            }
        }
        if (Build.VERSION.SDK_INT >= 29) systemGestureExclusionRects = listOf(Rect(0, 0, w, h))
    }

    // ---------- barras ----------
    private fun userPressed(): Set<Int> {
        val s = HashSet<Int>(latched)
        if (!latch) for (q in ptrs.values) if (q.role == 1 && q.bar >= 0) s.add(q.bar)
        return s
    }
    private fun pressedSet(): Set<Int> { val s = HashSet(userPressed()); s.addAll(animPressed); return s }
    private fun applyMask(logIt: Boolean) {
        var m = (1L shl N) - 1
        for (i in pressedSet()) if (i < flatBars.size) m = m and flatBars[i].mask
        curMask = m
        Native.setMask(m)
        if (logIt) practice?.let { it.log.put(JSONObject().put("t", SystemClock.uptimeMillis()).put("type", "press").put("bars", JSONArray(userPressed().toList()))) }
    }
    private fun barAt(x: Float, y: Float): Int {
        for (i in barRects.indices) if (barRects[i].contains(x, y)) return i
        return -1
    }

    // ---------- cuerdas ----------
    private fun axis(x: Float, y: Float) = if (portrait) y else x
    private fun inStrings(x: Float, y: Float): Boolean =
        if (portrait) y >= strPanel.top && y <= strPanel.bottom && x >= strPanel.left && x <= strPanel.right
        else x >= strPanel.left - spacing && x <= strPanel.right + spacing && y > menuRect.bottom
    private fun nearestString(v: Float): Int {
        var best = -1; var bd = Float.MAX_VALUE
        for (i in 0 until N) { val d = abs(sp[i] - v); if (d < bd) { bd = d; best = i } }
        return if (bd <= spacing * 0.75f) best else -1
    }
    private fun velFromSpeed(pxPerMs: Float): Float { val v = pxPerMs / dp; return 0.25f + 0.75f * min(1f, max(0f, (v - 0.3f) / 3.5f)) }
    private fun velocity(speedVel: Float, pressure: Float): Float =
        if (forceOk()) (0.5f * speedVel + 0.5f * (0.25f + 0.75f * pNorm(pressure))).coerceIn(0.1f, 1f) else speedVel

    private fun seekTimeline(x: Float) {
        val r = runner ?: return
        val lx = tlRect.left + 96 * dp; val lw = tlRect.right - 10 * dp - lx
        if (x < lx) return
        r.seek(((x - lx) / lw).coerceIn(0f, 1f) * r.plan.duration); r.playing = false; onModeChanged?.invoke()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (tourStep >= 0) { if (e.actionMasked == MotionEvent.ACTION_UP) tourTap(e.x, e.y); return true }
        var base = -1L
        fun off(t: Long): Int { if (base < 0) base = t; return min(MAX_OFFSET_US, ((t - base) * 1000L).toInt()) }

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; val id = e.getPointerId(i)
                val q = Ptr(id); ptrs[id] = q
                val x = e.getX(i); val y = e.getY(i); val t = e.eventTime
                val v = axis(x, y)
                q.lastV = v; q.lastT = t; q.downV = v; q.downT = t
                val b = barAt(x, y)
                if (menuRect.contains(x, y)) { q.role = 3; q.header = 1; downHeader = 1 }
                else if (tableRect.contains(x, y)) { q.role = 3; q.header = 2; downHeader = 2 }
                else if (!tlRect.isEmpty && tlRect.contains(x, y)) { q.role = 4; seekTimeline(x) }
                else if (b >= 0 || barsPanel.contains(x, y)) {
                    q.role = 1
                    if (latch) { if (!latched.remove(b) && b >= 0) latched.add(b) } else q.bar = b
                    applyMask(true)
                } else if (inStrings(x, y)) {
                    q.role = 2
                    val pr = e.getPressure(i); seePressure(pr)
                    val s = nearestString(v)
                    if (s >= 0) firePluck(s, if (forceOk()) 0.3f + 0.7f * pNorm(pr) else 0.6f, off(t), t)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val q = ptrs[e.getPointerId(i)] ?: continue
                    when (q.role) {
                        1 -> if (!latch) { val b = barAt(e.getX(i), e.getY(i)); if (b != q.bar) { q.bar = b; applyMask(true) } }
                        4 -> seekTimeline(e.getX(i))
                        2 -> {
                            for (h in 0 until e.historySize) {
                                val hp = e.getHistoricalPressure(i, h); seePressure(hp)
                                strumTo(q, axis(e.getHistoricalX(i, h), e.getHistoricalY(i, h)), e.getHistoricalEventTime(h), hp, ::off)
                            }
                            val cp = e.getPressure(i); seePressure(cp)
                            val v = axis(e.getX(i), e.getY(i))
                            strumTo(q, v, e.eventTime, cp, ::off)
                            if (abs(v - q.downV) > REST_SLOP_DP * dp) q.moved = true
                        }
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (e.actionMasked == MotionEvent.ACTION_CANCEL) { ptrs.clear(); downHeader = 0; applyMask(true) }
                else {
                    val i = e.actionIndex
                    val q = ptrs.remove(e.getPointerId(i))
                    if (q != null && q.role == 1) applyMask(true)
                    if (q != null && q.role == 3) {
                        val inside = (if (q.header == 1) menuRect else tableRect).contains(e.getX(i), e.getY(i))
                        if (inside) { if (q.header == 1) onMenu?.invoke() else onTable?.invoke() }
                        downHeader = 0
                    }
                }
            }
        }
        postInvalidateOnAnimation()
        return true
    }

    private fun strumTo(q: Ptr, v1: Float, t1: Long, pressure: Float, off: (Long) -> Int) {
        val v0 = q.lastV; val t0 = q.lastT
        if (t1 <= t0 && v1 == v0) return
        val dt = max(1L, t1 - t0).toFloat()
        val vel = velocity(velFromSpeed(abs(v1 - v0) / dt), pressure)
        if (v1 != v0) {
            val order = (0 until N).filter { if (v1 > v0) sp[it] > v0 && sp[it] <= v1 else sp[it] >= v1 && sp[it] < v0 }
                .sortedBy { if (v1 > v0) sp[it] else -sp[it] }
            for (s in order) {
                val t = t0 + ((sp[s] - v0) / (v1 - v0) * dt).toLong()
                if (t - lastStringT[s] < MIN_RETRIGGER_MS) continue
                firePluck(s, vel, off(t), t)
            }
        }
        q.lastV = v1; q.lastT = t1
    }

    private fun firePluck(s: Int, vel: Float, offUs: Int, t: Long) {
        lastStringT[s] = t
        Native.pluck(s, vel, offUs, t.toDouble())
        val sounded = ((curMask shr s) and 1L) == 1L
        practice?.let { it.log.put(JSONObject().put("t", t).put("type", "pluck").put("s", s).put("sounded", sounded)); it.lastPluck = SystemClock.uptimeMillis(); it.pending = true }
        song?.let { sg ->
            if (!autoAdvance || t < sg.block) return@let
            val it = sg.items.getOrNull(sg.i) ?: return@let
            if (userPressed() != it.barIdx) { sg.hits.clear(); return@let }
            sg.hits.add(t); sg.hits.removeAll { t - it > 600 }
            if (sg.hits.size >= 3 && sg.i < sg.items.size - 1) { sg.block = t + 700; sg.hits.clear(); val nx = sg.i + 1; postDelayed({ songGo(nx) }, 250) }
        }
    }

    // ---------- dibujo ----------
    private fun button(c: Canvas, r: RectF, label: String, down: Boolean) {
        p.style = Paint.Style.FILL; p.color = if (down) cOn else Color.parseColor("#3a3026")
        c.drawRoundRect(r, 10 * dp, 10 * dp, p)
        txt.textAlign = Paint.Align.CENTER
        txt.textSize = 14 * dp; txt.typeface = Typeface.DEFAULT_BOLD; txt.color = if (down) Color.parseColor("#1d150d") else cText
        c.drawText(label, r.centerX(), r.centerY() + 5 * dp, txt)
    }
    private fun isC(i: Int) = (layout?.names?.getOrNull(i) ?: "").let { it.startsWith("C") && !it.startsWith("C#") }
    private fun isF(i: Int) = (layout?.names?.getOrNull(i) ?: "").let { it.startsWith("F") && !it.startsWith("F#") }
    private fun cColor() = if (style == "contrast") Color.parseColor("#ffb000") else Color.parseColor("#e06a5a")
    private fun fColor() = if (style == "contrast") Color.parseColor("#2ec5ff") else Color.parseColor("#5aa0e0")
    private fun stringPaint(i: Int, open: Boolean, lv: Float) {
        p.style = Paint.Style.STROKE; p.pathEffect = null
        var w = (if (isC(i) || isF(i)) 2.4f else 1.6f) * dp + lv * 1.5f * dp
        when (style) {
            "sober" -> p.color = if (open) cStr else cOff
            "contrast" -> { w += 1 * dp; if (!open) { p.color = Color.parseColor("#4a4a4a"); p.pathEffect = dash } else p.color = if (isC(i)) cColor() else if (isF(i)) fColor() else Color.WHITE }
            else -> p.color = if (!open) cOff else if (isC(i)) cColor() else if (isF(i)) fColor() else cStr
        }
        p.strokeWidth = w
    }

    override fun onDraw(c: Canvas) {
        val l = layout ?: return
        val now = SystemClock.uptimeMillis()
        runner?.let { r -> val dt = (now - lastFrame).coerceIn(0L, 100L); if (r.tick(dt.toDouble())) onModeChanged?.invoke(); onFrame?.invoke() }
        lastFrame = now
        practice?.let { pr -> if (pr.pending && now - pr.lastPluck > 1300) { pr.pending = false; onPracticeLog?.invoke(pr.log.toString()); practiceAgain() } }
        // dedo quieto sobre cuerdas => apagar
        for (q in ptrs.values) if (q.role == 2 && !q.restDone && !q.moved && now - q.downT >= REST_MS) {
            q.restDone = true
            val s = nearestString(q.downV)
            if (s >= 0) for (d in -1..1) { val j = s + d; if (j in 0 until N && (d == 0 || abs(sp[j] - q.downV) < spacing * 1.1f)) Native.damp(j, 0) }
        }
        Native.getLevels(levels)
        c.drawColor(cBg)
        drawBars(c, now)
        button(c, menuRect, Str.t("n.menu"), downHeader == 1)
        button(c, tableRect, Str.t("tab.coverage"), downHeader == 2)
        drawStrings(c, l, now)
        if (!tlRect.isEmpty) drawTimeline(c, tlRect)
        if (showLatency) drawLatency(c, now)
        if (tourStep >= 0) drawTour(c)
        postInvalidateOnAnimation()
    }

    private fun drawBars(c: Canvas, now: Long) {
        p.style = Paint.Style.FILL; p.color = cPanel; p.pathEffect = null
        c.drawRoundRect(barsPanel, 14 * dp, 14 * dp, p)
        val pressed = pressedSet()
        val sg = song; val cur = sg?.items?.getOrNull(sg.i)?.barIdx ?: emptySet(); val nxt = sg?.items?.getOrNull(sg.i + 1)?.barIdx ?: emptySet()
        val hint = if (practice != null && hints) practice!!.barIdx else emptySet()
        for (i in barRects.indices) {
            val r = barRects[i]; val on = i in pressed; val byAnim = i in animPressed
            p.style = Paint.Style.FILL; p.pathEffect = null
            p.color = if (byAnim) cAcc2 else if (on) cOn else cBtn
            c.drawRoundRect(r, 9 * dp, 9 * dp, p)
            txt.textAlign = Paint.Align.CENTER
            txt.textSize = min(15 * dp, r.width() / 2.6f); txt.typeface = Typeface.DEFAULT_BOLD
            txt.color = if (on || byAnim) Color.parseColor("#1d150d") else cText
            c.drawText(flatBars[i].disp, r.centerX(), r.centerY() + txt.textSize * 0.35f, txt)
            p.style = Paint.Style.STROKE
            if (i in cur) { p.strokeWidth = 3 * dp; p.color = cAcc2; c.drawRoundRect(r, 9 * dp, 9 * dp, p) }
            else if (i in nxt) { p.strokeWidth = 2 * dp; p.color = cAcc2; p.pathEffect = dash; c.drawRoundRect(r, 9 * dp, 9 * dp, p); p.pathEffect = null }
            if (i in hint) { p.strokeWidth = 2 * dp; p.color = cOn; p.pathEffect = dash; c.drawRoundRect(r, 9 * dp, 9 * dp, p); p.pathEffect = null }
            if (byAnim) {
                val pulse = 0.5f + 0.5f * sin(now / 140f)
                p.strokeWidth = 3 * dp; p.color = cDark
                c.drawRoundRect(RectF(r.left + 2 * dp, r.top + 2 * dp, r.right - 2 * dp, r.bottom - 2 * dp), 8 * dp, 8 * dp, p)
                txt.textSize = 14 * dp + 2 * dp * pulse; c.drawText("✋", r.centerX(), r.top + txt.textSize, txt)
            }
        }
        p.style = Paint.Style.FILL
    }

    private fun drawStrings(c: Canvas, l: Layout, now: Long) {
        // franja Estudio: qué cuerdas pueden sonar (fieltro) y cuáles vibran (nivel)
        if (studio) {
            for (i in 0 until N) {
                val open = ((curMask shr i) and 1L) == 1L
                val lv = min(1f, sqrt(levels[i]) * 1.6f)
                p.style = Paint.Style.FILL; p.pathEffect = null
                if (portrait) {
                    val y0 = sp[i] - spacing / 2 + 1; val y1 = sp[i] + spacing / 2 - 1
                    p.color = if (open) Color.parseColor("#3a3026") else Color.parseColor("#1f1914"); c.drawRect(strip.left, y0, strip.right, y1, p)
                    if (open) { p.color = cOn; c.drawRect(strip.left, y0, strip.left + strip.width() * lv, y1, p) }
                } else {
                    val cw = strip.width() / N; val x = strip.left + i * cw
                    p.color = if (open) Color.parseColor("#3a3026") else Color.parseColor("#1f1914"); c.drawRect(x + 1, strip.top, x + cw - 1, strip.bottom, p)
                    if (open) { p.color = cOn; c.drawRect(x + 1, strip.bottom - strip.height() * lv, x + cw - 1, strip.bottom, p) }
                    else { p.color = Color.parseColor("#6b3b33"); c.drawRect(x + 1, strip.bottom - 3 * dp, x + cw - 1, strip.bottom, p) }
                }
            }
            if (!portrait) {
                txt.textAlign = Paint.Align.CENTER; txt.textSize = 9 * dp; txt.typeface = Typeface.DEFAULT; txt.color = cText
                for (i in 0 until N) if (isC(i) || i == 0) c.drawText(l.dispNames.getOrNull(i) ?: "", strip.left + (i + 0.5f) * strip.width() / N, strip.top + 11 * dp, txt)
            }
        }
        // zona: de la animación (relleno) o pista de práctica/canción (contorno)
        fun band(a: Int, b: Int): RectF = if (portrait) RectF(lineA - 4 * dp, sp[b] - spacing / 2, lineB + 4 * dp, sp[a] + spacing / 2)
            else RectF(sp[a] - spacing / 2, lineA - 4 * dp, sp[b] + spacing / 2, lineB + 4 * dp)
        runner?.sweep?.let { sw -> p.style = Paint.Style.FILL; p.color = Color.argb(40, 124, 196, 176); c.drawRect(band(sw.a, sw.b), p) }
        val hz = practice?.range?.takeIf { hints } ?: song?.items?.getOrNull(song!!.i)?.range
        if (hz != null && hz.size == 2) { p.style = Paint.Style.STROKE; p.strokeWidth = 2 * dp; p.color = cAcc2; p.pathEffect = dash; c.drawRect(band(hz[0], hz[1]), p); p.pathEffect = null }
        val tsec = now / 1000f
        for (i in 0 until N) {
            val open = ((curMask shr i) and 1L) == 1L
            val lv = min(1f, sqrt(levels[i]) * 1.6f)
            stringPaint(i, open, lv)
            if (lv > 0.02f && open) {
                val amp = lv * 3.2f * dp; val k = 14
                val path = Path()
                if (portrait) { path.moveTo(lineA, sp[i]); for (j in 1..k) path.lineTo(lineA + (lineB - lineA) * j / k, sp[i] + amp * sin(j * Math.PI / k).toFloat() * sin(tsec * 90f + i)) }
                else { path.moveTo(sp[i], lineA); for (j in 1..k) path.lineTo(sp[i] + amp * sin(j * Math.PI / k).toFloat() * sin(tsec * 90f + i), lineA + (lineB - lineA) * j / k) }
                c.drawPath(path, p)
            } else if (portrait) c.drawLine(lineA, sp[i], lineB, sp[i], p) else c.drawLine(sp[i], lineA, sp[i], lineB, p)
        }
        p.pathEffect = null
        // guía de la animación: mano que rasguea y anillo del pinch
        runner?.let { r ->
            val mid = (lineA + lineB) / 2
            r.sweep?.let { sw ->
                val k = if (sw.dur > 0) ((r.t - sw.t) / sw.dur).coerceIn(0.0, 1.0).toFloat() else 1f
                val pos = sp[sw.a] + (sp[sw.b] - sp[sw.a]) * k
                p.style = Paint.Style.STROKE; p.strokeWidth = 2 * dp; p.color = cAcc2
                if (portrait) c.drawLine(lineA, pos, lineB, pos, p) else c.drawLine(pos, lineA, pos, lineB, p)
                p.style = Paint.Style.FILL
                val cx = if (portrait) mid else pos; val cy = if (portrait) pos else mid
                c.drawCircle(cx, cy, 14 * dp, p)
                txt.textAlign = Paint.Align.CENTER; txt.textSize = 16 * dp; txt.typeface = Typeface.DEFAULT_BOLD; txt.color = cDark
                c.drawText(if (portrait) "↑" else "→", cx, cy + 6 * dp, txt)
            }
            for (f in r.focus) {
                val k = (((r.t - f.t) / 300.0) % 1.0).toFloat()
                val cx = if (portrait) mid else sp[f.s]; val cy = if (portrait) sp[f.s] else mid
                p.style = Paint.Style.STROKE; p.strokeWidth = 3 * dp; p.color = cAcc2
                c.drawCircle(cx, cy, (10 + 12 * k) * dp, p)
                p.style = Paint.Style.FILL; c.drawCircle(cx, cy, 6 * dp, p)
            }
        }
        // leyenda de colores
        if (style != "sober") {
            val items = listOf(cColor() to Str.t("leg.c"), fColor() to Str.t("leg.f"), cOff to Str.t("leg.felt"))
            txt.textAlign = Paint.Align.LEFT; txt.textSize = 10 * dp; txt.typeface = Typeface.DEFAULT
            var lx = strPanel.left + 8 * dp; val ly = strPanel.bottom - 6 * dp
            var total = 0f; items.forEach { total += 26 * dp + txt.measureText(it.second) }
            p.style = Paint.Style.FILL; p.color = Color.argb(150, 0, 0, 0)
            c.drawRoundRect(RectF(lx - 4 * dp, ly - 13 * dp, lx + total, ly + 4 * dp), 6 * dp, 6 * dp, p)
            for ((col, lab) in items) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 3 * dp; p.color = col
                c.drawLine(lx, ly - 4 * dp, lx + 14 * dp, ly - 4 * dp, p)
                txt.color = cText; c.drawText(lab, lx + 18 * dp, ly, txt)
                lx += 26 * dp + txt.measureText(lab)
            }
            txt.textAlign = Paint.Align.CENTER
        }
    }

    /** Línea de tiempo: una fila por barra (presiona/suelta), una por la mano de las cuerdas y una de lo que suena. */
    private fun drawTimeline(c: Canvas, R: RectF) {
        val r = runner ?: return; val pl = r.plan
        p.style = Paint.Style.FILL; p.pathEffect = null; p.color = Color.argb(248, 20, 16, 12)
        c.drawRoundRect(R, 12 * dp, 12 * dp, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1 * dp; p.color = Color.parseColor("#3a3026"); c.drawRoundRect(R, 12 * dp, 12 * dp, p)
        val lx = R.left + 96 * dp; val lw = R.right - 10 * dp - lx
        fun px(v: Double) = lx + lw * (v / pl.duration).toFloat()
        val bottom = R.bottom - 18 * dp
        txt.textAlign = Paint.Align.LEFT; txt.typeface = Typeface.DEFAULT_BOLD
        var y = R.top + 18 * dp
        pl.steps.forEachIndexed { i, s ->
            if (i > 0) { p.color = Color.parseColor("#4a4036"); p.pathEffect = dash; p.strokeWidth = 1 * dp; c.drawLine(px(s.t0), R.top + 6 * dp, px(s.t0), bottom, p); p.pathEffect = null }
            txt.textSize = 11 * dp; txt.color = if (i == r.step()) cAcc2 else cMuted
            c.drawText("${i + 1} ${s.title}", px(s.t0) + 4 * dp, y, txt)
        }
        y += 8 * dp
        txt.textSize = 9.5f * dp; txt.color = cMuted
        c.drawText((pl.steps.getOrNull(0)?.hand ?: "").uppercase(), R.left + 8 * dp, y + 10 * dp, txt); y += 14 * dp
        for (b in pl.bars) {
            txt.textSize = 11 * dp; txt.color = cText; txt.typeface = Typeface.DEFAULT_BOLD
            c.drawText(Str.t("an.bar", "b" to b.label), R.left + 8 * dp, y + 16 * dp, txt)
            p.style = Paint.Style.FILL; p.color = cAcc2
            c.drawRoundRect(RectF(px(b.t0), y + 3 * dp, max(px(b.t0) + 4 * dp, px(b.t1)), y + 21 * dp), 6 * dp, 6 * dp, p)
            txt.textSize = 9.5f * dp; txt.color = cDark
            c.drawText(Str.t("an.pressed"), px(b.t0) + 5 * dp, y + 16 * dp, txt)
            if (b.t1 < pl.duration) { txt.textAlign = Paint.Align.RIGHT; c.drawText(Str.t("an.released"), px(b.t1) - 5 * dp, y + 16 * dp, txt); txt.textAlign = Paint.Align.LEFT }
            y += 28 * dp
        }
        txt.textSize = 9.5f * dp; txt.color = cMuted
        c.drawText((pl.steps.getOrNull(1)?.hand ?: "").uppercase(), R.left + 8 * dp, y + 10 * dp, txt); y += 14 * dp
        txt.textSize = 11 * dp; txt.color = cText; c.drawText(Str.t("an.strings"), R.left + 8 * dp, y + 18 * dp, txt)
        for (a in pl.right) {
            p.style = Paint.Style.FILL; p.color = cOn
            txt.textSize = 10 * dp; txt.color = cOn
            if (a.type == "strum") {
                val path = Path(); path.moveTo(px(a.t0), y + 26 * dp); path.lineTo(px(a.t1) + 2 * dp, y + 6 * dp); path.lineTo(px(a.t1) + 2 * dp, y + 26 * dp); path.close()
                c.drawPath(path, p); c.drawText(a.text, px(a.t0), y + 40 * dp, txt)
            } else {
                c.drawCircle(px(a.t), y + 16 * dp, 7 * dp, p)
                txt.textAlign = Paint.Align.CENTER; c.drawText(a.text, px(a.t), y + 40 * dp, txt); txt.textAlign = Paint.Align.LEFT
            }
        }
        y += 48 * dp
        txt.textSize = 9.5f * dp; txt.color = cMuted; c.drawText(Str.t("an.sound").uppercase(), R.left + 8 * dp, y + 12 * dp, txt)
        txt.textSize = 11 * dp; txt.color = cText; txt.typeface = Typeface.DEFAULT
        for (s in pl.sound) c.drawText(s.text, px(s.t), y + 12 * dp, txt)
        txt.textSize = 10 * dp; txt.color = cMuted; c.drawText(Str.t("an.seekHint"), R.left + 8 * dp, R.bottom - 6 * dp, txt)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * dp; p.color = cOn
        val cx = px(r.t); c.drawLine(cx, R.top + 6 * dp, cx, bottom, p)
        txt.textAlign = Paint.Align.CENTER
    }

    private fun drawLatency(c: Canvas, now: Long) {
        if (now - statsAt > 250) { Native.stats(stats); statsAt = now }
        val out = stats[3]
        val force = if (!useForce) Str.t("n.forceDis") else if (forceOk()) Str.t("n.forceOn") else Str.t("n.forceOff")
        val lines = listOf(
            "Audio: " + (if (audioOn) "OK" else "—") + "  " + (if (stats[10] == 1.0) "AAudio" else if (stats[10] == 2.0) "OpenSL" else "-") +
                "  " + (if (stats[8] == 1.0) "low-latency" else "normal") + "  " + (if (stats[9] == 1.0) "exclusive" else "shared"),
            "${stats[4].toInt()} Hz  burst ${stats[5].toInt()}  buffer ${stats[6].toInt()}  xruns ${stats[7].toInt()}",
            Str.t("n.latSw") + ": %.1f / %.1f / %.1f ms".format(stats[0], stats[1], stats[2]),
            Str.t("n.latOut") + ": " + (if (out >= 0) "%.1f ms".format(out) else "—") + "   Σ " + (if (out >= 0) "%.0f ms".format(stats[1] + out) else "—"),
            Str.t("n.force") + ": " + force
        )
        p.style = Paint.Style.FILL; p.color = Color.argb(225, 10, 8, 6)
        val h = lines.size * 17 * dp + 16 * dp
        c.drawRoundRect(RectF(barsPanel.left, barsPanel.bottom - h, barsPanel.right, barsPanel.bottom), 12 * dp, 12 * dp, p)
        txt.textAlign = Paint.Align.LEFT; txt.textSize = 10.5f * dp; txt.color = cAcc2; txt.typeface = Typeface.MONOSPACE
        for ((k, s) in lines.withIndex()) c.drawText(s, barsPanel.left + 10 * dp, barsPanel.bottom - h + 22 * dp + k * 17 * dp, txt)
        txt.textAlign = Paint.Align.CENTER
    }

    // ---------- recorrido guiado ----------
    private fun tourTarget(): RectF = when (tourStep) { 0 -> barsPanel; 1 -> RectF(strPanel.left, if (portrait) strPanel.top else lineA, strPanel.right, strPanel.bottom); 2 -> tableRect; else -> menuRect }
    private fun drawTour(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val tg = RectF(tourTarget()); tg.inset(-6 * dp, -6 * dp)
        val path = Path(); path.fillType = Path.FillType.EVEN_ODD
        path.addRect(0f, 0f, w, h, Path.Direction.CW); path.addRoundRect(tg, 12 * dp, 12 * dp, Path.Direction.CW)
        p.style = Paint.Style.FILL; p.pathEffect = null; p.color = Color.argb(165, 0, 0, 0); c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2 * dp; p.color = cAcc2; c.drawRoundRect(tg, 12 * dp, 12 * dp, p)
        val cw = min(340 * dp, w - 24 * dp)
        tp.textSize = 14 * dp; tp.color = cText; tp.typeface = Typeface.DEFAULT
        val keys = listOf("tour.1", "tour.2", "tour.3", "tour.4")
        val body = StaticLayout.Builder.obtain(Str.t(keys[tourStep]), 0, Str.t(keys[tourStep]).length, tp, (cw - 24 * dp).toInt()).setAlignment(TextLayout.Alignment.ALIGN_NORMAL).build()
        val ch = 16 * dp + 18 * dp + 26 * dp + body.height + 14 * dp + 40 * dp
        // posición: debajo, arriba, a un lado o centrada
        var cx: Float; var cy: Float
        when {
            tg.bottom + 10 * dp + ch < h -> { cx = tg.left; cy = tg.bottom + 10 * dp }
            tg.top - 10 * dp - ch > 0 -> { cx = tg.left; cy = tg.top - 10 * dp - ch }
            w - tg.right > cw + 20 * dp -> { cx = tg.right + 10 * dp; cy = 12 * dp }
            tg.left > cw + 20 * dp -> { cx = tg.left - 10 * dp - cw; cy = 12 * dp }
            else -> { cx = (w - cw) / 2; cy = (h - ch) / 2 }
        }
        cx = cx.coerceIn(12 * dp, w - cw - 12 * dp); cy = cy.coerceIn(12 * dp, max(12 * dp, h - ch - 12 * dp))
        val card = RectF(cx, cy, cx + cw, cy + ch)
        p.style = Paint.Style.FILL; p.color = cPanel; c.drawRoundRect(card, 14 * dp, 14 * dp, p)
        txt.textAlign = Paint.Align.LEFT; txt.textSize = 11 * dp; txt.color = cAcc2; txt.typeface = Typeface.DEFAULT_BOLD
        c.drawText("${tourStep + 1} / 4", cx + 12 * dp, cy + 22 * dp, txt)
        txt.textSize = 16 * dp; txt.color = cText
        c.drawText(Str.t(keys[tourStep] + "t"), cx + 12 * dp, cy + 44 * dp, txt)
        c.save(); c.translate(cx + 12 * dp, cy + 54 * dp); body.draw(c); c.restore()
        val by = card.bottom - 46 * dp
        tourSkip.set(cx + 12 * dp, by, cx + 12 * dp + 100 * dp, by + 34 * dp)
        tourNext.set(card.right - 12 * dp - 120 * dp, by, card.right - 12 * dp, by + 34 * dp)
        tourPrev.set(tourNext.left - 8 * dp - 100 * dp, by, tourNext.left - 8 * dp, by + 34 * dp)
        button(c, tourSkip, Str.t("tour.skip"), false)
        if (tourStep > 0) button(c, tourPrev, Str.t("tour.prev"), false) else tourPrev.setEmpty()
        button(c, tourNext, if (tourStep == 3) Str.t("tour.done") else Str.t("tour.next"), true)
        txt.textAlign = Paint.Align.CENTER
    }
    private fun tourTap(x: Float, y: Float) {
        when {
            tourNext.contains(x, y) -> if (tourStep >= 3) endTour() else { tourStep++; invalidate() }
            !tourPrev.isEmpty && tourPrev.contains(x, y) -> { tourStep = max(0, tourStep - 1); invalidate() }
            tourSkip.contains(x, y) -> endTour()
        }
    }
}
