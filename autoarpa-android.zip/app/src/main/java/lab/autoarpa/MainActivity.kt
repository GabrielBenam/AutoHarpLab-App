package lab.autoarpa

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var harp: HarpView
    private lateinit var web: WebView
    private lateinit var root: LinearLayout
    private lateinit var dock: LinearLayout
    private val prefs by lazy { getSharedPreferences("autoarpa", Context.MODE_PRIVATE) }
    private var overlayOpen = false
    private val dp by lazy { resources.displayMetrics.density }

    // ---- franja superior (dinámica) ----
    private lateinit var exRow: LinearLayout; private lateinit var exCtrlA: LinearLayout; private lateinit var exCtrlB: LinearLayout; private lateinit var exText: LinearLayout
    private lateinit var exHead: TextView; private lateinit var exBody: TextView; private lateinit var exPlay: Button; private lateinit var exSpeed: TextView
    private lateinit var exStepChk: CheckBox; private lateinit var exTl: Button; private lateinit var stepBar: StepBarView
    private lateinit var prRow: LinearLayout; private lateinit var prCtrl: LinearLayout; private lateinit var prText: LinearLayout
    private lateinit var prHead: TextView; private lateinit var prBody: TextView; private lateinit var prAgain: Button; private lateinit var prEx: Button
    private lateinit var sgRow: LinearLayout; private lateinit var sgCtrlA: LinearLayout; private lateinit var sgCtrlB: LinearLayout; private lateinit var sgText: LinearLayout
    private lateinit var sgHead: TextView; private lateinit var sgBody: TextView; private lateinit var sgAuto: CheckBox; private lateinit var sgChips: LinearLayout
    private lateinit var sgScroll: HorizontalScrollView
    private var practiceJson: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layouts = Layouts.load(this)

        harp = HarpView(this)
        harp.setLayout(layouts[0])                         // se reemplaza en cuanto el laboratorio envía el layout activo
        harp.mirror = prefs.getBoolean("mirror", false)
        harp.studio = prefs.getBoolean("studio", true)
        harp.latch = prefs.getBoolean("latch", false)
        harp.showLatency = prefs.getBoolean("latency", false)
        harp.useForce = prefs.getBoolean("force", true)
        harp.style = prefs.getString("style", "classic") ?: "classic"
        harp.onMenu = { openOverlay("menu") }
        harp.onTable = { openOverlay("table") }
        harp.onModeChanged = { refreshDock() }
        harp.onFrame = { if (stepBar.visibility == View.VISIBLE) stepBar.invalidate() }
        harp.onPracticeLog = { log -> evaluatePractice(log) }
        harp.onTourEnd = { prefs.edit().putBoolean("tourDone", true).apply() }

        buildDock()

        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#17130f"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "AndroidBridge")
            visibility = View.GONE
            loadUrl("file:///android_asset/web/index.html?embed=android")
        }

        val stack = FrameLayout(this)
        stack.addView(harp, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        stack.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#17130f")) }
        root.addView(dock, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(stack, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        applyInsets()
        arrangeDock()
        refreshDock()
        harp.post { if (!prefs.getBoolean("tourDone", false)) harp.startTour() }
    }

    /** Reserva el margen de la barra de navegación, los gestos y la cámara: nada del sistema queda encima de los botones. */
    private fun applyInsets() {
        root.setOnApplyWindowInsetsListener { v, wi ->
            var l = 0; var t = 0; var r = 0; var b = 0
            if (Build.VERSION.SDK_INT >= 30) {
                val s = wi.getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars() or WindowInsets.Type.displayCutout())
                val g = wi.getInsets(WindowInsets.Type.mandatorySystemGestures())
                l = max(s.left, g.left); r = max(s.right, g.right); b = max(s.bottom, g.bottom); t = s.top
            } else {
                l = wi.stableInsetLeft; r = wi.stableInsetRight; b = wi.stableInsetBottom
                if (Build.VERSION.SDK_INT >= 29) { val g = wi.mandatorySystemGestureInsets; l = max(l, g.left); r = max(r, g.right); b = max(b, g.bottom) }
                if (Build.VERSION.SDK_INT >= 28) wi.displayCutout?.let { l = max(l, it.safeInsetLeft); r = max(r, it.safeInsetRight); t = max(t, it.safeInsetTop); b = max(b, it.safeInsetBottom) }
            }
            v.setPadding(l, t, r, b)
            wi
        }
        root.requestApplyInsets()
    }

    // ---------- franja superior ----------
    private fun btn(text: String, primary: Boolean = false, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 12f; minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding((12 * dp).toInt(), (4 * dp).toInt(), (12 * dp).toInt(), (4 * dp).toInt())
        if (primary) { setBackgroundColor(Color.parseColor("#e0a35a")); setTextColor(Color.parseColor("#1d150d")) }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(3, 2, 3, 2) }
    }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun textCol(head: TextView, body: TextView): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding((8 * dp).toInt(), 0, (8 * dp).toInt(), 0)
        addView(head); addView(body)
    }
    private fun headTv() = TextView(this).apply { setTextColor(Color.parseColor("#7cc4b0")); textSize = 11f; setTypeface(typeface, android.graphics.Typeface.BOLD); maxLines = 1 }
    private fun bodyTv(lines: Int) = TextView(this).apply { setTextColor(Color.parseColor("#f1e8dc")); textSize = 13f; maxLines = lines }
    private fun chk(text: String, checked: Boolean, onChange: (Boolean) -> Unit) = CheckBox(this).apply {
        this.text = text; isChecked = checked; textSize = 11f; setTextColor(Color.parseColor("#a8998a")); setOnCheckedChangeListener { _, b -> onChange(b) }
    }

    private fun buildDock() {
        dock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#201a14")); setPadding((4 * dp).toInt(), (2 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt()); visibility = View.GONE }
        // ejemplo
        exHead = headTv(); exBody = bodyTv(3); exText = textCol(exHead, exBody)
        exCtrlA = row(); exCtrlB = row()
        exCtrlA.addView(btn("◀") { harp.exampleStep(-1) })
        exPlay = btn(Str.t("an.pause"), true) { harp.exampleToggle() }; exCtrlA.addView(exPlay)
        exCtrlA.addView(btn("▶") { harp.exampleStep(1) })
        exCtrlA.addView(btn("−") { harp.runner?.changeSpeed(-1); refreshDock() })
        exSpeed = TextView(this).apply { setTextColor(Color.parseColor("#f1e8dc")); textSize = 12f; gravity = Gravity.CENTER; minWidth = (42 * dp).toInt() }
        exCtrlA.addView(exSpeed)
        exCtrlA.addView(btn("+") { harp.runner?.changeSpeed(1); refreshDock() })
        exStepChk = chk(Str.t("an.stepMode"), true) { b -> harp.runner?.stepMode = b }
        exCtrlB.addView(exStepChk)
        exTl = btn(Str.t("an.timeline")) { harp.timelineOpen = !harp.timelineOpen; harp.relayout(); refreshDock() }
        exCtrlB.addView(exTl)
        exCtrlB.addView(btn("✕") { harp.closeExample() })
        exRow = LinearLayout(this)
        stepBar = StepBarView(this, harp)
        // Tu turno
        prHead = headTv(); prBody = bodyTv(6); prText = textCol(prHead, prBody)
        prCtrl = row()
        prAgain = btn(Str.t("pr.again"), true) { harp.practiceAgain(); prBody.text = prDo; refreshDock() }
        prEx = btn(Str.t("pr.example")) { practiceJson?.let { web.evaluateJavascript("AH.ui.playLastPracticeExample && AH.ui.playLastPracticeExample()", null) } }
        prCtrl.addView(prAgain); prCtrl.addView(prEx); prCtrl.addView(btn("✕") { harp.closePractice() })
        prRow = LinearLayout(this)
        // canción
        sgHead = headTv(); sgBody = bodyTv(2); sgText = textCol(sgHead, sgBody)
        sgCtrlA = row(); sgCtrlB = row()
        sgCtrlA.addView(btn("◀") { harp.song?.let { harp.songGo(it.i - 1) } })
        sgCtrlA.addView(btn("▶") { harp.song?.let { harp.songGo(it.i + 1) } })
        sgAuto = chk(Str.t("song.auto"), true) { b -> harp.autoAdvance = b }
        sgCtrlB.addView(sgAuto); sgCtrlB.addView(btn("✕") { harp.closeSong() })
        sgRow = LinearLayout(this)
        sgChips = row()
        sgScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(sgChips) }

        dock.addView(exRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        dock.addView(stepBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (26 * dp).toInt()))
        dock.addView(prRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        dock.addView(sgRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        dock.addView(sgScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }
    private var prDo = ""

    /** Horizontal: controles | texto | controles en una fila. Vertical: texto arriba y controles debajo. */
    private fun arrange(rowView: LinearLayout, a: LinearLayout?, text: LinearLayout, b: LinearLayout?, portrait: Boolean) {
        listOfNotNull(a, text, b).forEach { (it.parent as? ViewGroup)?.removeView(it) }
        rowView.removeAllViews()
        if (portrait) {
            rowView.orientation = LinearLayout.VERTICAL
            rowView.addView(text, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            val ctrls = row()
            a?.let { ctrls.addView(it) }
            ctrls.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
            b?.let { ctrls.addView(it) }
            rowView.addView(ctrls, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        } else {
            rowView.orientation = LinearLayout.HORIZONTAL; rowView.gravity = Gravity.CENTER_VERTICAL
            a?.let { rowView.addView(it) }
            rowView.addView(text, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            b?.let { rowView.addView(it) }
        }
    }
    private fun isPortrait() = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
    private fun arrangeDock() {
        val pt = isPortrait()
        arrange(exRow, exCtrlA, exText, exCtrlB, pt)
        arrange(prRow, null, prText, prCtrl, pt)
        arrange(sgRow, sgCtrlA, sgText, sgCtrlB, pt)
    }
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        arrangeDock(); refreshDock(); harp.post { harp.relayout() }
    }

    private fun refreshDock() {
        val mode = harp.mode()
        dock.visibility = if (mode == "none") View.GONE else View.VISIBLE
        exRow.visibility = if (mode == "example") View.VISIBLE else View.GONE
        stepBar.visibility = exRow.visibility
        prRow.visibility = if (mode == "practice") View.VISIBLE else View.GONE
        sgRow.visibility = if (mode == "song") View.VISIBLE else View.GONE
        sgScroll.visibility = sgRow.visibility
        harp.runner?.let { r ->
            val done = r.done(); val st = r.plan.steps[r.step()]
            exHead.text = if (done) r.plan.label else st.head
            exBody.text = if (done) r.plan.result else st.text
            exPlay.text = if (r.playing) Str.t("an.pause") else if (done) Str.t("an.repeat") else Str.t("an.play")
            exSpeed.text = r.speedLabel()
            exStepChk.text = Str.t("an.stepMode")
            exTl.text = Str.t("an.timeline") + if (harp.timelineOpen) " ▴" else " ▾"
            exTl.visibility = if (isPortrait()) View.GONE else View.VISIBLE
            stepBar.invalidate()
        }
        prAgain.text = Str.t("pr.again"); prEx.text = Str.t("pr.example"); sgAuto.text = Str.t("song.auto")
        harp.song?.let { s ->
            val cur = s.items[s.i]; val nx = s.items.getOrNull(s.i + 1)
            sgHead.text = "${s.name} · ${s.i + 1}/${s.items.size}"
            sgBody.text = cur.chord + ": " + cur.how + (if (nx != null) "   →  " + nx.chord else "")
            if (sgChips.childCount != s.items.size) {
                sgChips.removeAllViews()
                s.items.forEachIndexed { k, it -> sgChips.addView(btn(it.chord) { harp.songGo(k) }) }
            }
            for (k in 0 until sgChips.childCount) {
                val b = sgChips.getChildAt(k) as Button
                b.setBackgroundColor(if (k == s.i) Color.parseColor("#7cc4b0") else if (k == s.i + 1) Color.parseColor("#3d5a52") else Color.parseColor("#30271f"))
                b.setTextColor(if (k == s.i) Color.parseColor("#10201b") else Color.parseColor("#f1e8dc"))
                b.alpha = if (s.items[k].playable) 1f else 0.45f
            }
            sgChips.getChildAt(s.i)?.let { v -> sgScroll.post { sgScroll.smoothScrollTo(max(0, v.left - sgScroll.width / 3), 0) } }
        }
    }

    private fun evaluatePractice(log: String) {
        web.evaluateJavascript("JSON.stringify(AH.ui.evalPractice(" + JSONObject.quote(log) + "))") { v ->
            try {
                val s = JSONTokener(v).nextValue() as? String ?: return@evaluateJavascript
                val o = JSONObject(s)
                prHead.text = o.optString("title")
                val items = o.optJSONArray("items")
                val sb = StringBuilder()
                if (items != null) for (i in 0 until items.length()) { val it = items.getJSONObject(i); if (sb.isNotEmpty()) sb.append('\n'); sb.append(if (it.optBoolean("ok")) "✓ " else "✗ ").append(it.optString("text")) }
                prBody.text = sb.toString()
            } catch (e: Exception) { }
        }
    }

    private fun openOverlay(mode: String) {
        overlayOpen = true
        web.visibility = View.VISIBLE
        web.evaluateJavascript("if(window.AH&&AH.ui){AH.ui.openMode('$mode')}", null)
        web.requestFocus()
    }
    private fun closeOverlay() { overlayOpen = false; web.visibility = View.GONE }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (overlayOpen) closeOverlay() else super.onBackPressed() }

    private fun applyLayout(json: String) {
        try {
            val l = Layouts.parseOne(JSONObject(json))
            val oldMidi = harp.currentMidi()
            harp.setLayout(l)
            if (oldMidi != null && !oldMidi.contentEquals(l.midi)) { harp.stopAudio(); harp.startAudio() }
        } catch (e: Exception) { }
    }

    /** Puente con el laboratorio web. Los métodos llegan en un hilo del WebView: lo que toca la interfaz pasa al hilo principal. */
    inner class Bridge {
        @JavascriptInterface fun layoutChanged(json: String) { runOnUiThread { applyLayout(json) } }
        @JavascriptInterface fun setStrings(json: String) { runOnUiThread { Str.set(json); refreshDock(); harp.invalidate() } }
        @JavascriptInterface fun playExample(json: String) { runOnUiThread { closeOverlay(); harp.startExample(json) } }
        @JavascriptInterface fun startPractice(json: String) {
            runOnUiThread {
                try {
                    val o = JSONObject(json)
                    closeOverlay(); practiceJson = json
                    prDo = o.optString("body"); prHead.text = o.optString("head"); prBody.text = prDo
                    harp.startPractice(o.getJSONObject("target"))
                } catch (e: Exception) { }
            }
        }
        @JavascriptInterface fun startSong(json: String) {
            runOnUiThread {
                try {
                    val o = JSONObject(json); val arr = o.getJSONArray("items")
                    val items = ArrayList<HarpView.SongItem>()
                    for (i in 0 until arr.length()) {
                        val it = arr.getJSONObject(i)
                        val bi = it.optJSONArray("barIdx"); val set = HashSet<Int>(); if (bi != null) for (k in 0 until bi.length()) set.add(bi.getInt(k))
                        val rg = it.optJSONArray("range")
                        items.add(HarpView.SongItem(it.optString("chord"), set, if (rg != null && rg.length() == 2) intArrayOf(rg.getInt(0), rg.getInt(1)) else null, it.optBoolean("playable"), it.optString("how")))
                    }
                    if (items.isEmpty()) return@runOnUiThread
                    closeOverlay(); sgChips.removeAllViews()
                    harp.startSong(o.optString("name"), items)
                } catch (e: Exception) { }
            }
        }
        @JavascriptInterface fun startTour() { runOnUiThread { closeOverlay(); harp.startTour() } }
        @JavascriptInterface fun close() { runOnUiThread { closeOverlay() } }
        @JavascriptInterface fun resetStats() { Native.resetStats() }
        @JavascriptInterface fun getSettings(): String = JSONObject().apply {
            put("latch", prefs.getBoolean("latch", false)); put("mirror", prefs.getBoolean("mirror", false)); put("studio", prefs.getBoolean("studio", true))
            put("latency", prefs.getBoolean("latency", false)); put("force", prefs.getBoolean("force", true))
            prefs.getString("lang", null)?.let { put("lang", it) }
            put("notation", prefs.getString("notation", "auto")); put("style", prefs.getString("style", "classic"))
        }.toString()
        @JavascriptInterface fun setSetting(key: String, v: Boolean) {
            prefs.edit().putBoolean(key, v).apply()
            runOnUiThread {
                when (key) {
                    "latch" -> { harp.latch = v; if (!v) harp.clearLatched() }
                    "mirror" -> { harp.mirror = v; harp.relayout() }
                    "studio" -> { harp.studio = v; harp.relayout() }
                    "latency" -> harp.showLatency = v
                    "force" -> harp.useForce = v
                }
            }
        }
        @JavascriptInterface fun setSettingStr(key: String, v: String) {
            prefs.edit().putString(key, v).apply()
            if (key == "style") runOnUiThread { harp.style = v; harp.invalidate() }
        }
        /** Guarda una imagen PNG (hoja de fieltrado) en Imágenes/Autoarpa. Devuelve dónde quedó. */
        @JavascriptInterface fun saveImage(dataUrl: String, name: String): String = try {
            val bytes = Base64.decode(dataUrl.substringAfter(","), Base64.DEFAULT)
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Autoarpa")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: throw IllegalStateException("MediaStore")
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                Environment.DIRECTORY_PICTURES + "/Autoarpa/" + name
            } else {
                val f = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), name); f.writeBytes(bytes); f.absolutePath
            }
        } catch (e: Exception) { "error: " + (e.message ?: "") }
    }

    override fun onResume() {
        super.onResume()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        harp.startAudio()
        web.onResume()
    }

    override fun onPause() {
        harp.stopAudio()
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
