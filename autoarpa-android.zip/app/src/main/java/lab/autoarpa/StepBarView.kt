package lab.autoarpa

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

/** Barra de pasos del ejemplo: un tramo por paso (ancho = duración), cursor de tiempo; tocar un tramo salta a ese paso. */
class StepBarView(ctx: Context, private val harp: HarpView) : View(ctx) {
    private val dp = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10 * dp }
    private val segs = ArrayList<RectF>()

    override fun onDraw(c: Canvas) {
        val r = harp.runner ?: return
        val pl = r.plan
        val w = width - 12 * dp; val x0 = 6 * dp
        val cur = r.step(); val done = r.done()
        segs.clear()
        var x = x0
        pl.steps.forEachIndexed { i, s ->
            val sw = w * ((s.t1 - s.t0) / pl.duration).toFloat() - 3 * dp
            val rect = RectF(x, 2 * dp, x + sw, 10 * dp); segs.add(RectF(x, 0f, x + sw, height.toFloat()))
            p.color = if (done || i < cur) Color.parseColor("#5e8f80") else if (i == cur) Color.parseColor("#7cc4b0") else Color.parseColor("#3a3026")
            c.drawRoundRect(rect, 4 * dp, 4 * dp, p)
            txt.color = if (i == cur && !done) Color.parseColor("#7cc4b0") else Color.parseColor("#a8998a")
            txt.typeface = if (i == cur) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            val label = "${i + 1} ${s.title}"
            c.save(); c.clipRect(x, 0f, x + sw, height.toFloat()); c.drawText(label, x + 2 * dp, 22 * dp, txt); c.restore()
            x += sw + 3 * dp
        }
        p.color = Color.parseColor("#e0a35a")
        val cx = x0 + w * (r.t / pl.duration).toFloat()
        c.drawRect(cx - 1.5f * dp, 0f, cx + 1.5f * dp, 12 * dp, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            val i = segs.indexOfFirst { it.contains(e.x, e.y) }
            if (i >= 0) harp.exampleGoStep(i)
        }
        return true
    }
}
