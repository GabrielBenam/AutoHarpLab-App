package lab.autoarpa

import org.json.JSONArray
import org.json.JSONObject

/* Guion de la animación (generado y traducido por src/player.js) y su reproductor, equivalente a AH.player.Runner. */

class Step(val t0: Double, val t1: Double, val title: String, val text: String, val head: String, val hand: String)
class Ev(val t: Double, val type: String, val bars: IntArray, val s: Int, val vel: Float, val a: Int, val b: Int, val dur: Double)
class BarLane(val idx: Int, val label: String, val t0: Double, val t1: Double)
class RightLane(val type: String, val t0: Double, val t1: Double, val t: Double, val a: Int, val b: Int, val s: Int, val text: String)
class SoundLane(val t: Double, val text: String)

class Plan(
    val events: List<Ev>, val steps: List<Step>, val bars: List<BarLane>, val right: List<RightLane>,
    val sound: List<SoundLane>, val duration: Double, val result: String, val label: String
) {
    companion object {
        private fun ints(a: JSONArray?): IntArray = if (a == null) IntArray(0) else IntArray(a.length()) { a.getInt(it) }
        fun parse(json: String): Plan? = try {
            val o = JSONObject(json)
            val ev = ArrayList<Ev>()
            val ea = o.getJSONArray("events")
            for (i in 0 until ea.length()) {
                val e = ea.getJSONObject(i)
                ev.add(Ev(e.getDouble("t"), e.getString("type"), ints(e.optJSONArray("bars")), e.optInt("s", -1),
                    e.optDouble("vel", 0.75).toFloat(), e.optInt("a", 0), e.optInt("b", 0), e.optDouble("dur", 0.0)))
            }
            val steps = ArrayList<Step>()
            val sa = o.getJSONArray("steps")
            for (i in 0 until sa.length()) {
                val s = sa.getJSONObject(i)
                steps.add(Step(s.getDouble("t0"), s.getDouble("t1"), s.optString("title"), s.optString("text"), s.optString("head"), s.optString("hand")))
            }
            val lanes = o.getJSONObject("lanes")
            val bars = ArrayList<BarLane>()
            val ba = lanes.getJSONArray("bars")
            for (i in 0 until ba.length()) { val b = ba.getJSONObject(i); bars.add(BarLane(b.getInt("idx"), b.optString("label"), b.getDouble("t0"), b.getDouble("t1"))) }
            val right = ArrayList<RightLane>()
            val ra = lanes.getJSONArray("right")
            for (i in 0 until ra.length()) {
                val r = ra.getJSONObject(i)
                right.add(RightLane(r.getString("type"), r.optDouble("t0", 0.0), r.optDouble("t1", 0.0), r.optDouble("t", 0.0), r.optInt("a", 0), r.optInt("b", 0), r.optInt("s", -1), r.optString("text")))
            }
            val sound = ArrayList<SoundLane>()
            val so = lanes.getJSONArray("sound")
            for (i in 0 until so.length()) { val x = so.getJSONObject(i); sound.add(SoundLane(x.getDouble("t"), x.optString("text"))) }
            Plan(ev.sortedBy { it.t }, steps, bars, right, sound, o.getDouble("duration"), o.optString("result"), o.optString("label"))
        } catch (e: Exception) { null }
    }
}

interface RunnerHost {
    fun onPress(bars: List<Int>)
    fun onPluck(s: Int, vel: Float, delayMs: Double)
    fun onStop()
}

class Runner(val plan: Plan, private val host: RunnerHost) {
    companion object { val SPEEDS = doubleArrayOf(0.25, 0.5, 0.75, 1.0, 1.5, 2.0); const val LOOK = 40.0 }
    var t = 0.0; private set
    var playing = true
    var speed = 0.75; private set
    var stepMode = true
    var pressed: List<Int> = emptyList(); private set
    var sweep: Ev? = null; private set
    var focus: List<Ev> = emptyList(); private set
    private var next = 0

    init { apply(0.0) }

    fun stepAt(tt: Double): Int { var s = 0; plan.steps.forEachIndexed { i, st -> if (tt >= st.t0) s = i }; return s }
    fun step() = stepAt(t)
    fun done() = t >= plan.duration

    private fun apply(tt: Double) {
        val pr = plan.bars.filter { tt >= it.t0 && tt < it.t1 }.map { it.idx }
        if (pr != pressed) { pressed = pr; host.onPress(pr) }
        sweep = plan.events.firstOrNull { it.type == "sweep" && tt >= it.t && tt <= it.t + it.dur + 600 }
        focus = plan.events.filter { it.type == "focus" && tt >= it.t && tt <= it.t + it.dur }
    }

    /** Avanza dtReal ms reales. Devuelve true si cambió el paso o se pausó (hay que refrescar textos y botones). */
    fun tick(dtReal: Double): Boolean {
        if (!playing) { apply(t); return false }
        val before = step()
        var nt = t + dtReal * speed
        var paused = false
        if (stepMode && before < plan.steps.size - 1) {
            val lim = plan.steps[before].t1 - 1
            if (t < lim && nt >= lim) { nt = lim; paused = true }
        }
        if (nt >= plan.duration) { nt = plan.duration; paused = true }
        val ahead = nt + LOOK * speed
        val ev = plan.events
        while (next < ev.size && ev[next].t <= ahead && (!paused || ev[next].t <= nt)) {
            val e = ev[next++]
            if (e.type == "pluck") host.onPluck(e.s, e.vel, ((e.t - t) / speed).coerceAtLeast(0.0))
        }
        t = nt; apply(nt)
        if (paused) playing = false
        return paused || step() != before
    }

    fun seek(tt: Double) {
        t = tt.coerceIn(0.0, plan.duration)
        next = plan.events.indexOfFirst { it.t >= t }.let { if (it < 0) plan.events.size else it }
        host.onStop(); apply(t)
    }
    fun toggle() { if (!playing && done()) { seek(0.0); playing = true; return }; playing = !playing }
    fun goStep(i: Int) { val s = plan.steps[i.coerceIn(0, plan.steps.size - 1)]; seek(s.t0); playing = true }
    fun nextStep() { val i = step(); if (i >= plan.steps.size - 1) { seek(plan.steps[i].t0); playing = true } else goStep(i + 1) }
    fun prevStep() { val i = step(); goStep(if (t - plan.steps[i].t0 > 400) i else i - 1) }
    fun changeSpeed(dir: Int) { var k = SPEEDS.indexOfFirst { it == speed }; if (k < 0) k = 2; speed = SPEEDS[(k + dir).coerceIn(0, SPEEDS.size - 1)] }
    fun speedLabel(): String = (if (speed == Math.floor(speed)) speed.toInt().toString() else speed.toString()) + "×"
}
