/* Idiomas (es, en, pt, fr, de) y notación de acordes (letras, solfeo, alemana).
   Una sola tabla para escritorio, web y Android: la app Android recibe de aquí sus textos nativos.
   Los nombres internos de acordes siguen en letras (C, F#m7); solo cambia lo que se muestra y lo que se acepta al escribir. */
(function (g) {
  'use strict';
  const AH = g.AH = g.AH || {};
  const LANGS = ['es', 'en', 'pt', 'fr', 'de'];
  const LANG_NAMES = { es: 'Español', en: 'English', pt: 'Português', fr: 'Français', de: 'Deutsch' };

  /* clave: [es, en, pt, fr, de] */
  const K = {
    'app.title': ['Autoarpa Lab', 'Autoharp Lab', 'Autoharpa Lab', 'Autoharpe Lab', 'Autoharp Lab'],
    'hdr.layout': ['Layout', 'Layout', 'Layout', 'Disposition', 'Layout'],
    'hdr.open': ['Abrir', 'Open', 'Abrir', 'Ouvrir', 'Öffnen'],
    'hdr.save': ['Guardar', 'Save', 'Salvar', 'Enregistrer', 'Speichern'],
    'hdr.vol': ['Vol', 'Vol', 'Vol', 'Vol', 'Lautst.'],
    'hdr.theme': ['Tema', 'Theme', 'Tema', 'Thème', 'Design'],
    'hdr.close': ['Cerrar', 'Close', 'Fechar', 'Fermer', 'Schließen'],
    'hdr.ref': ['Referencia', 'Reference', 'Referência', 'Référence', 'Referenz'],
    'hdr.mine': ['Mis layouts', 'My layouts', 'Meus layouts', 'Mes dispositions', 'Meine Layouts'],
    'layout.os21': ['Oscar Schmidt 21 (fábrica)', 'Oscar Schmidt 21 (factory)', 'Oscar Schmidt 21 (fábrica)', 'Oscar Schmidt 21 (usine)', 'Oscar Schmidt 21 (Werk)'],
    'layout.unified21': ['Unified (Jo Ann Smith)', 'Unified (Jo Ann Smith)', 'Unified (Jo Ann Smith)', 'Unified (Jo Ann Smith)', 'Unified (Jo Ann Smith)'],
    'layout.folk21': ['Folk 21 (Harpers Guild + Smith)', 'Folk 21 (Harpers Guild + Smith)', 'Folk 21 (Harpers Guild + Smith)', 'Folk 21 (Harpers Guild + Smith)', 'Folk 21 (Harpers Guild + Smith)'],
    'layout.race15': ['Folk 15 (P. D. Race)', 'Folk 15 (P. D. Race)', 'Folk 15 (P. D. Race)', 'Folk 15 (P. D. Race)', 'Folk 15 (P. D. Race)'],
    'layout.std15': ['Estándar 15 (Berkshire)', 'Standard 15 (Berkshire)', 'Padrão 15 (Berkshire)', 'Standard 15 (Berkshire)', 'Standard 15 (Berkshire)'],
    'layout.app15': ['Appalachian 15', 'Appalachian 15', 'Appalachian 15', 'Appalachian 15', 'Appalachian 15'],
    'layout.std12': ['Estándar 12 (1898–1983)', 'Standard 12 (1898–1983)', 'Padrão 12 (1898–1983)', 'Standard 12 (1898–1983)', 'Standard 12 (1898–1983)'],

    'tab.play': ['Tocar', 'Play', 'Tocar', 'Jouer', 'Spielen'],
    'tab.search': ['Buscador', 'Chord finder', 'Buscador', 'Recherche', 'Akkordsuche'],
    'tab.coverage': ['Tabla de acordes', 'Chord table', 'Tabela de acordes', 'Tableau des accords', 'Akkordtabelle'],
    'tab.optimize': ['Optimizador', 'Optimizer', 'Otimizador', 'Optimiseur', 'Optimierer'],
    'tab.song': ['Canción', 'Song', 'Música', 'Chanson', 'Lied'],
    'tab.editor': ['Editor de barras', 'Bar editor', 'Editor de barras', 'Éditeur de barres', 'Leisten-Editor'],
    'tab.settings': ['Ajustes', 'Settings', 'Ajustes', 'Réglages', 'Einstellungen'],
    'tab.help': ['Ayuda', 'Help', 'Ajuda', 'Aide', 'Hilfe'],

    'play.bars': ['Botonera', 'Chord buttons', 'Botoneira', 'Boutons d’accords', 'Akkordtasten'],
    'play.barsHint': ['Clic o teclado · varias barras = intersección', 'Click or keyboard · several bars = intersection', 'Clique ou teclado · várias barras = interseção', 'Clic ou clavier · plusieurs barres = intersection', 'Klick oder Tastatur · mehrere Leisten = Schnittmenge'],
    'play.release': ['Soltar barras', 'Release bars', 'Soltar barras', 'Relâcher les barres', 'Leisten loslassen'],
    'play.latch': ['Mantener presionadas', 'Keep pressed', 'Manter pressionadas', 'Maintenir enfoncées', 'Gedrückt halten'],
    'play.pressSome': ['Presiona una o más barras', 'Press one or more bars', 'Pressione uma ou mais barras', 'Appuyez sur une ou plusieurs barres', 'Drücke eine oder mehrere Leisten'],
    'play.noBars': ['Sin barras: suenan las {n} cuerdas', 'No bars: all {n} strings sound', 'Sem barras: soam as {n} cordas', 'Sans barre : les {n} cordes sonnent', 'Ohne Leiste: alle {n} Saiten klingen'],
    'play.oneNote': ['una sola nota ({n})', 'a single note ({n})', 'uma única nota ({n})', 'une seule note ({n})', 'nur ein Ton ({n})'],
    'play.noString': ['ninguna cuerda suena', 'no string sounds', 'nenhuma corda soa', 'aucune corde ne sonne', 'keine Saite klingt'],
    'play.bassIn': ['bajo en {n}', 'bass on {n}', 'baixo em {n}', 'basse sur {n}', 'Bass auf {n}'],
    'play.notes': ['Notas: {list} · {n} cuerdas', 'Notes: {list} · {n} strings', 'Notas: {list} · {n} cordas', 'Notes : {list} · {n} cordes', 'Töne: {list} · {n} Saiten'],
    'play.strings': ['Encordado', 'Strings', 'Cordas', 'Cordes', 'Saiten'],
    'play.zone': ['Zona', 'Zone', 'Zona', 'Zone', 'Zone'],
    'play.speed': ['Velocidad', 'Speed', 'Velocidade', 'Vitesse', 'Tempo'],
    'play.strum': ['Rasguear (Espacio)', 'Strum (Space)', 'Rasguear (Espaço)', 'Gratter (Espace)', 'Streichen (Leertaste)'],
    'play.damp': ['Apagar (Esc)', 'Mute (Esc)', 'Abafar (Esc)', 'Étouffer (Échap)', 'Abdämpfen (Esc)'],
    'play.hint': ['Arrastra sobre las cuerdas para rasguear y haz clic en una cuerda para pulsarla. Al presionar una barra se apagan las cuerdas que vibraban bajo su fieltro.', 'Drag across the strings to strum and click a string to pluck it. Pressing a bar mutes the strings that were ringing under its felt.', 'Arraste sobre as cordas para rasguear e clique numa corda para tocá-la. Ao pressionar uma barra, as cordas sob o feltro se calam.', 'Glissez sur les cordes pour gratter et cliquez sur une corde pour la pincer. Appuyer sur une barre étouffe les cordes qui vibraient sous son feutre.', 'Über die Saiten ziehen zum Streichen, auf eine Saite klicken zum Zupfen. Eine gedrückte Leiste dämpft die Saiten unter ihrem Filz.'],

    'zone.full': ['Completo', 'Full', 'Completo', 'Complet', 'Vollständig'],
    'zone.nobass': ['Sin bajos', 'No bass', 'Sem graves', 'Sans basses', 'Ohne Bässe'],
    'zone.lowmid': ['Graves-medios', 'Low-mid', 'Graves-médios', 'Graves-médiums', 'Tief-Mitte'],
    'zone.mid': ['Medios', 'Middle', 'Médios', 'Médiums', 'Mitte'],
    'zone.high': ['Agudos', 'High', 'Agudos', 'Aigus', 'Hoch'],

    'cls.exacto': ['Exacto', 'Exact', 'Exato', 'Exact', 'Exakt'],
    'cls.funcional': ['Funcional', 'Functional', 'Funcional', 'Fonctionnel', 'Funktional'],
    'cls.sustituto': ['Sustituto', 'Substitute', 'Substituto', 'Substitut', 'Ersatz'],
    'cls.color': ['Color', 'Color', 'Cor', 'Couleur', 'Farbe'],
    'cls.none': ['Sin opción', 'No option', 'Sem opção', 'Aucune option', 'Keine Option'],

    'type.maj': ['Mayor', 'Major', 'Maior', 'Majeur', 'Dur'],
    'type.min': ['Menor', 'Minor', 'Menor', 'Mineur', 'Moll'],
    'type.7': ['Séptima dominante', 'Dominant seventh', 'Sétima dominante', 'Septième de dominante', 'Dominantseptakkord'],
    'type.m7': ['Menor séptima', 'Minor seventh', 'Menor com sétima', 'Mineur septième', 'Moll-Septakkord'],
    'type.maj7': ['Mayor séptima', 'Major seventh', 'Maior com sétima', 'Majeur septième', 'Major-Septakkord'],
    'type.6': ['Sexta', 'Sixth', 'Sexta', 'Sixte', 'Sextakkord'],
    'type.m6': ['Menor sexta', 'Minor sixth', 'Menor com sexta', 'Mineur sixte', 'Moll-Sextakkord'],
    'type.sus2': ['Suspendido 2', 'Suspended 2', 'Suspenso 2', 'Suspendu 2', 'Sus2'],
    'type.sus4': ['Suspendido 4', 'Suspended 4', 'Suspenso 4', 'Suspendu 4', 'Sus4'],
    'type.7sus4': ['Séptima sus4', 'Seventh sus4', 'Sétima sus4', 'Septième sus4', 'Septakkord sus4'],
    'type.add9': ['Add9', 'Add9', 'Add9', 'Add9', 'Add9'],
    'type.9': ['Novena', 'Ninth', 'Nona', 'Neuvième', 'Nonenakkord'],
    'type.dim': ['Disminuido (tríada)', 'Diminished (triad)', 'Diminuto (tríade)', 'Diminué (triade)', 'Vermindert (Dreiklang)'],
    'type.dim7': ['Disminuido séptima', 'Diminished seventh', 'Diminuto com sétima', 'Septième diminuée', 'Verminderter Septakkord'],
    'type.m7b5': ['Semidisminuido', 'Half-diminished', 'Meio-diminuto', 'Demi-diminué', 'Halbvermindert'],
    'type.aug': ['Aumentado', 'Augmented', 'Aumentado', 'Augmenté', 'Übermäßig'],
    'type.majShort': ['mayor', 'major', 'maior', 'majeur', 'Dur'],

    'search.title': ['¿Cómo toco este acorde?', 'How do I play this chord?', 'Como toco este acorde?', 'Comment jouer cet accord ?', 'Wie spiele ich diesen Akkord?'],
    'search.ph': ['Ej. {ex}', 'E.g. {ex}', 'Ex. {ex}', 'Ex. {ex}', 'z. B. {ex}'],
    'search.pinch': ['Permitir pinch (cuerdas pulsadas aparte)', 'Allow pinch (strings plucked separately)', 'Permitir pinch (cordas tocadas à parte)', 'Autoriser le pinch (cordes pincées à part)', 'Pinch erlauben (Saiten einzeln gezupft)'],
    'search.maxB': ['Máx. botones', 'Max. buttons', 'Máx. botões', 'Boutons max.', 'Max. Tasten'],
    'search.go': ['Buscar', 'Search', 'Buscar', 'Chercher', 'Suchen'],
    'search.order': ['Orden: parecido menos costo de ejecución (botones extra, zona, pinch, alcance de la mano, pocas cuerdas, bajo invertido).', 'Order: similarity minus playing cost (extra buttons, zone, pinch, hand reach, few strings, inverted bass).', 'Ordem: semelhança menos custo de execução (botões extras, zona, pinch, alcance da mão, poucas cordas, baixo invertido).', 'Ordre : ressemblance moins coût d’exécution (boutons en plus, zone, pinch, portée de la main, peu de cordes, basse renversée).', 'Reihenfolge: Ähnlichkeit minus Spielaufwand (zusätzliche Tasten, Zone, Pinch, Handreichweite, wenige Saiten, umgekehrter Bass).'],
    'search.bad': ['No reconozco ese acorde. Ejemplos: {ex}', 'I don’t recognize that chord. Examples: {ex}', 'Não reconheço esse acorde. Exemplos: {ex}', 'Je ne reconnais pas cet accord. Exemples : {ex}', 'Diesen Akkord kenne ich nicht. Beispiele: {ex}'],
    'search.none': ['Ninguna combinación se parece lo suficiente (menos de 35 %). Prueba el Optimizador para re-fieltrar una barra.', 'No combination is similar enough (below 35%). Try the Optimizer to re-felt a bar.', 'Nenhuma combinação é parecida o bastante (menos de 35 %). Experimente o Otimizador para refeltrar uma barra.', 'Aucune combinaison n’est assez proche (moins de 35 %). Essayez l’Optimiseur pour refeutrer une barre.', 'Keine Kombination ist ähnlich genug (unter 35 %). Versuche den Optimierer, um eine Leiste neu zu befilzen.'],
    'search.target': ['{chord} ({type}) · notas {notes} · layout: {layout}', '{chord} ({type}) · notes {notes} · layout: {layout}', '{chord} ({type}) · notas {notes} · layout: {layout}', '{chord} ({type}) · notes {notes} · disposition : {layout}', '{chord} ({type}) · Töne {notes} · Layout: {layout}'],
    'card.missing': ['faltan: {x}', 'missing: {x}', 'faltam: {x}', 'manquent : {x}', 'fehlen: {x}'],
    'card.foreign': ['ajenas: {x}', 'extra: {x}', 'estranhas: {x}', 'étrangères : {x}', 'fremd: {x}'],
    'card.inversion': ['inversión', 'inversion', 'inversão', 'renversement', 'Umkehrung'],
    'card.arp': ['arpegiado (pinch)', 'arpeggiated (pinch)', 'arpejado (pinch)', 'arpégé (pinch)', 'arpeggiert (Pinch)'],
    'card.exec': ['ejecución {d}', 'difficulty {d}', 'execução {d}', 'exécution {d}', 'Schwierigkeit {d}'],
    'diff.easy': ['fácil', 'easy', 'fácil', 'facile', 'leicht'],
    'diff.medium': ['media', 'medium', 'média', 'moyenne', 'mittel'],
    'diff.hard': ['difícil', 'hard', 'difícil', 'difficile', 'schwer'],
    'card.sound': ['Suenan: {notes} · {n} cuerdas', 'Sounding: {notes} · {n} strings', 'Soam: {notes} · {n} cordas', 'Sonnent : {notes} · {n} cordes', 'Es klingen: {notes} · {n} Saiten'],
    'card.anim': ['Ver animación', 'Watch animation', 'Ver animação', 'Voir l’animation', 'Animation ansehen'],
    'card.turn': ['Tu turno', 'Your turn', 'Sua vez', 'À vous', 'Du bist dran'],
    'card.listen': ['Escuchar', 'Listen', 'Ouvir', 'Écouter', 'Anhören'],
    'card.onboard': ['Ver en botonera', 'Show on buttons', 'Ver na botoneira', 'Voir sur les boutons', 'Auf den Tasten zeigen'],
    'card.back': ['← Tabla', '← Table', '← Tabela', '← Tableau', '← Tabelle'],
    'mech.bar': ['Barra', 'Bar', 'Barra', 'Barre', 'Leiste'],
    'mech.inter': ['Intersección', 'Intersection', 'Interseção', 'Intersection', 'Schnittmenge'],
    'mech.zone': ['Zona', 'Zone', 'Zona', 'Zone', 'Zone'],
    'mech.pinch': ['Pinch', 'Pinch', 'Pinch', 'Pinch', 'Pinch'],
    'desc.press': ['Presiona {bars}', 'Press {bars}', 'Pressione {bars}', 'Appuyez sur {bars}', 'Drücke {bars}'],
    'desc.strumAll': ['rasguea todo', 'strum all strings', 'rasgueie tudo', 'grattez tout', 'streiche alle Saiten'],
    'desc.strumZone': ['rasguea zona {zone} (cuerdas {a}–{b})', 'strum the {zone} zone (strings {a}–{b})', 'rasgueie a zona {zone} (cordas {a}–{b})', 'grattez la zone {zone} (cordes {a}–{b})', 'streiche die Zone {zone} (Saiten {a}–{b})'],
    'desc.pinch': ['suelta las barras y pulsa {list}', 'release the bars and pluck {list}', 'solte as barras e toque {list}', 'relâchez les barres et pincez {list}', 'lass die Leisten los und zupfe {list}'],
    'desc.str': ['{note} (cuerda {n})', '{note} (string {n})', '{note} (corda {n})', '{note} (corde {n})', '{note} (Saite {n})'],
    'w.and': [' y ', ' and ', ' e ', ' et ', ' und '],
    'toast.onboard': ['Barras presionadas (modo mantener).', 'Bars pressed (keep mode).', 'Barras pressionadas (modo manter).', 'Barres enfoncées (mode maintien).', 'Leisten gedrückt (Halten-Modus).'],
    'toast.pinch': ['Recuerda el pinch: {x}', 'Remember the pinch: {x}', 'Lembre do pinch: {x}', 'N’oubliez pas le pinch : {x}', 'Denk an den Pinch: {x}'],

    'cov.pinch': ['Incluir pinch', 'Include pinch', 'Incluir pinch', 'Inclure le pinch', 'Pinch einbeziehen'],
    'cov.go': ['Calcular', 'Calculate', 'Calcular', 'Calculer', 'Berechnen'],
    'cov.hint': ['Mejor parecido alcanzable para cada acorde con el layout actual. Toca una celda para ver cómo tocarlo.', 'Best similarity reachable for each chord with the current layout. Tap a cell to see how to play it.', 'Melhor semelhança alcançável para cada acorde com o layout atual. Toque numa célula para ver como tocá-lo.', 'Meilleure ressemblance atteignable pour chaque accord avec la disposition actuelle. Touchez une case pour voir comment le jouer.', 'Beste erreichbare Ähnlichkeit je Akkord mit dem aktuellen Layout. Tippe auf eine Zelle, um zu sehen, wie man ihn spielt.'],
    'kpi.exact': ['exactos de {n}', 'exact out of {n}', 'exatos de {n}', 'exacts sur {n}', 'exakt von {n}'],
    'kpi.func': ['exactos + funcionales', 'exact + functional', 'exatos + funcionais', 'exacts + fonctionnels', 'exakt + funktional'],
    'kpi.avg': ['parecido medio', 'average similarity', 'semelhança média', 'ressemblance moyenne', 'mittlere Ähnlichkeit'],
    'kpi.bars': ['barras', 'bars', 'barras', 'barres', 'Leisten'],
    'leg.func': ['Funcional ≥85%', 'Functional ≥85%', 'Funcional ≥85%', 'Fonctionnel ≥85 %', 'Funktional ≥85 %'],
    'leg.sub': ['Sustituto ≥70%', 'Substitute ≥70%', 'Substituto ≥70%', 'Substitut ≥70 %', 'Ersatz ≥70 %'],
    'leg.col': ['Color <70%', 'Color <70%', 'Cor <70%', 'Couleur <70 %', 'Farbe <70 %'],

    'opt.title': ['Optimizador de re-fieltrado', 'Re-felting optimizer', 'Otimizador de refeltragem', 'Optimiseur de refeutrage', 'Umbefilzungs-Optimierer'],
    'opt.hint': ['Escribe los acordes de tus canciones (repetidos o con peso, ej. A:4 E:3 F#m:2 Bm). El optimizador propone qué barras re-fieltrar para cubrirlos mejor, sin tocar las barras bloqueadas ni las que tu repertorio ya usa.', 'Type the chords of your songs (repeated or weighted, e.g. A:4 E:3 F#m:2 Bm). The optimizer suggests which bars to re-felt to cover them better, without touching locked bars or bars your repertoire already uses.', 'Escreva os acordes das suas músicas (repetidos ou com peso, ex. A:4 E:3 F#m:2 Bm). O otimizador propõe quais barras refeltrar para cobri-los melhor, sem mexer nas barras bloqueadas nem nas que o repertório já usa.', 'Saisissez les accords de vos chansons (répétés ou pondérés, ex. A:4 E:3 F#m:2 Bm). L’optimiseur propose quelles barres refeutrer pour mieux les couvrir, sans toucher aux barres verrouillées ni à celles que votre répertoire utilise déjà.', 'Gib die Akkorde deiner Lieder ein (wiederholt oder gewichtet, z. B. A:4 E:3 F#m:2 Bm). Der Optimierer schlägt vor, welche Leisten neu befilzt werden, ohne gesperrte oder bereits genutzte Leisten zu ändern.'],
    'opt.steps': ['Barras a cambiar', 'Bars to change', 'Barras a mudar', 'Barres à changer', 'Zu ändernde Leisten'],
    'opt.locked': ['Bloqueadas', 'Locked', 'Bloqueadas', 'Verrouillées', 'Gesperrt'],
    'opt.go': ['Optimizar', 'Optimize', 'Otimizar', 'Optimiser', 'Optimieren'],
    'opt.apply': ['Usar layout propuesto', 'Use proposed layout', 'Usar layout proposto', 'Utiliser la disposition proposée', 'Vorgeschlagenes Layout verwenden'],
    'opt.calc': ['Calculando…', 'Calculating…', 'Calculando…', 'Calcul…', 'Berechne…'],
    'opt.ignored': ['Ignorados: {x}', 'Ignored: {x}', 'Ignorados: {x}', 'Ignorés : {x}', 'Ignoriert: {x}'],
    'opt.empty': ['Escribe al menos un acorde.', 'Type at least one chord.', 'Escreva pelo menos um acorde.', 'Saisissez au moins un accord.', 'Gib mindestens einen Akkord ein.'],
    'opt.cover': ['cobertura del repertorio', 'repertoire coverage', 'cobertura do repertório', 'couverture du répertoire', 'Repertoire-Abdeckung'],
    'opt.change': ['Re-fieltrar <b>{from}</b> (fila {r}, pos. {c}) como <b>{to}</b> · +{gain}', 'Re-felt <b>{from}</b> (row {r}, pos. {c}) as <b>{to}</b> · +{gain}', 'Refeltrar <b>{from}</b> (fila {r}, pos. {c}) como <b>{to}</b> · +{gain}', 'Refeutrer <b>{from}</b> (rangée {r}, pos. {c}) en <b>{to}</b> · +{gain}', '<b>{from}</b> (Reihe {r}, Pos. {c}) neu befilzen als <b>{to}</b> · +{gain}'],
    'opt.noChange': ['Ningún cambio mejora la cobertura: el layout ya cubre bien este repertorio o las barras útiles están bloqueadas.', 'No change improves coverage: the layout already covers this repertoire well or the useful bars are locked.', 'Nenhuma mudança melhora a cobertura: o layout já cobre bem este repertório ou as barras úteis estão bloqueadas.', 'Aucun changement n’améliore la couverture : la disposition couvre déjà bien ce répertoire ou les barres utiles sont verrouillées.', 'Keine Änderung verbessert die Abdeckung: Das Layout deckt das Repertoire schon gut ab oder die nützlichen Leisten sind gesperrt.'],
    'opt.thChord': ['Acorde', 'Chord', 'Acorde', 'Accord', 'Akkord'],
    'opt.thW': ['Peso', 'Weight', 'Peso', 'Poids', 'Gewicht'],
    'opt.thBefore': ['Antes', 'Before', 'Antes', 'Avant', 'Vorher'],
    'opt.thAfter': ['Después', 'After', 'Depois', 'Après', 'Nachher'],
    'opt.thHow': ['Cómo (después)', 'How (after)', 'Como (depois)', 'Comment (après)', 'Wie (nachher)'],
    'opt.applied': ['Layout propuesto cargado y guardado en «Mis layouts»', 'Proposed layout loaded and saved in “My layouts”', 'Layout proposto carregado e salvo em «Meus layouts»', 'Disposition proposée chargée et enregistrée dans « Mes dispositions »', 'Vorgeschlagenes Layout geladen und unter „Meine Layouts“ gespeichert'],
    'felt.title': ['Cómo fieltrar: {from} → {to}', 'How to felt: {from} → {to}', 'Como feltrar: {from} → {to}', 'Comment feutrer : {from} → {to}', 'Befilzen: {from} → {to}'],
    'felt.before': ['Antes', 'Before', 'Antes', 'Avant', 'Vorher'],
    'felt.after': ['Después', 'After', 'Depois', 'Après', 'Nachher'],
    'felt.cut': ['corta muesca: la cuerda debe sonar', 'cut a notch: the string must sound', 'corte o entalhe: a corda deve soar', 'entaillez : la corde doit sonner', 'Kerbe schneiden: Saite soll klingen'],
    'felt.fill': ['cubre con fieltro: la cuerda debe callar', 'fill with felt: the string must be silent', 'cubra com feltro: a corda deve calar', 'couvrez de feutre : la corde doit se taire', 'mit Filz schließen: Saite soll schweigen'],
    'felt.cutList': ['Cortar muesca en las cuerdas: {x}', 'Cut a notch at strings: {x}', 'Cortar entalhe nas cordas: {x}', 'Entailler aux cordes : {x}', 'Kerben schneiden bei Saiten: {x}'],
    'felt.fillList': ['Cubrir con fieltro las cuerdas: {x}', 'Fill with felt at strings: {x}', 'Cobrir com feltro as cordas: {x}', 'Couvrir de feutre les cordes : {x}', 'Mit Filz schließen bei Saiten: {x}'],
    'felt.legend': ['Vista desde arriba. La franja es el fieltro; cada hueco (muesca) deja sonar la cuerda que pasa por él.', 'Top view. The strip is the felt; each gap (notch) lets the string under it sound.', 'Vista de cima. A faixa é o feltro; cada vão (entalhe) deixa soar a corda que passa por ele.', 'Vue de dessus. La bande est le feutre ; chaque entaille laisse sonner la corde qui passe dessous.', 'Ansicht von oben. Der Streifen ist der Filz; jede Kerbe lässt die Saite darunter klingen.'],
    'felt.download': ['Descargar imagen', 'Download image', 'Baixar imagem', 'Télécharger l’image', 'Bild herunterladen'],
    'felt.sheet': ['Hoja de fieltrado completa', 'Full felting sheet', 'Folha de feltragem completa', 'Feuille de feutrage complète', 'Vollständiger Befilzungsplan'],
    'felt.sheetTitle': ['Hoja de fieltrado · {layout}', 'Felting sheet · {layout}', 'Folha de feltragem · {layout}', 'Feuille de feutrage · {layout}', 'Befilzungsplan · {layout}'],
    'felt.saved': ['Imagen guardada: {x}', 'Image saved: {x}', 'Imagem salva: {x}', 'Image enregistrée : {x}', 'Bild gespeichert: {x}'],
    'felt.string': ['cuerda', 'string', 'corda', 'corde', 'Saite'],

    'arr.title': ['Reacomodo de botones', 'Button rearrangement', 'Reorganização de botões', 'Réorganisation des boutons', 'Tasten neu anordnen'],
    'arr.hint': ['Mueve las barras entre posiciones sin re-fieltrar. Escribe tus progresiones en orden, una canción por línea. Minimiza el recorrido de la mano, junta las barras que se presionan a la vez, aleja de los extremos las más usadas y premia el patrón de Smith: quintas de izquierda a derecha, relativo menor debajo del mayor y V7 junto al I.', 'Moves bars between slots without re-felting. Type your progressions in order, one song per line. It minimizes hand travel, keeps bars pressed together close, keeps the most used bars away from the ends and rewards Smith’s pattern: fifths left to right, relative minor below the major and V7 next to I.', 'Move as barras entre posições sem refeltrar. Escreva as progressões em ordem, uma música por linha. Minimiza o percurso da mão, aproxima as barras pressionadas juntas, afasta das pontas as mais usadas e premia o padrão de Smith: quintas da esquerda para a direita, relativo menor abaixo do maior e V7 junto ao I.', 'Déplace les barres sans refeutrer. Saisissez vos progressions dans l’ordre, une chanson par ligne. Minimise le trajet de la main, rapproche les barres pressées ensemble, éloigne des bords les plus utilisées et favorise le schéma de Smith : quintes de gauche à droite, relatif mineur sous le majeur et V7 près du I.', 'Verschiebt Leisten ohne Umbefilzen. Gib deine Folgen der Reihe nach ein, ein Lied pro Zeile. Minimiert Handwege, hält gemeinsam gedrückte Leisten zusammen, hält oft genutzte von den Rändern fern und belohnt Smiths Muster: Quinten von links nach rechts, Paralleltonart unter Dur, V7 neben I.'],
    'arr.rows': ['Solo mover dentro de cada fila (conserva filas de mayores, séptimas y menores)', 'Only move within each row (keeps major, seventh and minor rows)', 'Mover só dentro de cada fila (mantém filas de maiores, sétimas e menores)', 'Ne déplacer que dans chaque rangée (garde les rangées majeurs, septièmes, mineurs)', 'Nur innerhalb der Reihe verschieben (behält Dur-, Sept- und Moll-Reihen)'],
    'arr.fixed': ['Fijas', 'Fixed', 'Fixas', 'Fixes', 'Fest'],
    'arr.go': ['Reacomodar', 'Rearrange', 'Reorganizar', 'Réorganiser', 'Neu anordnen'],
    'arr.apply': ['Usar layout reacomodado', 'Use rearranged layout', 'Usar layout reorganizado', 'Utiliser la disposition réorganisée', 'Neu angeordnetes Layout verwenden'],
    'arr.moved': ['{n} barras movidas', '{n} bars moved', '{n} barras movidas', '{n} barres déplacées', '{n} Leisten verschoben'],
    'arr.ind': ['Indicador', 'Indicator', 'Indicador', 'Indicateur', 'Kennzahl'],
    'arr.travel': ['Recorrido medio de la mano por cambio (botones)', 'Average hand travel per change (buttons)', 'Percurso médio da mão por troca (botões)', 'Trajet moyen de la main par changement (boutons)', 'Mittlerer Handweg pro Wechsel (Tasten)'],
    'arr.near': ['Cambios a un botón vecino', 'Changes to a neighbouring button', 'Trocas para um botão vizinho', 'Changements vers un bouton voisin', 'Wechsel zur Nachbartaste'],
    'arr.harm': ['Patrón armónico de Smith cumplido', 'Smith harmonic pattern met', 'Padrão harmônico de Smith cumprido', 'Schéma harmonique de Smith respecté', 'Smiths harmonisches Muster erfüllt'],
    'arr.keys': ['Tonalidades con IV-I-V contiguos', 'Keys with adjacent IV-I-V', 'Tonalidades com IV-I-V contíguos', 'Tonalités avec IV-I-V contigus', 'Tonarten mit benachbartem IV-I-V'],
    'arr.missing': ['Sin forma de tocar (≥70 %) con este layout, no cuentan: {x}. Usa primero el optimizador de re-fieltrado.', 'No way to play (≥70%) with this layout, not counted: {x}. Use the re-felting optimizer first.', 'Sem forma de tocar (≥70 %) com este layout, não contam: {x}. Use antes o otimizador de refeltragem.', 'Impossible à jouer (≥70 %) avec cette disposition, non comptés : {x}. Utilisez d’abord l’optimiseur de refeutrage.', 'Mit diesem Layout nicht spielbar (≥70 %), nicht gezählt: {x}. Nutze zuerst den Umbefilzungs-Optimierer.'],
    'arr.moves': ['Movimientos: {x}', 'Moves: {x}', 'Movimentos: {x}', 'Déplacements : {x}', 'Verschiebungen: {x}'],
    'arr.move': ['{label} (fila {r1}, pos. {c1} → fila {r2}, pos. {c2})', '{label} (row {r1}, pos. {c1} → row {r2}, pos. {c2})', '{label} (fila {r1}, pos. {c1} → fila {r2}, pos. {c2})', '{label} (rangée {r1}, pos. {c1} → rangée {r2}, pos. {c2})', '{label} (Reihe {r1}, Pos. {c1} → Reihe {r2}, Pos. {c2})'],
    'arr.applied': ['Layout reacomodado cargado y guardado en «Mis layouts»', 'Rearranged layout loaded and saved in “My layouts”', 'Layout reorganizado carregado e salvo em «Meus layouts»', 'Disposition réorganisée chargée et enregistrée dans « Mes dispositions »', 'Neu angeordnetes Layout geladen und unter „Meine Layouts“ gespeichert'],

    'ed.title': ['Editor de barras', 'Bar editor', 'Editor de barras', 'Éditeur de barres', 'Leisten-Editor'],
    'ed.hint': ['Selecciona una barra en la botonera de abajo', 'Select a bar in the buttons below', 'Selecione uma barra na botoneira abaixo', 'Sélectionnez une barre ci-dessous', 'Wähle unten eine Leiste'],
    'ed.label': ['Etiqueta', 'Label', 'Rótulo', 'Étiquette', 'Beschriftung'],
    'ed.fromChord': ['Fieltrar según etiqueta', 'Felt from label', 'Feltrar pelo rótulo', 'Feutrer selon l’étiquette', 'Nach Beschriftung befilzen'],
    'ed.add': ['+ Barra en fila', '+ Bar in row', '+ Barra na fila', '+ Barre dans la rangée', '+ Leiste in Reihe'],
    'ed.del': ['Eliminar barra', 'Delete bar', 'Excluir barra', 'Supprimer la barre', 'Leiste löschen'],
    'ed.up': ['▲ fila', '▲ row', '▲ fila', '▲ rangée', '▲ Reihe'],
    'ed.down': ['▼ fila', '▼ row', '▼ fila', '▼ rangée', '▼ Reihe'],
    'ed.hear': ['Escuchar', 'Listen', 'Ouvir', 'Écouter', 'Anhören'],
    'ed.cells': ['Cada casilla es una cuerda: encendida = suena (muesca en el fieltro), apagada = fieltro.', 'Each cell is a string: lit = sounds (notch in the felt), dark = felt.', 'Cada casa é uma corda: acesa = soa (entalhe no feltro), apagada = feltro.', 'Chaque case est une corde : allumée = sonne (entaille), éteinte = feutre.', 'Jedes Feld ist eine Saite: hell = klingt (Kerbe im Filz), dunkel = Filz.'],
    'ed.name': ['Nombre del layout', 'Layout name', 'Nome do layout', 'Nom de la disposition', 'Layout-Name'],
    'ed.save': ['Guardar como layout propio', 'Save as my layout', 'Salvar como layout próprio', 'Enregistrer comme ma disposition', 'Als eigenes Layout speichern'],
    'ed.delLayout': ['Borrar layout propio', 'Delete my layout', 'Apagar layout próprio', 'Supprimer ma disposition', 'Eigenes Layout löschen'],
    'ed.soundsLike': ['Suena como: {x} · {n} cuerdas · origen: {src}', 'Sounds like: {x} · {n} strings · source: {src}', 'Soa como: {x} · {n} cordas · origem: {src}', 'Sonne comme : {x} · {n} cordes · origine : {src}', 'Klingt wie: {x} · {n} Saiten · Herkunft: {src}'],
    'ed.empty': ['Barra sin cuerdas libres.', 'Bar with no open strings.', 'Barra sem cordas livres.', 'Barre sans corde libre.', 'Leiste ohne freie Saiten.'],
    'ed.select': ['Selecciona una barra.', 'Select a bar.', 'Selecione uma barra.', 'Sélectionnez une barre.', 'Wähle eine Leiste.'],
    'ed.badChord': ['Etiqueta no reconocida como acorde', 'Label not recognized as a chord', 'Rótulo não reconhecido como acorde', 'Étiquette non reconnue comme accord', 'Beschriftung ist kein bekannter Akkord'],
    'ed.saved': ['Layout guardado: {x}', 'Layout saved: {x}', 'Layout salvo: {x}', 'Disposition enregistrée : {x}', 'Layout gespeichert: {x}'],
    'ed.onlyOwn': ['Solo se pueden borrar layouts propios', 'Only your own layouts can be deleted', 'Só é possível apagar layouts próprios', 'Seules vos dispositions peuvent être supprimées', 'Nur eigene Layouts können gelöscht werden'],
    'ed.deleted': ['Layout borrado', 'Layout deleted', 'Layout apagado', 'Disposition supprimée', 'Layout gelöscht'],
    'ed.imported': ['Layout importado', 'Layout imported', 'Layout importado', 'Disposition importée', 'Layout importiert'],
    'ed.badFile': ['Archivo no válido: {x}', 'Invalid file: {x}', 'Arquivo inválido: {x}', 'Fichier non valide : {x}', 'Ungültige Datei: {x}'],
    'ed.cantSave': ['No se pudo guardar en este navegador; usa «Guardar» para exportar.', 'Could not save in this browser; use “Save” to export.', 'Não foi possível salvar neste navegador; use «Salvar» para exportar.', 'Impossible d’enregistrer dans ce navigateur ; utilisez « Enregistrer » pour exporter.', 'Speichern im Browser nicht möglich; nutze „Speichern“ zum Exportieren.'],
    'src.real': ['real documentado', 'documented real', 'real documentado', 'réel documenté', 'real dokumentiert'],
    'src.generado': ['generado', 'generated', 'gerado', 'généré', 'generiert'],
    'src.custom': ['personalizado', 'custom', 'personalizado', 'personnalisé', 'eigen'],
    'src.propuesta': ['propuesta', 'proposal', 'proposta', 'proposition', 'Vorschlag'],
    'src.realTip': ['Fieltrado real documentado', 'Documented real felting', 'Feltragem real documentada', 'Feutrage réel documenté', 'Dokumentierte echte Befilzung'],
    'src.genTip': ['Fieltrado generado por notas del acorde', 'Felting generated from the chord notes', 'Feltragem gerada pelas notas do acorde', 'Feutrage généré d’après les notes', 'Aus den Akkordtönen erzeugte Befilzung'],
    'src.cusTip': ['Barra personalizada', 'Custom bar', 'Barra personalizada', 'Barre personnalisée', 'Eigene Leiste'],

    'song.title': ['Modo canción', 'Song mode', 'Modo música', 'Mode chanson', 'Liedmodus'],
    'song.hint': ['Escribe los acordes de la canción en orden, separados por espacios o renglones. Al tocar, la app marca la barra actual y la siguiente, y avanza sola cuando rasgueas con las barras correctas.', 'Type the song’s chords in order, separated by spaces or lines. While playing, the app marks the current and next bars and moves on by itself when you strum with the right bars.', 'Escreva os acordes da música em ordem, separados por espaços ou linhas. Ao tocar, o app marca a barra atual e a seguinte, e avança sozinho quando você rasgueia com as barras certas.', 'Saisissez les accords de la chanson dans l’ordre, séparés par des espaces ou des lignes. Pendant le jeu, l’appli marque la barre actuelle et la suivante, et avance seule quand vous grattez avec les bonnes barres.', 'Gib die Akkorde des Liedes der Reihe nach ein, getrennt durch Leerzeichen oder Zeilen. Beim Spielen markiert die App die aktuelle und die nächste Leiste und geht von selbst weiter, wenn du mit den richtigen Leisten streichst.'],
    'song.name': ['Nombre', 'Name', 'Nome', 'Nom', 'Name'],
    'song.defaultName': ['Mi canción', 'My song', 'Minha música', 'Ma chanson', 'Mein Lied'],
    'song.save': ['Guardar canción', 'Save song', 'Salvar música', 'Enregistrer la chanson', 'Lied speichern'],
    'song.play': ['Tocar canción', 'Play song', 'Tocar música', 'Jouer la chanson', 'Lied spielen'],
    'song.list': ['Mis canciones', 'My songs', 'Minhas músicas', 'Mes chansons', 'Meine Lieder'],
    'song.open': ['Abrir', 'Open', 'Abrir', 'Ouvrir', 'Öffnen'],
    'song.del': ['Borrar', 'Delete', 'Apagar', 'Supprimer', 'Löschen'],
    'song.arrange': ['Reacomodar botones para esta canción', 'Rearrange buttons for this song', 'Reorganizar botões para esta música', 'Réorganiser les boutons pour cette chanson', 'Tasten für dieses Lied neu anordnen'],
    'song.unplayable': ['sin forma ≥70 %', 'no way ≥70%', 'sem forma ≥70 %', 'aucune forme ≥70 %', 'keine Form ≥70 %'],
    'song.auto': ['Avanzar solo al rasguear', 'Advance when I strum', 'Avançar ao rasguear', 'Avancer en grattant', 'Beim Streichen weiter'],
    'song.bar': ['{name} · {i} de {n}', '{name} · {i} of {n}', '{name} · {i} de {n}', '{name} · {i} sur {n}', '{name} · {i} von {n}'],
    'song.next': ['Siguiente: {x}', 'Next: {x}', 'Próximo: {x}', 'Suivant : {x}', 'Als Nächstes: {x}'],
    'song.done': ['Fin de la canción.', 'End of the song.', 'Fim da música.', 'Fin de la chanson.', 'Ende des Liedes.'],
    'song.empty': ['Escribe al menos un acorde reconocible.', 'Type at least one recognizable chord.', 'Escreva pelo menos um acorde reconhecível.', 'Saisissez au moins un accord reconnaissable.', 'Gib mindestens einen erkennbaren Akkord ein.'],
    'song.saved': ['Canción guardada', 'Song saved', 'Música salva', 'Chanson enregistrée', 'Lied gespeichert'],
    'song.preview': ['Cómo se tocará', 'How it will be played', 'Como será tocada', 'Comment elle sera jouée', 'So wird es gespielt'],

    'an.prev': ['Anterior', 'Previous', 'Anterior', 'Précédent', 'Zurück'],
    'an.next': ['Siguiente', 'Next', 'Próximo', 'Suivant', 'Weiter'],
    'an.play': ['Play', 'Play', 'Play', 'Lecture', 'Start'],
    'an.pause': ['Pausa', 'Pause', 'Pausa', 'Pause', 'Pause'],
    'an.repeat': ['Repetir', 'Replay', 'Repetir', 'Rejouer', 'Wiederholen'],
    'an.stepMode': ['Paso a paso', 'Step by step', 'Passo a passo', 'Pas à pas', 'Schritt für Schritt'],
    'an.timeline': ['Línea de tiempo', 'Timeline', 'Linha do tempo', 'Chronologie', 'Zeitleiste'],
    'an.close': ['Cerrar', 'Close', 'Fechar', 'Fermer', 'Schließen'],
    'an.stepOf': ['Paso {i} de {n}', 'Step {i} of {n}', 'Passo {i} de {n}', 'Étape {i} sur {n}', 'Schritt {i} von {n}'],
    'an.speed': ['Velocidad', 'Speed', 'Velocidade', 'Vitesse', 'Tempo'],
    'an.bar': ['Barra {b}', 'Bar {b}', 'Barra {b}', 'Barre {b}', 'Leiste {b}'],
    'an.pressed': ['presiona', 'press', 'pressiona', 'appuyer', 'drücken'],
    'an.released': ['suelta', 'release', 'solta', 'relâcher', 'loslassen'],
    'an.strumLane': ['rasguea {a} → {b}', 'strum {a} → {b}', 'rasgueia {a} → {b}', 'gratter {a} → {b}', 'streichen {a} → {b}'],
    'an.pinchLane': ['pulsa {n} ({note})', 'pluck {n} ({note})', 'toca {n} ({note})', 'pincer {n} ({note})', 'zupfen {n} ({note})'],
    'an.strings': ['Cuerdas', 'Strings', 'Cordas', 'Cordes', 'Saiten'],
    'an.sound': ['Suena', 'Sounds', 'Soa', 'Son', 'Klang'],
    'an.ringing': ['siguen sonando', 'still ringing', 'continuam soando', 'continuent de sonner', 'klingen weiter'],
    'an.seekHint': ['Toca la línea para ir a ese momento.', 'Tap the timeline to jump to that moment.', 'Toque a linha para ir a esse momento.', 'Touchez la ligne pour aller à cet instant.', 'Tippe auf die Zeitleiste, um dorthin zu springen.'],
    'an.result': ['Resultado: {chord} al {pct} % ({cls}){arp}.', 'Result: {chord} at {pct}% ({cls}){arp}.', 'Resultado: {chord} a {pct} % ({cls}){arp}.', 'Résultat : {chord} à {pct} % ({cls}){arp}.', 'Ergebnis: {chord} zu {pct} % ({cls}){arp}.'],
    'an.arp': [', arpegiado', ', arpeggiated', ', arpejado', ', arpégé', ', arpeggiert'],
    'hand.left': ['Mano izquierda', 'Left hand', 'Mão esquerda', 'Main gauche', 'Linke Hand'],
    'hand.right': ['Mano derecha', 'Right hand', 'Mão direita', 'Main droite', 'Rechte Hand'],
    'st.press': ['Presionar', 'Press', 'Pressionar', 'Appuyer', 'Drücken'],
    'st.strum': ['Rasguear', 'Strum', 'Rasguear', 'Gratter', 'Streichen'],
    'st.release': ['Soltar', 'Release', 'Soltar', 'Relâcher', 'Loslassen'],
    'st.pinch': ['Pulsar', 'Pluck', 'Tocar', 'Pincer', 'Zupfen'],
    'sx.press1': ['{hand}: mantén presionada la barra {b}.', '{hand}: hold down the {b} bar.', '{hand}: mantenha pressionada a barra {b}.', '{hand} : maintenez la barre {b} enfoncée.', '{hand}: halte die Leiste {b} gedrückt.'],
    'sx.pressN': ['{hand}: mantén presionadas a la vez {list}, un dedo en cada una. Solo suenan las cuerdas libres en todas (intersección).', '{hand}: hold {list} down together, one finger on each. Only strings open in all of them sound (intersection).', '{hand}: mantenha {list} pressionadas ao mesmo tempo, um dedo em cada. Só soam as cordas livres em todas (interseção).', '{hand} : maintenez {list} ensemble, un doigt sur chacune. Seules les cordes libres dans toutes sonnent (intersection).', '{hand}: halte {list} gleichzeitig gedrückt, je ein Finger. Nur Saiten, die in allen frei sind, klingen (Schnittmenge).'],
    'sx.strumAll': ['{hand}: rasguea de grave a agudo todo el encordado. Las cuerdas grises no suenan: las tapa el fieltro.', '{hand}: strum from low to high across all strings. Grey strings don’t sound: the felt covers them.', '{hand}: rasgueie do grave ao agudo por todas as cordas. As cordas cinzas não soam: o feltro as cobre.', '{hand} : grattez du grave à l’aigu sur toutes les cordes. Les cordes grises ne sonnent pas : le feutre les couvre.', '{hand}: streiche von tief nach hoch über alle Saiten. Graue Saiten klingen nicht: der Filz deckt sie ab.'],
    'sx.strumZone': ['{hand}: rasguea de grave a agudo solo de la cuerda {a} ({na}) a la {b} ({nb}). Las grises no suenan: las tapa el fieltro.', '{hand}: strum from low to high only from string {a} ({na}) to {b} ({nb}). Grey strings don’t sound: the felt covers them.', '{hand}: rasgueie do grave ao agudo só da corda {a} ({na}) à {b} ({nb}). As cinzas não soam: o feltro as cobre.', '{hand} : grattez du grave à l’aigu seulement de la corde {a} ({na}) à la {b} ({nb}). Les grises ne sonnent pas : le feutre les couvre.', '{hand}: streiche von tief nach hoch nur von Saite {a} ({na}) bis {b} ({nb}). Graue Saiten klingen nicht: der Filz deckt sie ab.'],
    'sx.release': ['{hand}: suelta todas las barras. Lo que ya vibra sigue sonando.', '{hand}: release all bars. What is already ringing keeps sounding.', '{hand}: solte todas as barras. O que já vibra continua soando.', '{hand} : relâchez toutes les barres. Ce qui vibre continue de sonner.', '{hand}: lass alle Leisten los. Was schon schwingt, klingt weiter.'],
    'sx.pinch1': ['{hand}: sin barras, pulsa con un dedo la cuerda {n} ({note}).', '{hand}: with no bars, pluck string {n} ({note}) with one finger.', '{hand}: sem barras, toque com um dedo a corda {n} ({note}).', '{hand} : sans barre, pincez d’un doigt la corde {n} ({note}).', '{hand}: ohne Leiste zupfe mit einem Finger Saite {n} ({note}).'],
    'sx.pinchN': ['{hand}: sin barras, pulsa con un dedo la cuerda {n} ({note}) y después {list}.', '{hand}: with no bars, pluck string {n} ({note}) with one finger, then {list}.', '{hand}: sem barras, toque a corda {n} ({note}) e depois {list}.', '{hand} : sans barre, pincez la corde {n} ({note}) puis {list}.', '{hand}: ohne Leiste zupfe Saite {n} ({note}), danach {list}.'],

    'pr.title': ['Tu turno: {chord}', 'Your turn: {chord}', 'Sua vez: {chord}', 'À vous : {chord}', 'Du bist dran: {chord}'],
    'pr.do': ['Hazlo tú: {how}. Te escucho.', 'Your go: {how}. I’m listening.', 'Faça você: {how}. Estou ouvindo.', 'À vous : {how}. J’écoute.', 'Jetzt du: {how}. Ich höre zu.'],
    'pr.again': ['Otra vez', 'Again', 'De novo', 'Encore', 'Nochmal'],
    'pr.example': ['Ver ejemplo', 'Watch example', 'Ver exemplo', 'Voir l’exemple', 'Beispiel ansehen'],
    'pr.hints': ['Pistas', 'Hints', 'Dicas', 'Indices', 'Hinweise'],
    'pr.barsOk': ['Barras correctas.', 'Right bars.', 'Barras corretas.', 'Bonnes barres.', 'Richtige Leisten.'],
    'pr.barsMissing': ['Te faltó presionar: {x}.', 'You didn’t press: {x}.', 'Faltou pressionar: {x}.', 'Il manquait : {x}.', 'Nicht gedrückt: {x}.'],
    'pr.barsExtra': ['Sobró: {x}.', 'Not needed: {x}.', 'Sobrou: {x}.', 'En trop : {x}.', 'Zu viel: {x}.'],
    'pr.noBars': ['No presionaste ninguna barra al rasguear.', 'You didn’t press any bar while strumming.', 'Você não pressionou nenhuma barra ao rasguear.', 'Aucune barre enfoncée pendant le grattage.', 'Beim Streichen war keine Leiste gedrückt.'],
    'pr.strumOk': ['Rasgueo en la zona correcta.', 'Strum in the right zone.', 'Rasgueado na zona correta.', 'Grattage dans la bonne zone.', 'Strich in der richtigen Zone.'],
    'pr.strumShort': ['No llegaste a las cuerdas {x}.', 'You missed strings {x}.', 'Não chegou às cordas {x}.', 'Cordes non atteintes : {x}.', 'Saiten nicht erreicht: {x}.'],
    'pr.strumExtra': ['También sonaron cuerdas fuera de la zona: {x}.', 'Strings outside the zone also sounded: {x}.', 'Soaram cordas fora da zona: {x}.', 'Des cordes hors zone ont sonné : {x}.', 'Auch Saiten außerhalb der Zone klangen: {x}.'],
    'pr.pinchOk': ['Pinch correcto.', 'Right pinch.', 'Pinch correto.', 'Bon pinch.', 'Richtiger Pinch.'],
    'pr.pinchMissing': ['Falta pulsar la cuerda {x}.', 'You still need to pluck string {x}.', 'Falta tocar a corda {x}.', 'Il faut encore pincer la corde {x}.', 'Saite {x} fehlt noch.'],
    'pr.pinchWrong': ['Pulsaste además: {x}.', 'You also plucked: {x}.', 'Você também tocou: {x}.', 'Vous avez aussi pincé : {x}.', 'Zusätzlich gezupft: {x}.'],
    'pr.pinchEarly': ['Pulsaste {x} con barras todavía presionadas: suéltalas antes.', 'You plucked {x} with bars still pressed: release them first.', 'Você tocou {x} com barras pressionadas: solte-as antes.', 'Vous avez pincé {x} avec des barres enfoncées : relâchez-les avant.', '{x} gezupft, während Leisten gedrückt waren: zuerst loslassen.'],
    'pr.score': ['Lo que sonó se parece a {chord} un {pct} %.', 'What you played is {pct}% like {chord}.', 'O que soou se parece com {chord} em {pct} %.', 'Ce qui a sonné ressemble à {chord} à {pct} %.', 'Gespielt: {pct} % ähnlich zu {chord}.'],
    'pr.good': ['¡Bien hecho!', 'Well done!', 'Muito bem!', 'Bravo !', 'Gut gemacht!'],
    'pr.close': ['Casi: revisa lo marcado.', 'Almost: check the notes.', 'Quase: veja as observações.', 'Presque : vérifiez les remarques.', 'Fast: sieh dir die Hinweise an.'],
    'pr.retry': ['Inténtalo de nuevo.', 'Try again.', 'Tente de novo.', 'Réessayez.', 'Versuch es nochmal.'],
    'pr.nothing': ['No escuché ninguna cuerda.', 'I didn’t hear any string.', 'Não ouvi nenhuma corda.', 'Je n’ai entendu aucune corde.', 'Ich habe keine Saite gehört.'],

    'tour.1t': ['Botonera', 'Chord buttons', 'Botoneira', 'Boutons d’accords', 'Akkordtasten'],
    'tour.1': ['Mantén una barra para tocar su acorde. Con varias a la vez solo suenan las cuerdas que todas dejan libres: así salen acordes nuevos.', 'Hold a bar to play its chord. With several at once only the strings all of them leave open sound: that is how new chords appear.', 'Mantenha uma barra para tocar o acorde dela. Com várias juntas só soam as cordas que todas deixam livres: assim surgem acordes novos.', 'Maintenez une barre pour jouer son accord. Avec plusieurs à la fois, seules les cordes libres dans toutes sonnent : c’est ainsi que naissent de nouveaux accords.', 'Halte eine Leiste, um ihren Akkord zu spielen. Mit mehreren gleichzeitig klingen nur die Saiten, die alle frei lassen: so entstehen neue Akkorde.'],
    'tour.2t': ['Cuerdas', 'Strings', 'Cordas', 'Cordes', 'Saiten'],
    'tour.2': ['Desliza el dedo para rasguear (el volumen sigue tu velocidad), toca una cuerda para pulsarla y deja el dedo quieto encima para apagarla.', 'Slide your finger to strum (volume follows your speed), tap a string to pluck it and rest your finger on it to mute it.', 'Deslize o dedo para rasguear (o volume segue sua velocidade), toque uma corda para tocá-la e deixe o dedo parado sobre ela para abafá-la.', 'Glissez le doigt pour gratter (le volume suit votre vitesse), touchez une corde pour la pincer et laissez le doigt posé pour l’étouffer.', 'Wische zum Streichen (die Lautstärke folgt deiner Geschwindigkeit), tippe eine Saite zum Zupfen an und lass den Finger liegen, um sie abzudämpfen.'],
    'tour.2d': ['Arrastra el ratón sobre las cuerdas o presiona Espacio para rasguear; haz clic en una cuerda para pulsarla.', 'Drag the mouse across the strings or press Space to strum; click a string to pluck it.', 'Arraste o mouse sobre as cordas ou pressione Espaço para rasguear; clique numa corda para tocá-la.', 'Faites glisser la souris sur les cordes ou appuyez sur Espace pour gratter ; cliquez sur une corde pour la pincer.', 'Ziehe die Maus über die Saiten oder drücke die Leertaste zum Streichen; klicke eine Saite zum Zupfen.'],
    'tour.3t': ['Tabla de acordes', 'Chord table', 'Tabela de acordes', 'Tableau des accords', 'Akkordtabelle'],
    'tour.3': ['Encuentra cualquier acorde, aunque tu autoarpa no lo traiga, con su porcentaje de parecido. Toca uno para ver sus formas, la animación paso a paso y practicarlo en «Tu turno».', 'Find any chord, even one your autoharp lacks, with its similarity percentage. Tap one to see its ways to play, the step-by-step animation and practise it in “Your turn”.', 'Encontre qualquer acorde, mesmo que sua autoharpa não o tenha, com sua porcentagem de semelhança. Toque num para ver as formas, a animação passo a passo e praticar em «Sua vez».', 'Trouvez n’importe quel accord, même absent de votre autoharpe, avec son pourcentage de ressemblance. Touchez-en un pour voir ses formes, l’animation pas à pas et vous exercer avec « À vous ».', 'Finde jeden Akkord, auch wenn deine Autoharp ihn nicht hat, mit seiner Ähnlichkeit in Prozent. Tippe einen an für seine Spielweisen, die Schritt-für-Schritt-Animation und Übung mit „Du bist dran“.'],
    'tour.4t': ['Menú', 'Menu', 'Menu', 'Menu', 'Menü'],
    'tour.4': ['Buscador, Optimizador de fieltrado, Modo canción, Editor de barras y Ajustes (idioma, notación y estilo de las cuerdas).', 'Chord finder, felting Optimizer, Song mode, Bar editor and Settings (language, notation and string style).', 'Buscador, Otimizador de feltragem, Modo música, Editor de barras e Ajustes (idioma, notação e estilo das cordas).', 'Recherche, Optimiseur de feutrage, Mode chanson, Éditeur de barres et Réglages (langue, notation et style des cordes).', 'Akkordsuche, Befilzungs-Optimierer, Liedmodus, Leisten-Editor und Einstellungen (Sprache, Notation und Saitenstil).'],
    'tour.next': ['Siguiente', 'Next', 'Próximo', 'Suivant', 'Weiter'],
    'tour.prev': ['Anterior', 'Back', 'Anterior', 'Précédent', 'Zurück'],
    'tour.skip': ['Saltar', 'Skip', 'Pular', 'Passer', 'Überspringen'],
    'tour.done': ['Listo', 'Done', 'Pronto', 'Terminé', 'Fertig'],
    'tour.again': ['Ver recorrido guiado', 'Show guided tour', 'Ver tour guiado', 'Revoir la visite guidée', 'Einführung anzeigen'],

    'set.lang': ['Idioma', 'Language', 'Idioma', 'Langue', 'Sprache'],
    'set.notation': ['Notación de acordes', 'Chord notation', 'Notação de acordes', 'Notation des accords', 'Akkordnotation'],
    'not.auto': ['Automática (según idioma)', 'Automatic (by language)', 'Automática (pelo idioma)', 'Automatique (selon la langue)', 'Automatisch (nach Sprache)'],
    'not.letters': ['Letras (C D E F G A B)', 'Letters (C D E F G A B)', 'Letras (C D E F G A B)', 'Lettres (C D E F G A B)', 'Buchstaben (C D E F G A B)'],
    'not.solfege': ['Solfeo (Do Re Mi)', 'Solfège (Do Re Mi)', 'Solfejo (Dó Ré Mi)', 'Solfège (Do Ré Mi)', 'Solmisation (Do Re Mi)'],
    'not.german': ['Alemana (C D E F G A H)', 'German (C D E F G A H)', 'Alemã (C D E F G A H)', 'Allemande (C D E F G A H)', 'Deutsch (C D E F G A H)'],
    'set.style': ['Estilo de las cuerdas', 'String style', 'Estilo das cordas', 'Style des cordes', 'Saitenstil'],
    'sty.classic': ['Clásica (guías {c} rojo y {f} azul)', 'Classic ({c} red and {f} blue guides)', 'Clássica (guias {c} vermelho e {f} azul)', 'Classique (repères {c} rouge et {f} bleu)', 'Klassisch ({c} rot und {f} blau als Orientierung)'],
    'sty.sober': ['Sobria (todas iguales)', 'Plain (all alike)', 'Sóbria (todas iguais)', 'Sobre (toutes pareilles)', 'Schlicht (alle gleich)'],
    'sty.contrast': ['Alto contraste', 'High contrast', 'Alto contraste', 'Contraste élevé', 'Hoher Kontrast'],
    'set.app': ['Instrumento en el teléfono', 'Instrument on the phone', 'Instrumento no telefone', 'Instrument sur le téléphone', 'Instrument auf dem Telefon'],
    'set.latch': ['Fijar botones (tocar para dejar presionada, otro toque la suelta)', 'Latch buttons (tap to hold, tap again to release)', 'Fixar botões (toque para manter, outro toque solta)', 'Verrouiller les boutons (un toque maintient, un autre relâche)', 'Tasten einrasten (Tippen hält, erneutes Tippen löst)'],
    'set.mirror': ['Zurdo: botonera a la derecha (las cuerdas no cambian de sentido)', 'Left-handed: buttons on the right (strings keep their direction)', 'Canhoto: botoneira à direita (as cordas não mudam de sentido)', 'Gaucher : boutons à droite (les cordes gardent leur sens)', 'Linkshänder: Tasten rechts (Saitenrichtung bleibt)'],
    'set.studio': ['Franja Estudio: ver qué cuerdas suenan', 'Studio strip: see which strings sound', 'Faixa Estúdio: ver quais cordas soam', 'Bande Studio : voir quelles cordes sonnent', 'Studio-Leiste: sehen, welche Saiten klingen'],
    'set.force': ['Volumen según la fuerza del toque (si la pantalla lo permite)', 'Volume from touch pressure (if the screen supports it)', 'Volume pela força do toque (se a tela permitir)', 'Volume selon la force du toucher (si l’écran le permet)', 'Lautstärke nach Druckstärke (falls der Bildschirm es kann)'],
    'set.latency': ['Mostrar panel de latencia', 'Show latency panel', 'Mostrar painel de latência', 'Afficher le panneau de latence', 'Latenz-Anzeige zeigen'],
    'set.reset': ['Reiniciar medición de latencia', 'Reset latency measurement', 'Reiniciar medição de latência', 'Réinitialiser la mesure de latence', 'Latenzmessung zurücksetzen'],
    'set.layoutHint': ['El layout activo se elige arriba y se aplica al instrumento al instante.', 'The active layout is chosen above and applies to the instrument at once.', 'O layout ativo é escolhido acima e se aplica ao instrumento na hora.', 'La disposition active se choisit en haut et s’applique aussitôt.', 'Das aktive Layout wird oben gewählt und gilt sofort.'],
    'leg.guide': ['{n} (guía)', '{n} (guide)', '{n} (guia)', '{n} (repère)', '{n} (Orientierung)'],
    'leg.felt': ['tapada (fieltro)', 'muted (felt)', 'abafada (feltro)', 'étouffée (feutre)', 'gedämpft (Filz)'],
    'n.menu': ['Menú', 'Menu', 'Menu', 'Menu', 'Menü'],
    'n.latSw': ['Toque a motor', 'Touch to engine', 'Toque ao motor', 'Toucher → moteur', 'Berührung → Engine'],
    'n.latOut': ['Salida', 'Output', 'Saída', 'Sortie', 'Ausgabe'],
    'n.force': ['Fuerza táctil', 'Touch pressure', 'Força do toque', 'Force tactile', 'Druckstärke'],
    'n.forceOn': ['detectada', 'detected', 'detectada', 'détectée', 'erkannt'],
    'n.forceOff': ['sin datos útiles (se usa la velocidad)', 'no useful data (speed is used)', 'sem dados úteis (usa a velocidade)', 'pas de données utiles (vitesse utilisée)', 'keine brauchbaren Daten (Geschwindigkeit wird genutzt)'],
    'n.forceDis': ['desactivada', 'off', 'desativada', 'désactivée', 'aus']
  };

  /* Textos que usa la parte nativa de Android (se envían por el puente al cambiar de idioma). */
  const NATIVE_KEYS = ['n.menu', 'tab.coverage', 'an.prev', 'an.next', 'an.play', 'an.pause', 'an.repeat', 'an.stepMode', 'an.timeline', 'an.close', 'an.speed', 'an.stepOf',
    'an.sound', 'an.strings', 'an.seekHint', 'an.bar', 'an.pressed', 'an.released', 'hand.left', 'hand.right', 'leg.felt', 'pr.again', 'pr.example', 'song.auto', 'an.ringing',
    'tour.1t', 'tour.1', 'tour.2t', 'tour.2', 'tour.3t', 'tour.3', 'tour.4t', 'tour.4', 'tour.next', 'tour.prev', 'tour.skip', 'tour.done', 'n.latSw', 'n.latOut', 'n.force', 'n.forceOn', 'n.forceOff', 'n.forceDis'];

  let lang = 'es', notationPref = 'auto';
  const listeners = [];

  function detect() {
    const n = (g.navigator && (g.navigator.language || '')) || '';
    const two = n.slice(0, 2).toLowerCase();
    return LANGS.includes(two) ? two : 'en';
  }
  function setLang(l) { if (LANGS.includes(l)) { lang = l; listeners.forEach(f => f()); } }
  function setNotation(n) { if (['auto', 'letters', 'solfege', 'german'].includes(n)) { notationPref = n; listeners.forEach(f => f()); } }
  function notation() { return notationPref !== 'auto' ? notationPref : (lang === 'en' ? 'letters' : lang === 'de' ? 'german' : 'solfege'); }
  function t(key, p) {
    const row = K[key];
    let s = row ? (row[LANGS.indexOf(lang)] || row[0]) : key;
    if (p) s = s.replace(/\{(\w+)\}/g, (m, k) => (p[k] !== undefined ? p[k] : m));
    return s;
  }

  /* ---------- Notación ---------- */
  const SOL = { C: 'Do', D: 'Re', E: 'Mi', F: 'Fa', G: 'Sol', A: 'La', B: 'Si' };
  const GER = { C: 'C', 'C#': 'Cis', Db: 'Des', D: 'D', 'D#': 'Dis', Eb: 'Es', E: 'E', 'E#': 'Eis', Fb: 'Fes', F: 'F', 'F#': 'Fis', Gb: 'Ges', G: 'G', 'G#': 'Gis', Ab: 'As', A: 'A', 'A#': 'Ais', Bb: 'B', B: 'H', Cb: 'Ces', 'B#': 'His' };
  function root(r) {
    const n = notation();
    if (n === 'german') return GER[r] || r;
    if (n === 'solfege') { let b = SOL[r[0]]; if (!b) return r; if (r[0] === 'D' && (lang === 'fr' || lang === 'pt')) b = lang === 'fr' ? 'Ré' : 'Ré'; if (r[0] === 'C' && lang === 'pt') b = 'Dó'; return b + r.slice(1); }
    return r;
  }
  /** Nombre de acorde o etiqueta de barra para mostrar: 'Bb7' -> 'Sib7' / 'B7' (alemana). Lo que no empieza con nota queda igual. */
  function chord(name) {
    if (!name) return name;
    const m = String(name).match(/^([A-G][#b]?)(.*?)(?:\/([A-G][#b]?))?$/);
    if (!m) return name;
    return root(m[1]) + m[2] + (m[3] ? '/' + root(m[3]) : '');
  }
  /** Nota con octava: 'F#3' -> 'Fa#3' */
  function note(name) { const m = String(name).match(/^([A-G][#b]?)(-?\d+)$/); return m ? root(m[1]) + m[2] : name; }
  function pc(i) { return root(AH.theory ? AH.theory.pcName(i) : String(i)); }

  const SOL_IN = { do: 'C', 'dó': 'C', re: 'D', 'ré': 'D', mi: 'E', fa: 'F', sol: 'G', la: 'A', si: 'B' };
  const GER_IN = { ces: 'Cb', cis: 'C#', des: 'Db', dis: 'D#', eis: 'E#', es: 'Eb', fes: 'Fb', fis: 'F#', ges: 'Gb', gis: 'G#', as: 'Ab', ais: 'A#', his: 'B#', c: 'C', d: 'D', e: 'E', f: 'F', g: 'G', a: 'A', b: 'Bb', h: 'B' };
  function convRoot(part, table, re) {
    const m = part.match(re); if (!m) return null;
    const base = table[m[1].toLowerCase()]; if (!base) return null;
    return { root: base, rest: part.slice(m[0].length) };
  }
  function fromSolfege(s) {
    const re = /^(dó|do|ré|re|mi|fa|sol|la|si)/i;
    const [main, bass] = s.split('/');
    const a = convRoot(main, SOL_IN, re); if (!a) return null;
    let out = a.root + a.rest.replace(/^♯/, '#').replace(/^♭/, 'b');
    if (bass !== undefined) { const b = convRoot(bass, SOL_IN, re); out += '/' + (b ? b.root + b.rest : bass); }
    return out;
  }
  function fromGerman(s) {
    const re = /^(ces|cis|des|dis|eis|es|fes|fis|ges|gis|as|ais|his|[a-h])/i;
    const [main, bass] = s.split('/');
    const a = convRoot(main, GER_IN, re); if (!a) return null;
    let out = a.root + a.rest;
    if (bass !== undefined) { const b = convRoot(bass, GER_IN, re); out += '/' + (b ? b.root + b.rest : bass); }
    return out;
  }
  /** Lecturas posibles (en letras) de lo que escribió el usuario, en orden de preferencia según la notación. */
  function candidates(str) {
    const s = String(str || '').trim();
    const sol = fromSolfege(s), ger = fromGerman(s), n = notation();
    const out = [];
    const add = x => { if (x && !out.includes(x)) out.push(x); };
    if (n === 'german') { add(ger); add(s); add(sol); }
    else if (n === 'solfege') { add(sol); add(s); add(ger); }
    else { add(s); add(sol); add(ger); }
    return out;
  }

  /* ---------- Textos compuestos ---------- */
  function joinList(arr) { if (arr.length <= 1) return arr.join(''); return arr.slice(0, -1).join(', ') + t('w.and') + arr[arr.length - 1]; }
  function describe(r, tuning) {
    const parts = [t('desc.press', { bars: r.bars.map(b => chord(b.label)).join(' + ') })];
    parts.push(r.window.id === 'full' ? t('desc.strumAll') : t('desc.strumZone', { zone: t('zone.' + r.window.id).toLowerCase(), a: r.range[0] + 1, b: r.range[1] + 1 }));
    if (r.pinches && r.pinches.length) parts.push(t('desc.pinch', { list: joinList(r.pinches.map(i => t('desc.str', { note: note(tuning[i].name), n: i + 1 }))) }));
    return parts.join(', ');
  }
  function mechanism(r) {
    const m = [];
    if (r.bars.length > 1) m.push(t('mech.inter'));
    if (r.window.id !== 'full') m.push(t('mech.zone'));
    if (r.pinches && r.pinches.length) m.push(t('mech.pinch'));
    return m.length ? m.join(' + ') : t('mech.bar');
  }
  function nativeBundle() { const o = {}; NATIVE_KEYS.forEach(k => { o[k] = t(k); }); o.notation = notation(); o.lang = lang; o['leg.c'] = t('leg.guide', { n: pc(0) }); o['leg.f'] = t('leg.guide', { n: pc(5) }); return o; }

  AH.i18n = { LANGS, LANG_NAMES, K, NATIVE_KEYS, t, setLang, setNotation, notation, get lang() { return lang; }, get notationPref() { return notationPref; },
    detect, onChange: f => listeners.push(f), chord, note, pc, root, candidates, fromSolfege, fromGerman, describe, mechanism, joinList, nativeBundle };
})(typeof globalThis !== 'undefined' ? globalThis : window);
