/* Guion de animación de un ejemplo de acorde (v2: pasos, línea de tiempo y modo paso a paso).
   build() convierte una receta del buscador {bars, window, range, pinches, sc} en:
   - steps: pasos con mano, título y texto que no desaparece;
   - lanes: línea de tiempo (cuándo se presiona y suelta cada barra; rasgueo y pinch de la otra mano; qué suena);
   - events: sonidos y marcas visuales con su tiempo (ms a 1×).
   Runner reproduce el guion con play/pausa, velocidad, saltos y modo paso a paso. Sin DOM: se prueba en Node
   y la app Android recibe el mismo guion ya traducido. */
(function (g) {
  'use strict';
  const AH = g.AH = g.AH || {};
  const E = AH.engine;

  const TIMING = { lead: 400, pressHold: 1800, strumLead: 400, perString: 70, strumTail: 900, releaseLead: 400, releaseHold: 1400, pinchLead: 700, pinchGap: 1600, pinchTail: 1200 };

  const I = () => AH.i18n;
  const tr = (k, p, fb) => (I() ? I().t(k, p) : (fb || k));
  const nm = s => (I() ? I().note(s) : s);
  const ch = s => (I() ? I().chord(s) : s);
  const list = a => (I() ? I().joinList(a) : a.join(', '));

  /**
   * layout: {rows, tuning}; r: receta; opts: {label: 'Bm', pct: 0.94, className: 'Funcional', leftHanded: false}
   */
  function build(layout, r, opts) {
    opts = opts || {};
    const tun = layout.tuning, n = tun.length;
    const flat = layout.rows.flat();
    const barIdx = r.bars.map(b => { let k = flat.indexOf(b); if (k < 0) k = flat.findIndex(x => x.label === b.label); return k; }).filter(k => k >= 0);
    const mask = E.andMasks(r.bars, n);
    const a = r.range ? r.range[0] : 0, b = r.range ? r.range[1] : n - 1;
    const pins = (r.pinches || []).slice();
    const strum = [];
    for (let i = a; i <= b; i++) if (mask[i]) strum.push(i);
    // mano que presiona barras y mano que toca cuerdas (zurdo: se invierten)
    const barHand = tr(opts.leftHanded ? 'hand.right' : 'hand.left', null, opts.leftHanded ? 'Mano derecha' : 'Mano izquierda');
    const strHand = tr(opts.leftHanded ? 'hand.left' : 'hand.right', null, opts.leftHanded ? 'Mano izquierda' : 'Mano derecha');
    const labels = r.bars.map(x => ch(x.label));
    const strLabel = i => (i + 1) + ' (' + nm(tun[i].name) + ')';
    const pcsOf = arr => Array.from(new Set(arr.map(i => tun[i].pc))).map(p => (I() ? I().pc(p) : p));

    const steps = [], events = [], lanes = { bars: [], right: [], sound: [] };
    let t = 0;

    // 1) presionar
    const s1 = { t0: 0, kind: 'press', hand: barHand, title: tr('st.press', null, 'Presionar'),
      text: labels.length === 1 ? tr('sx.press1', { hand: barHand, b: labels[0] }) : tr('sx.pressN', { hand: barHand, list: list(labels) }) };
    const tPress = TIMING.lead;
    events.push({ t: tPress, type: 'press', bars: barIdx });
    lanes.sound.push({ t: 0, text: '—' });
    t = tPress + TIMING.pressHold; s1.t1 = t; steps.push(s1);

    // 2) rasguear
    const full = a === 0 && b === n - 1;
    const s2 = { t0: t, kind: 'strum', hand: strHand, title: tr('st.strum', null, 'Rasguear'),
      text: full ? tr('sx.strumAll', { hand: strHand }) : tr('sx.strumZone', { hand: strHand, a: a + 1, b: b + 1, na: nm(tun[a].name), nb: nm(tun[b].name) }) };
    const tS = t + TIMING.strumLead, dur = Math.max(0, (strum.length - 1) * TIMING.perString);
    events.push({ t: tS, type: 'sweep', a, b, dur });
    strum.forEach((s, k) => events.push({ t: tS + k * TIMING.perString, type: 'pluck', s, vel: 0.75, kind: 'strum' }));
    lanes.right.push({ type: 'strum', t0: tS, t1: tS + dur, a, b, text: tr('an.strumLane', { a: a + 1, b: b + 1 }) });
    const res = opts.label ? ch(opts.label) + (opts.pct !== undefined ? ' ' + Math.round(opts.pct * 100) + '%' : '') : '';
    lanes.sound.push({ t: tS, text: pcsOf(strum).join(' · ') + (pins.length || !res ? '' : '  =  ' + res) });
    t = tS + dur + TIMING.strumTail; s2.t1 = t; steps.push(s2);

    let tRelease = null;
    if (pins.length) {
      // 3) soltar
      const s3 = { t0: t, kind: 'release', hand: barHand, title: tr('st.release', null, 'Soltar'), text: tr('sx.release', { hand: barHand }) };
      tRelease = t + TIMING.releaseLead;
      events.push({ t: tRelease, type: 'press', bars: [] });
      lanes.sound.push({ t: tRelease, text: tr('an.ringing', null, 'siguen sonando') });
      t = tRelease + TIMING.releaseHold; s3.t1 = t; steps.push(s3);
      // 4) pulsar
      const rest = pins.slice(1).map(p => strLabel(p));
      const s4 = { t0: t, kind: 'pinch', hand: strHand, title: tr('st.pinch', null, 'Pulsar'),
        text: pins.length === 1 ? tr('sx.pinch1', { hand: strHand, n: pins[0] + 1, note: nm(tun[pins[0]].name) }) : tr('sx.pinchN', { hand: strHand, n: pins[0] + 1, note: nm(tun[pins[0]].name), list: list(rest) }) };
      pins.forEach((p, k) => {
        const at = t + k * TIMING.pinchGap;
        events.push({ t: at, type: 'focus', s: p, dur: TIMING.pinchLead + 700 });
        events.push({ t: at + TIMING.pinchLead, type: 'pluck', s: p, vel: 0.8, kind: 'pinch' });
        lanes.right.push({ type: 'pinch', t: at + TIMING.pinchLead, s: p, text: tr('an.pinchLane', { n: p + 1, note: nm(tun[p].name) }) });
      });
      const tLast = t + (pins.length - 1) * TIMING.pinchGap + TIMING.pinchLead;
      lanes.sound.push({ t: t + TIMING.pinchLead, text: '+ ' + pcsOf(pins).join(' · ') + (res ? '  =  ' + res : '') });
      t = tLast + TIMING.pinchTail; s4.t1 = t; steps.push(s4);
    }
    const duration = t;
    barIdx.forEach((k, j) => lanes.bars.push({ idx: k, label: labels[j], t0: tPress, t1: tRelease !== null ? tRelease : duration }));
    const result = opts.label ? tr('an.result', { chord: ch(opts.label), pct: Math.round((opts.pct || 0) * 100), cls: opts.className || '', arp: pins.length ? tr('an.arp') : '' }) : '';
    events.push({ t: duration, type: 'end' });
    events.sort((x, y) => x.t - y.t);
    steps.forEach((s, i) => { s.i = i; s.of = steps.length; s.head = tr('an.stepOf', { i: i + 1, n: steps.length }, 'Paso ' + (i + 1) + ' de ' + steps.length) + ' · ' + s.hand; });
    return { events, steps, lanes, duration, result, label: opts.label ? ch(opts.label) : '', barIdx, strum, pinches: pins };
  }

  /** Cursor del rasgueo (índice de cuerda con decimales) en el instante t, o null. */
  function sweepAt(sw, t) {
    if (!sw) return null;
    const k = sw.dur > 0 ? Math.min(1, Math.max(0, (t - sw.t) / sw.dur)) : 1;
    return sw.a + (sw.b - sw.a) * k;
  }

  /** Estado visual en el instante t (sirve para saltar a cualquier punto). */
  function stateAt(plan, t) {
    const pressed = plan.lanes.bars.filter(l => t >= l.t0 && t < l.t1).map(l => l.idx);
    let step = 0; plan.steps.forEach((s, i) => { if (t >= s.t0) step = i; });
    const sw = plan.events.find(e => e.type === 'sweep' && t >= e.t && t <= e.t + e.dur + 600) || null;
    const focus = plan.events.filter(e => e.type === 'focus' && t >= e.t && t <= e.t + e.dur);
    return { pressed, step, sweep: sw, focus };
  }

  const SPEEDS = [0.25, 0.5, 0.75, 1, 1.5, 2];

  /**
   * Reproductor. hooks: {press(bars), pluck(s, vel, delayMs), stop(), change()}
   * lookahead (ms reales): los sonidos se programan con anticipación y desfase exacto (Android usa 40 ms).
   */
  function Runner(plan, hooks, opts) {
    this.plan = plan; this.h = hooks || {}; this.t = 0; this.next = 0; this.playing = true;
    this.speed = (opts && opts.speed) || 1; this.stepMode = !(opts && opts.stepMode === false); this.look = (opts && opts.lookahead) || 0;
    this.pressed = [];
    this._apply(0);
  }
  Runner.prototype.step = function () { return stateAt(this.plan, this.t).step; };
  Runner.prototype._apply = function (t) {
    const s = stateAt(this.plan, t);
    const key = s.pressed.join(',');
    if (key !== this.pressed.join(',')) { this.pressed = s.pressed; if (this.h.press) this.h.press(s.pressed); }
    this.state = s;
  };
  /** Avanza dtReal ms reales. Devuelve true si cambió algo que la interfaz deba redibujar en texto/botones. */
  Runner.prototype.tick = function (dtReal) {
    if (!this.playing) { this._apply(this.t); return false; }
    const steps = this.plan.steps, before = this.step();
    let nt = this.t + dtReal * this.speed, paused = false;
    if (this.stepMode && before < steps.length - 1) {
      const lim = steps[before].t1 - 1;
      if (this.t < lim && nt >= lim) { nt = lim; paused = true; }
    }
    if (nt >= this.plan.duration) { nt = this.plan.duration; paused = true; }
    const ahead = nt + this.look * this.speed;
    const ev = this.plan.events;
    while (this.next < ev.length && ev[this.next].t <= ahead && (!paused || ev[this.next].t <= nt)) {
      const e = ev[this.next++];
      if (e.type === 'pluck' && this.h.pluck) this.h.pluck(e.s, e.vel, Math.max(0, (e.t - this.t) / this.speed));
    }
    this.t = nt; this._apply(nt);
    if (paused) this.playing = false;
    return paused || this.step() !== before;
  };
  Runner.prototype.seek = function (t) {
    this.t = Math.max(0, Math.min(this.plan.duration, t));
    this.next = this.plan.events.findIndex(e => e.t >= this.t); if (this.next < 0) this.next = this.plan.events.length;
    if (this.h.stop) this.h.stop();
    this._apply(this.t);
  };
  Runner.prototype.toggle = function () {
    if (!this.playing && this.t >= this.plan.duration) { this.seek(0); this.playing = true; return; }
    this.playing = !this.playing;
  };
  Runner.prototype.goStep = function (i) {
    const s = this.plan.steps[Math.max(0, Math.min(this.plan.steps.length - 1, i))];
    this.seek(s.t0); this.playing = true;
  };
  Runner.prototype.nextStep = function () {
    const i = this.step();
    if (i >= this.plan.steps.length - 1) { this.seek(this.plan.steps[i].t0); this.playing = true; return; }
    this.goStep(i + 1);
  };
  Runner.prototype.prevStep = function () {
    const i = this.step();
    this.goStep(this.t - this.plan.steps[i].t0 > 400 ? i : i - 1);
  };
  Runner.prototype.changeSpeed = function (dir) {
    let k = SPEEDS.indexOf(this.speed); if (k < 0) k = 3;
    this.speed = SPEEDS[Math.max(0, Math.min(SPEEDS.length - 1, k + dir))];
  };
  Runner.prototype.done = function () { return this.t >= this.plan.duration; };

  AH.player = { TIMING, SPEEDS, build, sweepAt, stateAt, Runner };
})(typeof globalThis !== 'undefined' ? globalThis : window);
