/* Interfaz de usuario (escritorio, web y menú/tabla dentro de la app Android). */
(function (g) {
  'use strict';
  const AH = g.AH;
  const T = AH.theory, I = AH.instrument, E = AH.engine, O = AH.optimizer, L10 = AH.i18n, P = AH.player, PR = AH.practice;
  const t = L10.t;
  const D = { chord: s => L10.chord(s), note: s => L10.note(s), pc: i => L10.pc(i) };
  const $ = s => document.querySelector(s);
  const el = (tag, attrs, html) => { const e = document.createElement(tag); if (attrs) for (const k in attrs) { if (k === 'class') e.className = attrs[k]; else if (k.startsWith('on')) e.addEventListener(k.slice(2), attrs[k]); else e.setAttribute(k, attrs[k]); } if (html !== undefined) e.innerHTML = html; return e; };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const pct = x => Math.round(x * 100) + '%';
  const KEYROWS = ['1234567890', 'qwertyuiop', 'asdfghjklñ', 'zxcvbnm,.-'];
  const LS_KEY = 'autoarpa.layouts.v1', LS_LAST = 'autoarpa.lastLayout', LS_SET = 'autoarpa.settings', LS_SONGS = 'autoarpa.songs', LS_TOUR = 'autoarpa.tour.done';
  const EMBED = /[?&]embed=/.test(g.location.search);
  const bridge = () => g.AndroidBridge || null;
  const ls = { get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } } };

  const st = {
    layout: null, cache: null, pressed: new Set(), keyBars: new Map(), zone: 'full', audio: null, editSel: null,
    proposal: null, optResult: null, arranged: null, highlight: null, customDefs: [], layoutKey: 'def:os21',
    anim: null, animHands: new Set(), practice: null, practiceTgt: null, song: null, mode: 'menu', menuTab: null,
    settings: {}, style: 'classic', lastChord: null
  };

  function toast(msg) { const x = $('#toast'); x.textContent = msg; x.classList.add('show'); clearTimeout(x._h); x._h = setTimeout(() => x.classList.remove('show'), 2800); }

  /* ---------- Ajustes, idioma y notación ---------- */
  function loadSettings() {
    let s = {};
    const b = bridge();
    if (EMBED && b && b.getSettings) { try { s = JSON.parse(b.getSettings()); } catch (e) { s = {}; } }
    else { try { s = JSON.parse(ls.get(LS_SET, '{}')); } catch (e) { s = {}; } }
    st.settings = s;
    L10.setLang(s.lang || L10.detect());
    L10.setNotation(s.notation || 'auto');
    st.style = s.style || 'classic';
  }
  function saveSetting(k, v) {
    st.settings[k] = v;
    const b = bridge();
    if (EMBED && b) { try { if (typeof v === 'boolean') b.setSetting(k, v); else if (b.setSettingStr) b.setSettingStr(k, String(v)); } catch (e) { /* */ } }
    else ls.set(LS_SET, JSON.stringify(st.settings));
  }
  function sendNativeStrings() { const b = bridge(); if (b && b.setStrings) { try { b.setStrings(JSON.stringify(L10.nativeBundle())); } catch (e) { /* */ } } }
  function applyI18n() {
    document.documentElement.lang = L10.lang;
    document.title = t('app.title');
    document.querySelectorAll('[data-i18n]').forEach(e => { e.textContent = t(e.dataset.i18n); });
    document.querySelectorAll('[data-i18n-title]').forEach(e => { e.title = t(e.dataset.i18nTitle); });
    $('#qChord').placeholder = t('search.ph', { ex: examples() });
  }
  function examples() { return ['F#m7', 'Cmaj7', 'Bdim', 'G/B'].map(D.chord).join(', '); }
  function onLangChange() {
    applyI18n(); fillLayoutSelect(st.layoutKey); fillSelects(); help(); buildSettings();
    renderBars(); renderEditor(); updateReadout(); drawBed(); renderSongTab();
    if ($('#cTable').innerHTML) runCoverage();
    if (st.lastChord) runSearch(st.lastChord);
    notifyLayout(); sendNativeStrings();
    if (st.anim) { st.anim.plan = rebuildPlan(st.anim); buildProgress(); buildTimeline(); animLabels(); }
  }
  function fillSelects() {
    const zs = $('#zoneSel'), zv = st.zone; zs.innerHTML = '';
    E.WINDOWS.forEach(w => zs.appendChild(el('option', { value: w.id }, t('zone.' + w.id)))); zs.value = zv;
    const qr = $('#qRoot'), qrv = qr.value; qr.innerHTML = '';
    for (let i = 0; i < 12; i++) qr.appendChild(el('option', { value: i }, D.pc(i))); if (qrv) qr.value = qrv;
    const qt = $('#qType'), qtv = qt.value; qt.innerHTML = '';
    T.TYPES.forEach(x => qt.appendChild(el('option', { value: x.id }, (x.suf || t('type.majShort')) + ' · ' + t('type.' + x.id)))); if (qtv) qt.value = qtv;
    const sl = $('#setLang'); sl.innerHTML = '';
    L10.LANGS.forEach(l => sl.appendChild(el('option', { value: l }, L10.LANG_NAMES[l]))); sl.value = L10.lang;
    const sn = $('#setNotation'); sn.innerHTML = '';
    ['auto', 'letters', 'solfege', 'german'].forEach(n => sn.appendChild(el('option', { value: n }, t('not.' + n)))); sn.value = L10.notationPref;
    const ss = $('#setStyle'); ss.innerHTML = '';
    ['classic', 'sober', 'contrast'].forEach(n => ss.appendChild(el('option', { value: n }, t('sty.' + n, { c: D.pc(0), f: D.pc(5) })))); ss.value = st.style;
  }

  /* ---------- Persistencia de layouts ---------- */
  function loadCustom() { try { st.customDefs = JSON.parse(ls.get(LS_KEY, '[]')); } catch (e) { st.customDefs = []; } }
  function saveCustom() { if (!ls.set(LS_KEY, JSON.stringify(st.customDefs))) toast(t('ed.cantSave')); }

  /* ---------- Layouts ---------- */
  function layoutName(L) { return L.id && I.LAYOUT_DEFS.some(d => d.id === L.id) ? t('layout.' + L.id) : L.name; }
  function fillLayoutSelect(selId) {
    const s = $('#layoutSel'); s.innerHTML = '';
    const og1 = el('optgroup', { label: t('hdr.ref') });
    I.LAYOUT_DEFS.forEach(d => og1.appendChild(el('option', { value: 'def:' + d.id }, t('layout.' + d.id))));
    s.appendChild(og1);
    if (st.customDefs.length) {
      const og2 = el('optgroup', { label: t('hdr.mine') });
      st.customDefs.forEach((d, i) => og2.appendChild(el('option', { value: 'cus:' + i }, esc(d.name))));
      s.appendChild(og2);
    }
    if (selId) s.value = selId;
  }
  function setLayout(layout) {
    closeAll(true);
    st.layout = layout; st.pressed.clear(); st.editSel = null; st.highlight = null;
    st.cache = E.buildCache(layout);
    if (!st.audio) st.audio = new AH.Audio(layout.tuning); else st.audio.setTuning(layout.tuning);
    rebindKeys();
    $('#eName').value = layoutName(layout);
    renderBars(); renderEditor(); updateReadout(); drawBed(); renderSongTab();
    $('#cTable').innerHTML = ''; $('#cSummary').innerHTML = '';
    notifyLayout();
    if (EMBED) setTimeout(() => { if (!$('#cTable').innerHTML) runCoverage(); }, 400);
  }
  function selectLayout(v) {
    st.layoutKey = v; ls.set(LS_LAST, v);
    if (v.startsWith('def:')) setLayout(I.buildLayout(I.LAYOUT_DEFS.find(d => d.id === v.slice(4))));
    else setLayout(I.deserializeLayout(st.customDefs[+v.slice(4)]));
  }
  /** Envía a la app Android el layout activo, con las etiquetas ya en la notación elegida. */
  function notifyLayout() {
    const b = bridge(); if (!b || !st.layout || !b.layoutChanged) return;
    const L = st.layout;
    try {
      b.layoutChanged(JSON.stringify({ id: L.id, name: layoutName(L), midi: L.tuning.map(x => x.midi), names: L.tuning.map(x => x.name), dispNames: L.tuning.map(x => D.note(x.name)),
        rows: L.rows.map(r => r.map(x => ({ label: x.label, disp: D.chord(x.label), mask: Array.from(x.mask).join('') }))) }));
    } catch (e) { /* sin puente */ }
  }

  /* ---------- Botonera ---------- */
  const flatBars = () => st.layout.rows.flat();
  function keyOf(bar) { for (const [k, b] of st.keyBars) if (b === bar && k !== ';') return k; return ''; }
  function songTargets() {
    if (!st.song) return { cur: new Set(), next: new Set() };
    const it = st.song.items[st.song.i], nx = st.song.items[st.song.i + 1];
    return { cur: new Set(it ? it.barIdx : []), next: new Set(nx ? nx.barIdx : []) };
  }
  function renderBars() {
    const box = $('#bars'); box.innerHTML = '';
    const flat = flatBars(), song = songTargets();
    const hint = st.practice && $('#prHints').checked ? new Set(st.practice.tgt.barIdx) : new Set();
    st.layout.rows.forEach((row, ri) => {
      const r = el('div', { class: 'bar-row' });
      r.style.marginLeft = g.innerWidth > 700 ? (ri * 32) + 'px' : (ri * 4) + '%';
      row.forEach(b => {
        const k = flat.indexOf(b);
        const cls = ['bar-btn'];
        if (st.pressed.has(b.id)) cls.push('on');
        if (st.highlight && st.highlight.has(b.id)) cls.push('hl');
        if (st.animHands.has(b.id)) cls.push('hand');
        if (song.cur.has(k)) cls.push('song-cur'); else if (song.next.has(k)) cls.push('song-next');
        if (hint.has(k)) cls.push('pr-hint');
        const tip = (b.source === 'real' ? t('src.realTip') : b.source === 'generado' ? t('src.genTip') : t('src.cusTip')) + (b.note ? ' · ' + b.note : '');
        const btn = el('button', { class: cls.join(' '), title: tip }, `<span class="src ${b.source}"></span>${esc(D.chord(b.label))}<span class="k">${keyOf(b).toUpperCase()}</span>`);
        btn.addEventListener('pointerdown', e => { e.preventDefault(); if ($('#latch').checked || e.shiftKey || e.ctrlKey) toggleBar(b); else pressBar(b, true); });
        btn.addEventListener('pointerup', () => { if (!$('#latch').checked) pressBar(b, false); });
        btn.addEventListener('pointerleave', e => { if (!$('#latch').checked && e.buttons) pressBar(b, false); });
        r.appendChild(btn);
      });
      box.appendChild(r);
    });
  }
  function pressedIdx() { const f = flatBars(); return f.map((b, i) => (st.pressed.has(b.id) ? i : -1)).filter(i => i >= 0); }
  function pressBar(b, on) {
    if (on) { if (st.pressed.has(b.id)) return; st.pressed.add(b.id); if (st.audio && st.audio.ctx) st.audio.applyMask(b.mask); }
    else { if (!st.pressed.has(b.id)) return; st.pressed.delete(b.id); }
    st.highlight = null; renderBars(); updateReadout(); drawBed();
    prLog({ type: 'press', bars: pressedIdx() });
  }
  function toggleBar(b) { pressBar(b, !st.pressed.has(b.id)); }
  function pressedBars() { return flatBars().filter(b => st.pressed.has(b.id)); }
  function currentMask() { return E.andMasks(pressedBars(), st.layout.tuning.length); }
  function currentZone() { return E.WINDOWS.find(w => w.id === st.zone) || E.WINDOWS[0]; }
  function currentStrings() {
    const m = currentMask(); const [a, b] = E.windowRange(currentZone(), m.length);
    const out = []; for (let i = a; i <= b; i++) if (m[i]) out.push(i); return out;
  }

  function updateReadout() {
    const bars = pressedBars();
    const name = $('#chordName'), info = $('#chordInfo'), alt = $('#chordAlt'), notes = $('#chordNotes'), meter = $('#chordMeter');
    alt.innerHTML = ''; notes.textContent = '';
    if (!bars.length) { name.textContent = '—'; info.textContent = t('play.noBars', { n: st.layout.tuning.length }); meter.style.width = '0'; return; }
    const strings = currentStrings();
    const pcs = Array.from(new Set(strings.map(i => st.layout.tuning[i].pc)));
    const blabel = bars.map(b => D.chord(b.label)).join(' + ');
    if (pcs.length < 2) { name.textContent = '∅'; info.textContent = blabel + ': ' + (pcs.length ? t('play.oneNote', { n: D.pc(pcs[0]) }) : t('play.noString')); meter.style.width = '0'; return; }
    const id = E.identify(strings, st.layout.tuning, 4);
    const top = id[0]; const cls = E.classify(top.sc.S);
    name.textContent = D.chord(top.chord.name);
    info.textContent = blabel + ' · ' + pct(top.sc.S) + ' · ' + cls.name + (top.sc.inverted ? ' · ' + t('play.bassIn', { n: D.pc(E.features(strings, st.layout.tuning).bass) }) : '');
    meter.style.width = pct(top.sc.S); meter.style.background = `var(--${cls.id})`;
    id.slice(1).forEach(x => alt.appendChild(el('span', { class: 'chip' }, esc(D.chord(x.chord.name)) + ' ' + pct(x.sc.S))));
    notes.textContent = t('play.notes', { list: pcs.sort((a, b) => a - b).map(D.pc).join(' · '), n: strings.length });
  }

  /* ---------- Encordado (canvas) ---------- */
  const bed = { x: [], hover: -1, lastX: null, dragging: false };
  function stringColor(i, open, css) {
    const nmn = st.layout.tuning[i].name, isC = /^C\d/.test(nmn), isF = /^F\d/.test(nmn);
    if (st.style === 'sober') return { c: open ? css.getPropertyValue('--string') : css.getPropertyValue('--string-off'), w: 0, dash: false };
    if (st.style === 'contrast') {
      const dark = document.documentElement.dataset.theme !== 'light';
      if (!open) return { c: dark ? '#4a4a4a' : '#b9b9b9', w: 0, dash: true };
      return { c: isC ? '#ffb000' : isF ? '#2ec5ff' : (dark ? '#ffffff' : '#111111'), w: 1, dash: false };
    }
    if (!open) return { c: css.getPropertyValue('--string-off'), w: 0, dash: false };
    return { c: isC ? '#e06a5a' : isF ? '#5aa0e0' : css.getPropertyValue('--string'), w: isC || isF ? 0.6 : 0, dash: false };
  }
  function drawBed() {
    const c = $('#bed'); if (!c || !st.layout) return;
    const dpr = g.devicePixelRatio || 1; const W = c.clientWidth, H = c.clientHeight;
    if (!W) return;
    if (c.width !== W * dpr) { c.width = W * dpr; c.height = H * dpr; }
    const x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0);
    const css = getComputedStyle(document.documentElement);
    const grd = x.createLinearGradient(0, 0, 0, H); grd.addColorStop(0, css.getPropertyValue('--wood1')); grd.addColorStop(1, css.getPropertyValue('--wood2'));
    x.fillStyle = grd; x.fillRect(0, 0, W, H);
    const n = st.layout.tuning.length; const pad = 18; const step = (W - 2 * pad) / (n - 1);
    const mask = pressedBars().length ? currentMask() : null;
    const [za, zb] = E.windowRange(currentZone(), n);
    x.fillStyle = 'rgba(255,255,255,0.05)'; x.fillRect(pad + za * step - step / 2, 0, (zb - za + 1) * step, H);
    // pista de zona en práctica o canción
    const hz = st.practice && $('#prHints').checked ? st.practice.tgt.range : st.song && st.song.items[st.song.i] ? st.song.items[st.song.i].range : null;
    if (hz) { x.strokeStyle = css.getPropertyValue('--accent2'); x.setLineDash([6, 5]); x.lineWidth = 2; x.strokeRect(pad + hz[0] * step - step / 2, 4, (hz[1] - hz[0] + 1) * step, H - 8); x.setLineDash([]); }
    bed.x = [];
    for (let i = 0; i < n; i++) {
      const sx = pad + i * step; bed.x.push(sx);
      const on = !mask || mask[i];
      const sc = stringColor(i, on, css);
      const thick = 2.6 - 1.8 * (i / (n - 1)) + sc.w;
      x.strokeStyle = sc.c; x.lineWidth = thick + (i === bed.hover ? 1 : 0);
      if (sc.dash) x.setLineDash([4, 5]);
      x.beginPath(); x.moveTo(sx, 26); x.lineTo(sx, H - 34); x.stroke(); x.setLineDash([]);
      const vib = st.vib && st.vib[i] && (performance.now() - st.vib[i] < 900);
      if (vib && on) { x.strokeStyle = css.getPropertyValue('--accent'); x.globalAlpha = 0.5; x.lineWidth = thick + 3; x.beginPath(); x.moveTo(sx, 26); x.lineTo(sx, H - 34); x.stroke(); x.globalAlpha = 1; }
      const s = st.layout.tuning[i];
      x.fillStyle = on ? css.getPropertyValue('--text') : css.getPropertyValue('--string-off');
      x.font = '10px system-ui'; x.textAlign = 'center';
      if (step >= 18 || i % 2 === 0) { x.fillText(D.pc(s.pc), sx, 16); x.fillText(String(i + 1), sx, H - 22); }
    }
    drawLegend(x, W, H, css);
    drawAnimOverlay(x, W, H, pad, step, css);
    const live = st.anim || (st.vib && st.vib.some(v => v && performance.now() - v < 900));
    if (live && !st.anim) requestAnimationFrame(drawBed);
  }
  function drawLegend(x, W, H, css) {
    if (st.style === 'sober') return;
    const cC = st.style === 'contrast' ? '#ffb000' : '#e06a5a', cF = st.style === 'contrast' ? '#2ec5ff' : '#5aa0e0';
    const items = [[cC, t('leg.guide', { n: D.pc(0) })], [cF, t('leg.guide', { n: D.pc(5) })], [css.getPropertyValue('--string-off'), t('leg.felt')]];
    x.font = '11px system-ui'; x.textAlign = 'left';
    let lx = 12; const ly = H - 8;
    items.forEach(([c, l]) => { x.strokeStyle = c; x.lineWidth = 3; x.beginPath(); x.moveTo(lx, ly - 4); x.lineTo(lx + 14, ly - 4); x.stroke(); x.fillStyle = css.getPropertyValue('--text'); x.fillText(l, lx + 18, ly); lx += 26 + x.measureText(l).width; });
  }
  function drawAnimOverlay(x, W, H, pad, step, css) {
    const an = st.anim; if (!an) return;
    const acc = css.getPropertyValue('--accent2'), tt = an.runner.t, stt = an.runner.state;
    if (stt.sweep) {
      const sw = stt.sweep, cpos = P.sweepAt(sw, tt);
      x.fillStyle = acc; x.globalAlpha = 0.16; x.fillRect(pad + sw.a * step - step / 2, 0, (sw.b - sw.a + 1) * step, H); x.globalAlpha = 1;
      const cx = pad + cpos * step;
      x.strokeStyle = acc; x.lineWidth = 2; x.setLineDash([5, 4]); x.beginPath(); x.moveTo(cx, 22); x.lineTo(cx, H - 34); x.stroke(); x.setLineDash([]);
      x.fillStyle = acc; x.beginPath(); x.arc(cx, H / 2, 12, 0, 6.2832); x.fill();
      x.fillStyle = '#10201b'; x.font = 'bold 14px system-ui'; x.textAlign = 'center'; x.fillText('→', cx, H / 2 + 5);
    }
    stt.focus.forEach(f => {
      const sx = pad + f.s * step, k = ((tt - f.t) / 300) % 1;
      x.strokeStyle = acc; x.lineWidth = 3; x.beginPath(); x.arc(sx, H / 2, 10 + 10 * k, 0, 6.2832); x.stroke();
      x.fillStyle = acc; x.beginPath(); x.arc(sx, H / 2, 6, 0, 6.2832); x.fill();
    });
  }
  function stringAt(px) { let best = -1, d = 1e9; bed.x.forEach((sx, i) => { const dd = Math.abs(sx - px); if (dd < d) { d = dd; best = i; } }); return d < 14 ? best : -1; }
  function playString(i) {
    if (i < 0) return;
    const mask = pressedBars().length ? currentMask() : null;
    const sounded = !mask || !!mask[i];
    prLog({ type: 'pluck', s: i, sounded });
    songPluck();
    if (!sounded) return;
    st.audio.pluck(i); markVib([i]);
  }
  function markVib(list) { st.vib = st.vib || []; const tm = performance.now(); list.forEach(i => { st.vib[i] = tm; }); if (!st.anim) drawBed(); }
  function strumNow() {
    const n = st.layout.tuning.length, [a, b] = E.windowRange(currentZone(), n);
    const mask = pressedBars().length ? currentMask() : null;
    const all = []; for (let i = a; i <= b; i++) all.push(i);
    all.forEach(i => prLog({ type: 'pluck', s: i, sounded: !mask || !!mask[i] }));
    const strings = all.filter(i => !mask || mask[i]);
    st.audio.strum(strings, +$('#strumMs').value); markVib(strings);
    songPluck(3);
  }
  function bindBed() {
    const c = $('#bed');
    c.addEventListener('pointerdown', e => { c.setPointerCapture(e.pointerId); bed.dragging = true; const r = c.getBoundingClientRect(); bed.lastX = e.clientX - r.left; playString(stringAt(bed.lastX)); });
    c.addEventListener('pointermove', e => {
      const r = c.getBoundingClientRect(); const px = e.clientX - r.left;
      const h = stringAt(px); if (h !== bed.hover) { bed.hover = h; drawBed(); }
      if (!bed.dragging || bed.lastX === null) return;
      const lo = Math.min(bed.lastX, px), hi = Math.max(bed.lastX, px);
      const crossed = []; bed.x.forEach((sx, i) => { if (sx > lo && sx <= hi) crossed.push(i); });
      if (px < bed.lastX) crossed.reverse();
      crossed.forEach(playString); bed.lastX = px;
    });
    const end = () => { bed.dragging = false; bed.lastX = null; };
    c.addEventListener('pointerup', end); c.addEventListener('pointercancel', end);
    c.addEventListener('pointerleave', () => { bed.hover = -1; drawBed(); });
    g.addEventListener('resize', () => { drawBed(); if (st.anim) buildTimeline(); });
  }

  /* ---------- Teclado ---------- */
  function bindKeys() {
    document.addEventListener('keydown', e => {
      if (/input|textarea|select/i.test(e.target.tagName)) return;
      if (e.code === 'Space' && st.anim && !/button/i.test(e.target.tagName)) { e.preventDefault(); animToggle(); return; }
      if (!$('#tab-play').classList.contains('active')) return;
      if (e.code === 'Space') { e.preventDefault(); strumNow(); return; }
      if (e.key === 'Escape') { st.audio.dampAll(); return; }
      const b = st.keyBars.get(e.key.toLowerCase());
      if (b && !e.repeat) { e.preventDefault(); if ($('#latch').checked) toggleBar(b); else pressBar(b, true); }
    });
    document.addEventListener('keyup', e => {
      if ($('#latch').checked) return;
      const b = st.keyBars.get(e.key.toLowerCase()); if (b) pressBar(b, false);
    });
  }

  /* ---------- Buscador ---------- */
  function miniBed(r) {
    const n = st.layout.tuning.length; const set = new Set(r.strings); const pins = new Set(r.pinches || []);
    let h = '<div class="minibed">';
    for (let i = 0; i < n; i++) h += `<i class="${pins.has(i) ? 'pin' : set.has(i) ? 'on' : ''}"></i>`;
    return h + '</div>';
  }
  function difficulty(r) { const c = r.sc.S - r.rank; return t(c < 0.03 ? 'diff.easy' : c < 0.09 ? 'diff.medium' : 'diff.hard'); }
  function resultCard(r, chord) {
    const cls = E.classify(r.sc.S);
    const tun = st.layout.tuning;
    const pcs = Array.from(new Set(r.strings.map(i => tun[i].pc))).sort((a, b) => a - b).map(D.pc).join(' ');
    const det = [];
    if (r.sc.missing.length) det.push(t('card.missing', { x: r.sc.missing.map(D.pc).join(', ') }));
    if (r.sc.foreign.length) det.push(t('card.foreign', { x: r.sc.foreign.map(D.pc).join(', ') }));
    if (r.sc.inverted) det.push(t('card.inversion'));
    if (r.pinches && r.pinches.length) det.push(t('card.arp'));
    const card = el('div', { class: 'card' },
      `<div class="top-line"><span class="pct">${pct(r.sc.S)}</span><span class="badge ${cls.id}">${esc(cls.name)}</span></div>
       <div class="mech">${esc(E.mechanism(r))} · ${esc(t('card.exec', { d: difficulty(r) }))}</div>
       <div class="desc">${esc(E.describe(r, tun))}</div>${miniBed(r)}
       <div class="det">${esc(t('card.sound', { notes: pcs, n: r.strings.length }))}${det.length ? ' · ' + esc(det.join(' · ')) : ''}</div>`);
    const acts = el('div', { class: 'acts' });
    acts.appendChild(el('button', { class: 'primary', onclick: () => startAnim(r, chord, cls) }, esc(t('card.anim'))));
    acts.appendChild(el('button', { class: 'ghost', onclick: () => startPractice(r, chord) }, esc(t('card.turn'))));
    acts.appendChild(el('button', { class: 'ghost web-only', onclick: () => playRecipe(r) }, esc(t('card.listen'))));
    acts.appendChild(el('button', { class: 'ghost web-only', onclick: () => showOnBoard(r) }, esc(t('card.onboard'))));
    card.appendChild(acts);
    return card;
  }
  function playRecipe(r) {
    const a = st.audio; a.ensure(); a.dampAll();
    const base = r.strings.filter(i => !(r.pinches || []).includes(i));
    a.strum(base, +$('#strumMs').value); markVib(base);
    if (r.pinches && r.pinches.length) setTimeout(() => { r.pinches.forEach((p, k) => setTimeout(() => { a.pluck(p); markVib([p]); }, k * 160)); }, 260);
  }
  function showOnBoard(r) {
    closeAll(true);
    st.pressed.clear(); r.bars.forEach(b => st.pressed.add(b.id)); st.zone = r.window.id; $('#zoneSel').value = st.zone;
    switchTab('play'); $('#latch').checked = true; renderBars(); updateReadout(); drawBed();
    toast(t('toast.onboard') + (r.pinches.length ? ' ' + t('toast.pinch', { x: r.pinches.map(i => D.note(st.layout.tuning[i].name)).join(', ') }) : ''));
  }
  function runSearch(chord) {
    if (!chord) { $('#qTarget').textContent = t('search.bad', { ex: examples() }); $('#qResults').innerHTML = ''; return; }
    st.lastChord = chord;
    $('#qChord').value = D.chord(chord.name);
    const res = E.search(chord, st.cache, { top: 12, pinches: $('#qPinch').checked, maxButtons: +$('#qMaxB').value });
    $('#qTarget').innerHTML = esc(t('search.target', { chord: D.chord(chord.name), type: t('type.' + chord.type), notes: chord.tones.map(x => D.pc(x.pc)).join(' · '), layout: layoutName(st.layout) }));
    const box = $('#qResults'); box.innerHTML = '';
    if (!res.length) { box.innerHTML = `<p class="hint">${esc(t('search.none'))}</p>`; return; }
    res.forEach(r => box.appendChild(resultCard(r, chord)));
  }

  /* ---------- Animación de ejemplo ---------- */
  function rebuildPlan(an) { return P.build(st.layout, an.recipe, { label: an.chord && an.chord.name, pct: an.recipe.sc.S, className: E.classify(an.recipe.sc.S).name, leftHanded: EMBED && !!st.settings.mirror }); }
  function startAnim(r, chord) {
    const base = { recipe: r, chord };
    const plan = rebuildPlan(base);
    const b = bridge();
    if (EMBED && b && b.playExample) { b.playExample(JSON.stringify(plan)); return; }
    closeAll(true);
    switchTab('play');
    st.audio.ensure(); st.audio.dampAll(); st.pressed.clear();
    const runner = new P.Runner(plan, { press: animPress, pluck: animPluck, stop: () => st.audio.dampAll() }, { stepMode: $('#anStep').checked, speed: 0.75 });
    st.anim = Object.assign(base, { plan, runner, last: performance.now() });
    $('#animBar').hidden = false;
    $('#anTimeline').classList.toggle('open', g.innerWidth >= 700);
    buildProgress(); buildTimeline(); animLabels();
    requestAnimationFrame(animTick);
  }
  function animPress(idx) {
    const flat = flatBars();
    const ids = new Set(idx.map(k => flat[k] && flat[k].id).filter(Boolean));
    ids.forEach(id => { if (!st.pressed.has(id)) { const bar = flat.find(x => x.id === id); if (bar && st.audio.ctx) st.audio.applyMask(bar.mask); } });
    st.pressed = ids; st.animHands = new Set(ids); st.highlight = null;
    renderBars(); updateReadout();
  }
  function animPluck(s, vel, delayMs) {
    const m = pressedBars().length ? currentMask() : null;
    if (m && !m[s]) return;
    st.audio.ensure();
    st.audio.pluck(s, st.audio.ctx.currentTime + (delayMs || 0) / 1000, vel); markVib([s]);
  }
  function animLabels() {
    const an = st.anim; if (!an) return;
    const r = an.runner, plan = an.runner.plan, i = r.step();
    const done = r.done();
    $('#anPlay').textContent = r.playing ? t('an.pause') : done ? t('an.repeat') : t('an.play');
    $('#anSpeed').textContent = r.speed + '×';
    $('#anHead').textContent = done ? (plan.label || '') : plan.steps[i].head;
    $('#anBody').textContent = done ? plan.result : plan.steps[i].text;
    document.querySelectorAll('#anProg .seg').forEach((s, k) => { s.classList.toggle('cur', k === i && !done); s.classList.toggle('past', k < i || done); });
  }
  function animTick(now) {
    const an = st.anim; if (!an) return;
    const dt = Math.min(100, now - an.last); an.last = now;
    an.runner.stepMode = $('#anStep').checked;
    const wasPlaying = an.runner.playing;
    const changed = an.runner.tick(dt);
    if (changed || wasPlaying !== an.runner.playing) animLabels();
    moveCursors();
    drawBed();
    requestAnimationFrame(animTick);
  }
  function animToggle() { const an = st.anim; if (!an) return; an.runner.toggle(); an.last = performance.now(); animLabels(); }
  function animClose(silent) {
    if (!st.anim) return;
    st.anim = null; st.animHands.clear(); $('#animBar').hidden = true;
    if (!silent) { st.audio.dampAll(); st.pressed.clear(); renderBars(); updateReadout(); drawBed(); }
  }
  function buildProgress() {
    const an = st.anim, box = $('#anProg'); box.innerHTML = '';
    an.runner.plan.steps.forEach((s, i) => {
      const seg = el('div', { class: 'seg', title: s.title }, `<i></i><span>${i + 1} ${esc(s.title)}</span>`);
      seg.style.flexGrow = String(s.t1 - s.t0);
      seg.addEventListener('click', () => { an.runner.goStep(i); an.last = performance.now(); animLabels(); });
      box.appendChild(seg);
    });
    box.appendChild(el('div', { class: 'cursor', id: 'anProgCur' }));
  }
  /** Línea de tiempo: una fila por barra (presiona/suelta), una por la mano que toca las cuerdas y una de lo que suena. */
  function buildTimeline() {
    const an = st.anim; if (!an) return;
    const box = $('#anTimeline'), plan = an.runner.plan;
    const W = Math.max(320, box.clientWidth || 800), LX = 130, LW = W - LX - 14, dur = plan.duration;
    const px = v => LX + LW * v / dur;
    const rowH = 30;
    let y = 26, s = '';
    plan.steps.forEach((stp, i) => {
      if (i) s += `<line x1="${px(stp.t0)}" y1="6" x2="${px(stp.t0)}" y2="999" class="tl-sep"/>`;
      s += `<text x="${px(stp.t0) + 4}" y="17" class="tl-step">${i + 1} ${esc(stp.title)}</text>`;
    });
    const hb = plan.steps[0].hand, hs = plan.steps[1] ? plan.steps[1].hand : '';
    s += `<text x="8" y="${y + 12}" class="tl-group">${esc(hb.toUpperCase())}</text>`; y += 16;
    plan.lanes.bars.forEach(l => {
      s += `<text x="8" y="${y + 18}" class="tl-label">${esc(t('an.bar', { b: l.label }))}</text>`;
      s += `<rect x="${px(l.t0)}" y="${y + 4}" width="${Math.max(4, px(l.t1) - px(l.t0))}" height="20" rx="6" class="tl-bar"/>`;
      s += `<text x="${px(l.t0) + 6}" y="${y + 18}" class="tl-in">${esc(t('an.pressed'))}</text>`;
      if (l.t1 < dur) s += `<text x="${px(l.t1) - 6}" y="${y + 18}" class="tl-in" text-anchor="end">${esc(t('an.released'))}</text>`;
      y += rowH;
    });
    s += `<text x="8" y="${y + 12}" class="tl-group">${esc(hs.toUpperCase())}</text>`; y += 16;
    s += `<text x="8" y="${y + 22}" class="tl-label">${esc(t('an.strings'))}</text>`;
    plan.lanes.right.forEach(l => {
      if (l.type === 'strum') s += `<polygon points="${px(l.t0)},${y + 28} ${px(l.t1) + 2},${y + 6} ${px(l.t1) + 2},${y + 28}" class="tl-strum"/><text x="${px(l.t0)}" y="${y + 42}" class="tl-act">${esc(l.text)}</text>`;
      else s += `<circle cx="${px(l.t)}" cy="${y + 18}" r="7" class="tl-pinch"/><text x="${px(l.t)}" y="${y + 42}" class="tl-act" text-anchor="middle">${esc(l.text)}</text>`;
    });
    y += 50;
    s += `<text x="8" y="${y + 16}" class="tl-group">${esc(t('an.sound').toUpperCase())}</text>`;
    plan.lanes.sound.forEach(l => { s += `<text x="${px(l.t)}" y="${y + 16}" class="tl-sound">${esc(l.text)}</text>`; });
    y += 28;
    s += `<text x="8" y="${y + 10}" class="tl-hint">${esc(t('an.seekHint'))}</text>`;
    const H = y + 16;
    s = s.replace(/y2="999"/g, `y2="${H - 18}"`);
    s += `<line id="tlCur" x1="${LX}" y1="6" x2="${LX}" y2="${H - 18}" class="tl-cur"/>`;
    box.innerHTML = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">${s}</svg>`;
    const svg = box.querySelector('svg');
    svg.addEventListener('click', e => {
      const r = svg.getBoundingClientRect(), xx = e.clientX - r.left;
      if (xx < LX) return;
      an.runner.seek((xx - LX) / LW * dur); an.runner.playing = false; animLabels(); moveCursors();
    });
    an.tl = { LX, LW, dur };
    moveCursors();
  }
  function moveCursors() {
    const an = st.anim; if (!an) return;
    const f = an.runner.t / an.runner.plan.duration;
    const c = $('#tlCur'); if (c && an.tl) { const xx = an.tl.LX + an.tl.LW * f; c.setAttribute('x1', xx); c.setAttribute('x2', xx); }
    const p = $('#anProgCur'); if (p) p.style.left = (f * 100) + '%';
  }

  /* ---------- Tu turno ---------- */
  function startPractice(r, chord) {
    const tgt = PR.target(st.layout, r, chord.name);
    const head = t('pr.title', { chord: D.chord(chord.name) }), body = t('pr.do', { how: E.describe(r, st.layout.tuning) });
    st.practiceTgt = tgt; st.practiceRecipe = { r, chord };
    const b = bridge();
    if (EMBED && b && b.startPractice) { b.startPractice(JSON.stringify({ target: tgt, head, body })); return; }
    closeAll(true); switchTab('play');
    st.audio.ensure(); st.audio.dampAll(); st.pressed.clear();
    st.practice = { tgt, r, chord, log: [{ t: performance.now(), type: 'press', bars: [] }], timer: null, head, body };
    $('#prBar').hidden = false; prShow(head, body, []);
    renderBars(); updateReadout(); drawBed();
  }
  function prShow(head, body, items) {
    $('#prHead').textContent = head; $('#prBody').textContent = body;
    const ul = $('#prList'); ul.innerHTML = '';
    items.forEach(it => ul.appendChild(el('li', { class: it.ok ? 'ok' : 'bad' }, (it.ok ? '✓ ' : '✗ ') + esc(it.text))));
  }
  function prLog(e) {
    const p = st.practice; if (!p) return;
    e.t = performance.now(); p.log.push(e);
    if (e.type === 'pluck') { clearTimeout(p.timer); p.timer = setTimeout(prEvaluate, 1300); }
  }
  function prEvaluate() {
    const p = st.practice; if (!p) return;
    const res = PR.evaluate(st.layout, p.tgt, p.log);
    prShow(res.title || '', '', res.items);
    p.log = [{ t: performance.now(), type: 'press', bars: pressedIdx() }];
  }
  function prAgain() { const p = st.practice; if (!p) return; p.log = [{ t: performance.now(), type: 'press', bars: pressedIdx() }]; prShow(p.head, p.body, []); }
  function prClose(silent) {
    if (!st.practice) return; clearTimeout(st.practice.timer); st.practice = null; $('#prBar').hidden = true;
    if (!silent) { renderBars(); drawBed(); }
  }
  /** Para Android: evalúa el registro que manda la app y devuelve el resultado ya traducido. */
  function evalPractice(logJson) {
    try { const log = typeof logJson === 'string' ? JSON.parse(logJson) : logJson; return PR.evaluate(st.layout, st.practiceTgt, log); }
    catch (e) { return { verdict: 'none', title: '', items: [{ ok: false, text: String(e.message || e) }] }; }
  }

  /* ---------- Modo canción ---------- */
  function songsLoad() { try { return JSON.parse(ls.get(LS_SONGS, '[]')); } catch (e) { return []; } }
  function songsSave(list) { ls.set(LS_SONGS, JSON.stringify(list)); }
  function renderSongTab() {
    if (!st.layout) return;
    const prev = $('#sPreview'); prev.innerHTML = '';
    const res = PR.resolveSong($('#sText').value, st.layout, st.cache);
    const seen = new Set();
    res.items.forEach(it => {
      if (seen.has(it.chord)) return; seen.add(it.chord);
      prev.appendChild(el('div', { class: 'song-item' + (it.playable ? '' : ' bad') }, `<b>${esc(D.chord(it.chord))}</b> <span class="pctx">${pct(it.S)}</span> <span class="hint">${esc(it.playable ? it.how : t('song.unplayable'))}</span>`));
    });
    if (res.bad.length) prev.appendChild(el('p', { class: 'hint' }, esc(t('opt.ignored', { x: res.bad.join(', ') }))));
    const list = $('#sList'); list.innerHTML = '';
    songsLoad().forEach((s, i) => {
      const row = el('div', { class: 'song-row' }, `<b>${esc(s.name)}</b> <span class="hint">${esc(s.text.split(/\s+/).slice(0, 8).join(' '))}…</span>`);
      row.appendChild(el('button', { class: 'ghost', onclick: () => { $('#sName').value = s.name; $('#sText').value = s.text; renderSongTab(); } }, esc(t('song.open'))));
      row.appendChild(el('button', { class: 'ghost', onclick: () => { const l = songsLoad(); l.splice(i, 1); songsSave(l); renderSongTab(); } }, esc(t('song.del'))));
      list.appendChild(row);
    });
  }
  function startSong() {
    const name = $('#sName').value.trim() || t('song.defaultName');
    const res = PR.resolveSong($('#sText').value, st.layout, st.cache);
    if (!res.items.length) { toast(t('song.empty')); return; }
    if (res.bad.length) toast(t('opt.ignored', { x: res.bad.join(', ') }));
    const b = bridge();
    if (EMBED && b && b.startSong) {
      b.startSong(JSON.stringify({ name, items: res.items.map(it => ({ chord: D.chord(it.chord), barIdx: it.barIdx, range: it.range, playable: it.playable, how: it.how })) }));
      return;
    }
    closeAll(true); switchTab('play');
    st.audio.ensure(); st.pressed.clear();
    st.song = { name, items: res.items, i: 0, hits: [], block: 0 };
    $('#sgBar').hidden = false; renderSongBar(); renderBars(); updateReadout(); drawBed();
  }
  function renderSongBar() {
    const s = st.song; if (!s) return;
    const it = s.items[s.i], nx = s.items[s.i + 1];
    $('#sgHead').textContent = t('song.bar', { name: s.name, i: s.i + 1, n: s.items.length });
    $('#sgBody').textContent = (it.playable ? D.chord(it.chord) + ': ' + it.how : D.chord(it.chord) + ' · ' + t('song.unplayable')) + (nx ? ' · ' + t('song.next', { x: D.chord(nx.chord) }) : ' · ' + t('song.done'));
    const box = $('#sgChips'); box.innerHTML = '';
    s.items.forEach((x, k) => {
      const c = el('button', { class: 'sg-chip' + (k === s.i ? ' cur' : k === s.i + 1 ? ' next' : '') + (x.playable ? '' : ' bad') }, esc(D.chord(x.chord)));
      c.addEventListener('click', () => songGo(k)); box.appendChild(c);
    });
    const cur = box.children[s.i]; if (cur && cur.scrollIntoView) cur.scrollIntoView({ block: 'nearest', inline: 'center' });
  }
  function songGo(k) { const s = st.song; if (!s) return; s.i = Math.max(0, Math.min(s.items.length - 1, k)); s.hits = []; renderSongBar(); renderBars(); drawBed(); }
  /** Avance automático: tres cuerdas o más en medio segundo con las barras de la canción presionadas. */
  function songPluck(n) {
    const s = st.song; if (!s || !$('#sgAuto').checked) return;
    const now = performance.now(); if (now < s.block) return;
    const it = s.items[s.i]; if (!it) return;
    const want = it.barIdx.slice().sort().join(','), have = pressedIdx().sort().join(',');
    if (want !== have) { s.hits = []; return; }
    for (let k = 0; k < (n || 1); k++) s.hits.push(now);
    s.hits = s.hits.filter(x => now - x < 600);
    if (s.hits.length >= 3 && s.i < s.items.length - 1) { s.block = now + 700; s.hits = []; setTimeout(() => songGo(s.i + 1), 250); }
  }
  function songClose(silent) { if (!st.song) return; st.song = null; $('#sgBar').hidden = true; if (!silent) { renderBars(); drawBed(); } }
  function closeAll(silent) { animClose(silent); prClose(silent); songClose(silent); }

  /* ---------- Tabla de acordes ---------- */
  function runCoverage() {
    const grid = E.coverage(st.cache, null, { pinches: $('#cPinch').checked });
    const tb = $('#cTable'); tb.innerHTML = '';
    const head = el('tr'); head.appendChild(el('th', null, ''));
    for (let r = 0; r < 12; r++) head.appendChild(el('th', null, esc(D.pc(r))));
    tb.appendChild(head);
    let n = 0, ex = 0, fu = 0, sum = 0;
    grid.forEach(row => {
      const tr = el('tr'); const ty = T.TYPES.find(x => x.id === row.type);
      tr.appendChild(el('th', { title: t('type.' + ty.id) }, esc(ty.suf || t('type.majShort'))));
      row.cells.forEach(cell => {
        const cls = cell.best ? E.classify(cell.S).id : 'none';
        n++; sum += cell.S; if (cls === 'exacto') ex++; if (cls === 'exacto' || cls === 'funcional') fu++;
        const td = el('td', { class: cls, title: D.chord(cell.chord.name) + (cell.best ? ' · ' + E.describe(cell.best, st.layout.tuning) : ' · ' + t('cls.none')) }, cell.best ? Math.round(cell.S * 100) : '–');
        td.addEventListener('click', () => { switchTab('search'); runSearch(cell.chord); g.scrollTo(0, 0); });
        tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
    $('#cSummary').innerHTML = `<div class="kpi"><b>${ex}</b><span>${esc(t('kpi.exact', { n }))}</span></div><div class="kpi"><b>${fu}</b><span>${esc(t('kpi.func'))}</span></div><div class="kpi"><b>${pct(sum / n)}</b><span>${esc(t('kpi.avg'))}</span></div><div class="kpi"><b>${flatBars().length}</b><span>${esc(t('kpi.bars'))}</span></div>`;
  }

  /* ---------- Imágenes de fieltrado ---------- */
  /** Una o dos franjas de fieltro vistas desde arriba: muesca = la cuerda suena. */
  function feltSVG(rows, opts) {
    const tun = st.layout.tuning, n = tun.length, CW = 22, LX = 92, W = LX + n * CW + 12;
    const css = getComputedStyle(document.documentElement);
    const txt = css.getPropertyValue('--text').trim() || '#f1e8dc', mut = css.getPropertyValue('--muted').trim() || '#a8998a';
    const diff = rows.length === 2 ? rows[0].mask.map((v, i) => (v === rows[1].mask[i] ? 0 : rows[1].mask[i] ? 1 : -1)) : null;
    let y = 8, s = '';
    for (let i = 0; i < n; i++) {
      const x = LX + i * CW + CW / 2;
      s += `<text x="${x}" y="${y + 10}" font-size="9" fill="${mut}" text-anchor="middle">${i + 1}</text>`;
      s += `<text x="${x}" y="${y + 22}" font-size="9" fill="${txt}" text-anchor="middle">${esc(D.pc(tun[i].pc))}</text>`;
    }
    y += 30;
    if (diff) {
      for (let i = 0; i < n; i++) if (diff[i]) {
        const x = LX + i * CW;
        s += `<rect x="${x + 1}" y="${y}" width="${CW - 2}" height="${rows.length * 44 + 20}" rx="4" fill="${diff[i] > 0 ? 'rgba(63,169,122,.22)' : 'rgba(224,106,90,.22)'}"/>`;
      }
    }
    rows.forEach((row, ri) => {
      s += `<text x="8" y="${y + 24}" font-size="12" font-weight="700" fill="${txt}">${esc(row.label)}</text>`;
      s += `<rect x="${LX}" y="${y + 8}" width="${n * CW}" height="26" rx="4" fill="#8b7355" stroke="#5e4a33"/>`;
      for (let i = 0; i < n; i++) {
        const x = LX + i * CW + CW / 2;
        if (row.mask[i]) s += `<rect x="${x - 6}" y="${y + 8}" width="12" height="15" fill="#2a1f16"/>`;
        s += `<line x1="${x}" y1="${y + 2}" x2="${x}" y2="${y + 40}" stroke="#d9d2c5" stroke-width="1" opacity=".55"/>`;
      }
      y += 44;
      if (diff && ri === 0) {
        for (let i = 0; i < n; i++) if (diff[i]) s += `<text x="${LX + i * CW + CW / 2}" y="${y + 13}" font-size="13" font-weight="700" text-anchor="middle" fill="${diff[i] > 0 ? '#3fa97a' : '#e06a5a'}">${diff[i] > 0 ? '✂' : '■'}</text>`;
        y += 20;
      }
    });
    if (diff) {
      s += `<text x="${LX}" y="${y + 16}" font-size="11" fill="#3fa97a">✂ ${esc(t('felt.cut'))}</text>`;
      s += `<text x="${LX + 320}" y="${y + 16}" font-size="11" fill="#e06a5a">■ ${esc(t('felt.fill'))}</text>`;
      y += 22;
    }
    s += `<text x="${LX}" y="${y + 14}" font-size="10" fill="${mut}">${esc(t('felt.legend'))}</text>`;
    y += 22;
    const title = opts && opts.title ? `<text x="8" y="18" font-size="14" font-weight="700" fill="${txt}">${esc(opts.title)}</text>` : '';
    const top = opts && opts.title ? 26 : 0;
    return { svg: `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${y + top}" viewBox="0 0 ${W} ${y + top}"><rect width="100%" height="100%" fill="${css.getPropertyValue('--panel').trim() || '#261f18'}"/>${title}<g transform="translate(0,${top})">${s}</g></svg>`, W, H: y + top };
  }
  function downloadSVG(fig, name) {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas'); c.width = fig.W * 2; c.height = fig.H * 2;
      const x = c.getContext('2d'); x.scale(2, 2); x.drawImage(img, 0, 0);
      const url = c.toDataURL('image/png');
      const b = bridge();
      if (EMBED && b && b.saveImage) { toast(t('felt.saved', { x: b.saveImage(url, name) })); return; }
      const a = el('a', { href: url, download: name }); document.body.appendChild(a); a.click(); a.remove();
    };
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(fig.svg);
  }
  function feltCard(c, before, after) {
    const fig = feltSVG([{ label: t('felt.before'), mask: Array.from(before.mask) }, { label: t('felt.after'), mask: Array.from(after.mask) }],
      { title: t('felt.title', { from: D.chord(c.from), to: D.chord(c.to) }) });
    const cut = [], fill = [];
    for (let i = 0; i < before.mask.length; i++) { if (!before.mask[i] && after.mask[i]) cut.push(i); if (before.mask[i] && !after.mask[i]) fill.push(i); }
    const lab = arr => arr.map(i => (i + 1) + ' (' + D.note(st.layout.tuning[i].name) + ')').join(', ');
    const card = el('div', { class: 'card felt-card', style: 'grid-column:1/-1' });
    card.appendChild(el('div', { class: 'felt-fig' }, fig.svg));
    if (cut.length) card.appendChild(el('p', { class: 'desc' }, esc(t('felt.cutList', { x: lab(cut) }))));
    if (fill.length) card.appendChild(el('p', { class: 'desc' }, esc(t('felt.fillList', { x: lab(fill) }))));
    card.appendChild(el('button', { class: 'ghost', onclick: () => downloadSVG(fig, 'fieltro-' + c.to.replace(/[^\w#]+/g, '_') + '.png') }, esc(t('felt.download'))));
    return card;
  }
  function feltSheet() {
    const L = st.proposal || st.layout;
    const rows = L.rows.flat().map(b => ({ label: D.chord(b.label), mask: Array.from(b.mask) }));
    const fig = feltSVG(rows, { title: t('felt.sheetTitle', { layout: layoutName(L) }) });
    const out = $('#oOut');
    const card = el('div', { class: 'card felt-card', style: 'grid-column:1/-1' });
    card.appendChild(el('div', { class: 'felt-fig' }, fig.svg));
    card.appendChild(el('button', { class: 'ghost', onclick: () => downloadSVG(fig, 'hoja-fieltrado.png') }, esc(t('felt.download'))));
    out.insertBefore(card, out.firstChild);
  }

  /* ---------- Optimizador ---------- */
  function runOptimize() {
    const rep = O.parseRepertoire($('#oRep').value);
    const out = $('#oOut'); out.innerHTML = '';
    if (rep.bad.length) toast(t('opt.ignored', { x: rep.bad.join(', ') }));
    if (!rep.items.length) { out.innerHTML = `<p class="hint">${esc(t('opt.empty'))}</p>`; return; }
    out.innerHTML = `<p class="hint">${esc(t('opt.calc'))}</p>`;
    setTimeout(() => {
      const locked = new Set($('#oLocked').value.split(/[\s,]+/).filter(Boolean).map(x => { const c = T.parseChord(x); return c ? c.name : x; }));
      const r = O.optimize(st.layout, rep.items, { steps: +$('#oSteps').value, locked });
      st.proposal = r.layout; st.optResult = r; $('#oApply').disabled = !r.changes.length;
      out.innerHTML = '';
      const sum = el('div', { class: 'card' }, `<div class="top-line"><span class="pct">${pct(r.before.value)} → ${pct(r.after.value)}</span><span class="badge ${E.classify(r.after.value).id}">${esc(t('opt.cover'))}</span></div>
        <div class="desc">${r.changes.length ? r.changes.map(c => t('opt.change', { from: esc(D.chord(c.from)), r: c.row + 1, c: c.col + 1, to: esc(D.chord(c.to)), gain: pct(c.gain) })).join('<br>') : esc(t('opt.noChange'))}</div>`);
      out.appendChild(sum);
      r.changes.forEach(c => out.appendChild(feltCard(c, st.layout.rows[c.row][c.col], r.layout.rows[c.row][c.col])));
      const tb = el('table', { class: 'simple' }, `<tr><th>${esc(t('opt.thChord'))}</th><th>${esc(t('opt.thW'))}</th><th>${esc(t('opt.thBefore'))}</th><th>${esc(t('opt.thAfter'))}</th><th>${esc(t('opt.thHow'))}</th></tr>`);
      r.after.per.forEach((p, i) => { const b = r.before.per[i]; tb.appendChild(el('tr', null, `<td>${esc(D.chord(p.chord.name))}</td><td>${p.w}</td><td>${pct(b.S)}</td><td>${pct(p.S)}</td><td>${p.best ? esc(E.describe(p.best, st.layout.tuning)) : '—'}</td>`)); });
      const wrap = el('div', { class: 'card', style: 'grid-column:1/-1' }); wrap.appendChild(tb); out.appendChild(wrap);
    }, 20);
  }

  /* ---------- Reacomodo ---------- */
  function gridHtml(layout, moved) {
    let h = '<div class="bars small">';
    layout.rows.forEach((r, ri) => { h += `<div class="bar-row" style="margin-left:${ri * 22}px">` + r.map(b => `<span class="bar-btn mini${moved.has(b.label) ? ' moved' : ''}">${esc(D.chord(b.label))}</span>`).join('') + '</div>'; });
    return h + '</div>';
  }
  function runArrange() {
    const out = $('#aOut'); out.innerHTML = `<p class="hint">${esc(t('opt.calc'))}</p>`;
    setTimeout(() => {
      const locked = new Set($('#aLocked').value.split(/[\s,]+/).filter(Boolean).map(x => { const c = T.parseChord(x); return c ? c.name : x; }));
      const r = AH.arranger.arrange(st.layout, { progressions: $('#aProg').value, locked, withinRows: $('#aRows').checked });
      st.arranged = r.layout; $('#aApply').disabled = !r.moves.length;
      if (r.bad.length) toast(t('opt.ignored', { x: r.bad.join(', ') }));
      const moved = new Set(r.moves.map(m => m.label));
      const f = (x, d) => x.toFixed(d === undefined ? 2 : d);
      const b = r.before, a = r.after;
      out.innerHTML = '';
      out.appendChild(el('div', { class: 'card' }, `<div class="top-line"><b>${esc(t('opt.thBefore'))}</b></div>${gridHtml(st.layout, new Set())}`));
      out.appendChild(el('div', { class: 'card' }, `<div class="top-line"><b>${esc(t('opt.thAfter'))}</b><span class="badge funcional">${esc(t('arr.moved', { n: r.moves.length }))}</span></div>${gridHtml(r.layout, moved)}`));
      const tb = el('table', { class: 'simple' }, `<tr><th>${esc(t('arr.ind'))}</th><th>${esc(t('opt.thBefore'))}</th><th>${esc(t('opt.thAfter'))}</th></tr>
        <tr><td>${esc(t('arr.travel'))}</td><td>${r.transitions ? f(b.travelAvg) : '—'}</td><td>${r.transitions ? f(a.travelAvg) : '—'}</td></tr>
        <tr><td>${esc(t('arr.near'))}</td><td>${r.transitions ? pct(b.nearPct) : '—'}</td><td>${r.transitions ? pct(a.nearPct) : '—'}</td></tr>
        <tr><td>${esc(t('arr.harm'))}</td><td>${f(b.harmony, 1)} / ${b.harmonyMax}</td><td>${f(a.harmony, 1)} / ${a.harmonyMax}</td></tr>
        <tr><td>${esc(t('arr.keys'))}</td><td>${b.keysIVV.map(D.chord).join(' ') || '—'}</td><td>${a.keysIVV.map(D.chord).join(' ') || '—'}</td></tr>`);
      const wrap = el('div', { class: 'card', style: 'grid-column:1/-1' }); wrap.appendChild(tb);
      if (r.missing.length) wrap.appendChild(el('p', { class: 'hint' }, esc(t('arr.missing', { x: r.missing.map(D.chord).join(', ') }))));
      if (r.moves.length) wrap.appendChild(el('p', { class: 'desc' }, esc(t('arr.moves', { x: r.moves.map(m => t('arr.move', { label: D.chord(m.label), r1: m.from.r + 1, c1: m.from.c + 1, r2: m.to.r + 1, c2: m.to.c + 1 })).join(' · ') }))));
      out.appendChild(wrap);
    }, 20);
  }

  /* ---------- Editor ---------- */
  function renderEditor() {
    const box = $('#eBars'); box.innerHTML = '';
    st.layout.rows.forEach((row, ri) => {
      const r = el('div', { class: 'bar-row' });
      row.forEach((b, ci) => {
        const btn = el('button', { class: 'bar-btn' + (st.editSel && st.editSel.b === b ? ' sel' : '') }, `<span class="src ${b.source}"></span>${esc(D.chord(b.label))}`);
        btn.addEventListener('click', () => { st.editSel = { b, ri, ci }; renderEditor(); });
        r.appendChild(btn);
      });
      box.appendChild(r);
    });
    const grid = $('#eStrings'); grid.innerHTML = '';
    const sel = st.editSel && st.editSel.b;
    $('#eLabel').value = sel ? D.chord(sel.label) : '';
    st.layout.tuning.forEach((s, i) => {
      const on = sel ? !!sel.mask[i] : false;
      const btn = el('button', { class: on ? 'on' : '', title: (i + 1) + ' · ' + D.note(s.name) }, (i + 1) + ' ' + esc(D.note(s.name)));
      btn.disabled = !sel;
      btn.addEventListener('click', () => { sel.mask[i] = sel.mask[i] ? 0 : 1; sel.source = 'custom'; afterEdit(); });
      grid.appendChild(btn);
    });
    if (sel) {
      const strings = []; sel.mask.forEach((v, i) => { if (v) strings.push(i); });
      const id = strings.length ? E.identify(strings, st.layout.tuning, 3) : [];
      $('#eInfo').textContent = strings.length ? t('ed.soundsLike', { x: id.map(x => D.chord(x.chord.name) + ' ' + pct(x.sc.S)).join(' · '), n: strings.length, src: t('src.' + sel.source) }) + (sel.note ? ' · ' + sel.note : '') : t('ed.empty');
    } else $('#eInfo').textContent = t('ed.select');
  }
  function afterEdit() { st.cache = E.buildCache(st.layout); renderEditor(); renderBars(); updateReadout(); drawBed(); notifyLayout(); }
  function bindEditor() {
    $('#eLabel').addEventListener('change', () => { if (st.editSel) { const v = $('#eLabel').value.trim(); const c = T.parseChord(v); st.editSel.b.label = c ? c.name : (v || '?'); afterEdit(); } });
    $('#eFromChord').addEventListener('click', () => {
      if (!st.editSel) return toast(t('ed.select'));
      const c = T.parseChord($('#eLabel').value.trim());
      if (!c) return toast(t('ed.badChord'));
      const nb = I.barFromChord(c.name, st.layout.tuning); st.editSel.b.mask = nb.mask; st.editSel.b.label = nb.label; st.editSel.b.source = 'custom'; afterEdit();
    });
    $('#eAdd').addEventListener('click', () => {
      const ri = st.editSel ? st.editSel.ri : st.layout.rows.length - 1;
      const nb = I.barFromChord('C', st.layout.tuning); nb.source = 'custom';
      st.layout.rows[ri].push(nb); st.editSel = { b: nb, ri, ci: st.layout.rows[ri].length - 1 }; rebindKeys(); afterEdit();
    });
    $('#eDel').addEventListener('click', () => {
      if (!st.editSel) return; const { ri, ci } = st.editSel; st.layout.rows[ri].splice(ci, 1);
      st.layout.rows = st.layout.rows.filter(r => r.length); st.editSel = null; st.pressed.clear(); rebindKeys(); afterEdit();
    });
    const move = (dr, dc) => {
      if (!st.editSel) return; let { b, ri, ci } = st.editSel; const rows = st.layout.rows;
      rows[ri].splice(ci, 1);
      let nr = ri + dr; if (nr < 0) { rows.unshift([]); nr = 0; ri++; } if (nr >= rows.length) rows.push([]);
      const nc = dr ? Math.min(ci, rows[nr].length) : Math.max(0, Math.min(rows[nr].length, ci + dc));
      rows[nr].splice(nc, 0, b);
      st.layout.rows = rows.filter(r => r.length);
      const fr = st.layout.rows.findIndex(r => r.includes(b));
      st.editSel = { b, ri: fr, ci: st.layout.rows[fr].indexOf(b) }; rebindKeys(); afterEdit();
    };
    $('#eLeft').addEventListener('click', () => move(0, -1)); $('#eRight').addEventListener('click', () => move(0, 1));
    $('#eUp').addEventListener('click', () => move(-1, 0)); $('#eDown').addEventListener('click', () => move(1, 0));
    $('#eHear').addEventListener('click', () => { if (!st.editSel) return; const s = []; st.editSel.b.mask.forEach((v, i) => { if (v) s.push(i); }); st.audio.dampAll(); st.audio.strum(s); });
    $('#eSave').addEventListener('click', () => {
      const name = $('#eName').value.trim() || 'Mi layout';
      const ser = I.serializeLayout(st.layout); ser.name = name; ser.id = 'cus' + Date.now();
      const idx = st.customDefs.findIndex(d => d.name === name);
      if (idx >= 0) st.customDefs[idx] = ser; else st.customDefs.push(ser);
      saveCustom(); st.layout.name = name; st.layout.id = ser.id;
      st.layoutKey = 'cus:' + (idx >= 0 ? idx : st.customDefs.length - 1); ls.set(LS_LAST, st.layoutKey);
      fillLayoutSelect(st.layoutKey); toast(t('ed.saved', { x: name })); notifyLayout();
    });
    $('#eDelLayout').addEventListener('click', () => {
      const v = $('#layoutSel').value; if (!v.startsWith('cus:')) return toast(t('ed.onlyOwn'));
      st.customDefs.splice(+v.slice(4), 1); saveCustom(); fillLayoutSelect('def:os21'); selectLayout('def:os21'); toast(t('ed.deleted'));
    });
  }
  function rebindKeys() {
    st.keyBars.clear();
    st.layout.rows.forEach((r, ri) => r.forEach((b, ci) => { const k = (KEYROWS[ri] || '')[ci]; if (k) st.keyBars.set(k, b); }));
    if (st.keyBars.has('ñ')) st.keyBars.set(';', st.keyBars.get('ñ'));
  }

  /* ---------- Ajustes ---------- */
  function buildSettings() {
    const b = bridge(), box = $('#setBox'); box.innerHTML = '';
    if (!EMBED || !b || !b.getSettings) return;
    let cur = {}; try { cur = JSON.parse(b.getSettings()); } catch (e) { /* */ }
    [['latch', 'set.latch'], ['mirror', 'set.mirror'], ['studio', 'set.studio'], ['force', 'set.force'], ['latency', 'set.latency']].forEach(([k, key]) => {
      const cb = el('input', { type: 'checkbox' }); cb.checked = !!cur[k];
      cb.addEventListener('change', () => { saveSetting(k, cb.checked); });
      const l = el('label', { class: 'chk' }); l.appendChild(cb); l.appendChild(document.createTextNode(' ' + t(key))); box.appendChild(l);
    });
    box.appendChild(el('button', { class: 'ghost', onclick: () => b.resetStats() }, esc(t('set.reset'))));
  }

  /* ---------- Recorrido guiado (escritorio y web) ---------- */
  const TOUR = [['#barsPanel', 'tour.1t', 'tour.1'], ['#bedPanel', 'tour.2t', 'tour.2d'], ['.tabs button[data-tab=coverage]', 'tour.3t', 'tour.3'], ['.tabs', 'tour.4t', 'tour.4']];
  let tourI = 0;
  function startTour() {
    const b = bridge();
    if (EMBED && b && b.startTour) { b.startTour(); return; }
    switchTab('play'); tourI = 0; $('#tour').hidden = false; showTourStep();
  }
  function showTourStep() {
    const [sel, tt, tp] = TOUR[tourI];
    const target = $(sel); if (!target) return endTour();
    target.scrollIntoView({ block: 'center' });
    setTimeout(() => {
      const r = target.getBoundingClientRect(), spot = $('#tourSpot'), card = $('#tourCard');
      Object.assign(spot.style, { left: (r.left - 6) + 'px', top: (r.top - 6) + 'px', width: (r.width + 12) + 'px', height: (r.height + 12) + 'px' });
      $('#tourN').textContent = (tourI + 1) + ' / ' + TOUR.length; $('#tourT').textContent = t(tt); $('#tourP').textContent = t(tp);
      $('#tourPrev').style.visibility = tourI ? 'visible' : 'hidden';
      $('#tourNext').textContent = tourI === TOUR.length - 1 ? t('tour.done') : t('tour.next');
      const below = r.bottom + 12 + 190 < g.innerHeight;
      card.style.top = (below ? r.bottom + 14 : Math.max(10, r.top - 204)) + 'px';
      card.style.left = Math.max(10, Math.min(g.innerWidth - 380, r.left)) + 'px';
    }, 120);
  }
  function endTour() { $('#tour').hidden = true; ls.set(LS_TOUR, '1'); }

  /* ---------- Modo embebido (menú y tabla dentro de la app Android) ---------- */
  function openMode(mode) {
    st.mode = mode; document.body.dataset.mode = mode;
    if (mode === 'table') { switchTab('coverage'); if (!$('#cTable').innerHTML) runCoverage(); }
    else switchTab(st.menuTab && !['play', 'coverage'].includes(st.menuTab) ? st.menuTab : 'search');
  }

  /* ---------- General ---------- */
  function switchTab(id) {
    document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === id));
    document.querySelectorAll('.tab').forEach(x => x.classList.toggle('active', x.id === 'tab-' + id));
    if (id === 'play') setTimeout(drawBed, 0);
    if (id === 'coverage' && !$('#cTable').innerHTML) runCoverage();
    if (id === 'song') renderSongTab();
  }
  function exportLayout() {
    const data = JSON.stringify(I.serializeLayout(st.layout), null, 1);
    const a = el('a', { href: URL.createObjectURL(new Blob([data], { type: 'application/json' })), download: (layoutName(st.layout) || 'layout').replace(/[^\w\-]+/g, '_') + '.json' });
    document.body.appendChild(a); a.click(); a.remove();
  }
  function importLayout(file) {
    const r = new FileReader();
    r.onload = () => {
      try { const obj = JSON.parse(r.result); const L = I.deserializeLayout(obj); st.customDefs.push(I.serializeLayout(L)); saveCustom(); st.layoutKey = 'cus:' + (st.customDefs.length - 1); fillLayoutSelect(st.layoutKey); setLayout(L); toast(t('ed.imported')); }
      catch (e) { toast(t('ed.badFile', { x: e.message })); }
    };
    r.readAsText(file);
  }
  function help() { $('#helpBox').innerHTML = AH.HELP[L10.lang] || AH.HELP.es; }

  function init() {
    if (EMBED) document.body.classList.add('embed');
    loadSettings();
    L10.onChange(() => { if (st.layout) onLangChange(); });
    loadCustom();
    applyI18n(); fillSelects(); fillLayoutSelect('def:os21');
    $('#layoutSel').addEventListener('change', e => selectLayout(e.target.value));
    $('#zoneSel').addEventListener('change', e => { st.zone = e.target.value; updateReadout(); drawBed(); });
    $('#btnStrum').addEventListener('click', strumNow);
    $('#btnDamp').addEventListener('click', () => st.audio.dampAll());
    $('#btnRelease').addEventListener('click', () => { st.pressed.clear(); renderBars(); updateReadout(); drawBed(); prLog({ type: 'press', bars: [] }); });
    $('#vol').addEventListener('input', e => st.audio.setVolume(+e.target.value));
    $('#btnTheme').addEventListener('click', () => { const r = document.documentElement; const nt = r.dataset.theme === 'light' ? 'dark' : 'light'; r.dataset.theme = nt; ls.set('autoarpa.theme', nt); drawBed(); });
    const th = ls.get('autoarpa.theme', null); if (th) document.documentElement.dataset.theme = th;
    $('#btnExport').addEventListener('click', exportLayout);
    $('#btnImport').addEventListener('click', () => $('#fileInput').click());
    $('#fileInput').addEventListener('change', e => { if (e.target.files[0]) importLayout(e.target.files[0]); e.target.value = ''; });
    document.querySelectorAll('.tabs button').forEach(b => b.addEventListener('click', () => { if (EMBED) st.menuTab = b.dataset.tab; switchTab(b.dataset.tab); }));
    const searchFromInput = () => runSearch(T.parseChord($('#qChord').value));
    $('#qGo').addEventListener('click', searchFromInput);
    $('#qChord').addEventListener('keydown', e => { if (e.key === 'Enter') searchFromInput(); });
    $('#qType').addEventListener('change', () => runSearch(T.makeChord(+$('#qRoot').value, $('#qType').value)));
    $('#qRoot').addEventListener('change', () => runSearch(T.makeChord(+$('#qRoot').value, $('#qType').value)));
    $('#qPinch').addEventListener('change', () => { if (st.lastChord) runSearch(st.lastChord); });
    $('#qMaxB').addEventListener('change', () => { if (st.lastChord) runSearch(st.lastChord); });
    $('#qBack').addEventListener('click', () => switchTab('coverage'));
    $('#cGo').addEventListener('click', runCoverage);
    $('#cPinch').addEventListener('change', runCoverage);
    $('#oGo').addEventListener('click', runOptimize);
    $('#oSheet').disabled = false; $('#oSheet').addEventListener('click', feltSheet);
    $('#aGo').addEventListener('click', runArrange);
    const applyLayout = (L, msg) => { const ser = I.serializeLayout(L); ser.name = layoutName(L) + ' *'; st.customDefs.push(ser); saveCustom(); st.layoutKey = 'cus:' + (st.customDefs.length - 1); ls.set(LS_LAST, st.layoutKey); fillLayoutSelect(st.layoutKey); setLayout(I.deserializeLayout(ser)); toast(msg); };
    $('#aApply').addEventListener('click', () => { if (st.arranged) applyLayout(st.arranged, t('arr.applied')); });
    $('#oApply').addEventListener('click', () => { if (st.proposal) { const P0 = st.proposal; st.proposal = null; applyLayout(P0, t('opt.applied')); } });
    // animación
    $('#anPlay').addEventListener('click', animToggle);
    $('#anPrev').addEventListener('click', () => { if (st.anim) { st.anim.runner.prevStep(); st.anim.last = performance.now(); animLabels(); } });
    $('#anNext').addEventListener('click', () => { if (st.anim) { st.anim.runner.nextStep(); st.anim.last = performance.now(); animLabels(); } });
    $('#anSlow').addEventListener('click', () => { if (st.anim) { st.anim.runner.changeSpeed(-1); animLabels(); } });
    $('#anFast').addEventListener('click', () => { if (st.anim) { st.anim.runner.changeSpeed(1); animLabels(); } });
    $('#anTl').addEventListener('click', () => { $('#anTimeline').classList.toggle('open'); buildTimeline(); });
    $('#anClose').addEventListener('click', () => animClose());
    // práctica
    $('#prAgain').addEventListener('click', prAgain);
    $('#prExample').addEventListener('click', () => { const p = st.practice; if (p) startAnim(p.r, p.chord); });
    $('#prClose').addEventListener('click', () => prClose());
    $('#prHints').addEventListener('change', () => { renderBars(); drawBed(); });
    // canción
    $('#sText').addEventListener('input', () => { clearTimeout(st._sp); st._sp = setTimeout(renderSongTab, 300); });
    $('#sPlay').addEventListener('click', startSong);
    $('#sSave').addEventListener('click', () => { const name = $('#sName').value.trim() || t('song.defaultName'); const l = songsLoad(); const i = l.findIndex(s => s.name === name); const it = { name, text: $('#sText').value }; if (i >= 0) l[i] = it; else l.push(it); songsSave(l); renderSongTab(); toast(t('song.saved')); });
    $('#sArrange').addEventListener('click', () => { $('#aProg').value = $('#sText').value; switchTab('optimize'); runArrange(); });
    $('#sgPrev').addEventListener('click', () => { if (st.song) songGo(st.song.i - 1); });
    $('#sgNext').addEventListener('click', () => { if (st.song) songGo(st.song.i + 1); });
    $('#sgClose').addEventListener('click', () => songClose());
    // ajustes
    $('#setLang').addEventListener('change', e => { saveSetting('lang', e.target.value); L10.setLang(e.target.value); });
    $('#setNotation').addEventListener('change', e => { saveSetting('notation', e.target.value); L10.setNotation(e.target.value); });
    $('#setStyle').addEventListener('change', e => { st.style = e.target.value; saveSetting('style', st.style); drawBed(); });
    $('#setTour').addEventListener('click', startTour);
    $('#tourNext').addEventListener('click', () => { if (tourI < TOUR.length - 1) { tourI++; showTourStep(); } else endTour(); });
    $('#tourPrev').addEventListener('click', () => { if (tourI) { tourI--; showTourStep(); } });
    $('#tourSkip').addEventListener('click', endTour);
    $('#btnEmbedClose').addEventListener('click', () => { const b = bridge(); if (b) b.close(); });
    bindBed(); bindKeys(); bindEditor(); help(); buildSettings();
    let first = 'def:os21';
    const last = ls.get(LS_LAST, null);
    if (last && (last.startsWith('def:') ? I.LAYOUT_DEFS.some(d => 'def:' + d.id === last) : st.customDefs[+last.slice(4)])) first = last;
    fillLayoutSelect(first); selectLayout(first);
    sendNativeStrings();
    AH.ui = { openMode, state: st, startAnim, startPractice, evalPractice, notifyLayout, startTour, playLastPracticeExample: () => { const pr = st.practiceRecipe; if (pr) startAnim(pr.r, pr.chord); }, setLang: l => { saveSetting('lang', l); L10.setLang(l); } };
    if (EMBED) openMode('menu');
    else if (!ls.get(LS_TOUR, null)) setTimeout(startTour, 700);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})(window);
