/* "Tu turno" y "Modo canción": evaluación de lo que tocó el usuario y preparación de una canción.
   Sin DOM. Android manda su registro de toques al WebView y recibe el resultado ya traducido. */
(function (g) {
  'use strict';
  const AH = g.AH = g.AH || {};
  const T = AH.theory, E = AH.engine;
  const tr = (k, p) => (AH.i18n ? AH.i18n.t(k, p) : k);
  const ch = s => (AH.i18n ? AH.i18n.chord(s) : s);
  const nm = s => (AH.i18n ? AH.i18n.note(s) : s);
  const lst = a => (AH.i18n ? AH.i18n.joinList(a) : a.join(', '));

  /** Datos mínimos de una receta para practicar (también viajan a Android). */
  function target(layout, r, chordName) {
    const flat = layout.rows.flat();
    const n = layout.tuning.length, mask = E.andMasks(r.bars, n);
    const a = r.range ? r.range[0] : 0, b = r.range ? r.range[1] : n - 1;
    const strum = []; for (let i = a; i <= b; i++) if (mask[i]) strum.push(i);
    return { chord: chordName, barIdx: r.bars.map(x => flat.indexOf(x)).filter(k => k >= 0), labels: r.bars.map(x => x.label), range: [a, b], strum, pinches: (r.pinches || []).slice(), full: a === 0 && b === n - 1 };
  }

  /**
   * log: [{t, type:'press', bars:[idx...]} | {t, type:'pluck', s, sounded}], en orden.
   * Devuelve {verdict:'good'|'close'|'retry'|'none', items:[{ok, text}], score}
   */
  function evaluate(layout, tgt, log) {
    const tun = layout.tuning, flat = layout.rows.flat();
    let pressed = [];
    const withBars = [], noBars = [];
    for (const e of log) {
      if (e.type === 'press') pressed = e.bars.slice().sort((x, y) => x - y);
      else if (e.type === 'pluck') (pressed.length ? withBars : noBars).push({ s: e.s, sounded: !!e.sounded, bars: pressed, t: e.t });
    }
    const items = [];
    if (!withBars.length && !noBars.length) return { verdict: 'none', items: [{ ok: false, text: tr('pr.nothing') }], score: 0 };
    const name = i => (flat[i] ? ch(flat[i].label) : '?');
    // barras: el conjunto presionado más frecuente durante el rasgueo
    let issues = 0;
    if (tgt.barIdx.length) {
      if (!withBars.length) { items.push({ ok: false, text: tr('pr.noBars') }); issues += 2; }
      else {
        const cnt = {}; withBars.forEach(p => { const k = p.bars.join(','); cnt[k] = (cnt[k] || 0) + 1; });
        const used = Object.keys(cnt).sort((x, y) => cnt[y] - cnt[x])[0].split(',').filter(Boolean).map(Number);
        const miss = tgt.barIdx.filter(i => !used.includes(i)), extra = used.filter(i => !tgt.barIdx.includes(i));
        if (!miss.length && !extra.length) items.push({ ok: true, text: tr('pr.barsOk') });
        if (miss.length) { items.push({ ok: false, text: tr('pr.barsMissing', { x: lst(miss.map(name)) }) }); issues++; }
        if (extra.length) { items.push({ ok: false, text: tr('pr.barsExtra', { x: lst(extra.map(name)) }) }); issues++; }
      }
    }
    // rasgueo: cuerdas que sonaron con barras
    const sounded = Array.from(new Set(withBars.filter(p => p.sounded).map(p => p.s))).sort((x, y) => x - y);
    if (withBars.length) {
      const missed = tgt.strum.filter(s => !sounded.includes(s));
      const outside = sounded.filter(s => s < tgt.range[0] || s > tgt.range[1]);
      const lab = arr => arr.map(s => s + 1).join(', ');
      let ok = true;
      if (missed.length && missed.length / Math.max(1, tgt.strum.length) > 0.25) { items.push({ ok: false, text: tr('pr.strumShort', { x: lab(missed) }) }); ok = false; issues++; }
      if (!tgt.full && outside.length) { items.push({ ok: false, text: tr('pr.strumExtra', { x: lab(outside) }) }); ok = false; issues++; }
      if (ok) items.push({ ok: true, text: tr('pr.strumOk') });
    }
    // pinch: cuerdas pulsadas sin barras después del rasgueo
    const lastStrumT = withBars.length ? withBars[withBars.length - 1].t : -1;
    const after = noBars.filter(p => p.t > lastStrumT).map(p => p.s);
    if (tgt.pinches.length && (withBars.length || !tgt.barIdx.length)) {
      // pulsada aparte (aislada, no dentro del rasgueo) mientras seguían presionadas las barras
      const isolated = p => !withBars.some(q => q !== p && Math.abs(q.t - p.t) < 150);
      const early = tgt.pinches.filter(s => withBars.some(p => p.s === s && isolated(p)) && !after.includes(s));
      const miss = tgt.pinches.filter(s => !after.includes(s) && !early.includes(s));
      const wrong = Array.from(new Set(after.filter(s => !tgt.pinches.includes(s))));
      const lab = s => (s + 1) + ' (' + nm(tun[s].name) + ')';
      const cap = arr => (arr.length > 6 ? arr.slice(0, 6).concat(['…']) : arr);
      if (early.length) { items.push({ ok: false, text: tr('pr.pinchEarly', { x: lst(early.map(lab)) }) }); issues++; }
      if (miss.length) { items.push({ ok: false, text: tr('pr.pinchMissing', { x: lst(miss.map(lab)) }) }); issues++; }
      if (wrong.length) { items.push({ ok: false, text: tr('pr.pinchWrong', { x: cap(wrong.map(lab)).join(', ') }) }); issues++; }
      if (!early.length && !miss.length && !wrong.length) items.push({ ok: true, text: tr('pr.pinchOk') });
    }
    // parecido de lo que sonó con el acorde objetivo
    const heard = Array.from(new Set(sounded.concat(after)));
    const chord = T.parseChord(tgt.chord);
    let S = 0;
    if (chord && heard.length) S = E.score(E.features(heard, tun, new Set(after.filter(s => !sounded.includes(s)))), chord).S;
    items.push({ ok: S >= 0.85, text: tr('pr.score', { chord: ch(tgt.chord), pct: Math.round(S * 100) }) });
    const verdict = issues === 0 && S >= 0.7 ? 'good' : (issues <= 2 && S >= 0.6 ? 'close' : 'retry');
    return { verdict, items, score: S, title: tr(verdict === 'good' ? 'pr.good' : verdict === 'close' ? 'pr.close' : 'pr.retry') };
  }

  /* ---------- Modo canción ---------- */
  /** Convierte el texto de la canción en una lista de acordes con su mejor forma (sin pinch, para tocar de corrido). */
  function resolveSong(text, layout, cache) {
    const items = [], bad = [];
    String(text || '').split(/[\s,;|]+/).filter(Boolean).forEach(tok => {
      const [name, w] = tok.split(':');
      const c = T.parseChord(name);
      if (!c) { bad.push(name); return; }
      const reps = Math.max(1, Math.min(8, Math.round(parseFloat(w) || 1)));
      const res = E.search(c, cache, { top: 6, pinches: false, maxButtons: 3 });
      const best = res[0] || null;
      const flat = layout.rows.flat();
      const it = { chord: c.name, S: best ? best.sc.S : 0, playable: !!best && best.sc.S >= 0.7, recipe: best,
        barIdx: best ? best.bars.map(b => flat.indexOf(b)).filter(k => k >= 0) : [], range: best ? best.range : null,
        how: best ? E.describe(best, layout.tuning) : '' };
      for (let k = 0; k < reps; k++) items.push(it);
    });
    return { items, bad };
  }

  AH.practice = { target, evaluate, resolveSong };
})(typeof globalThis !== 'undefined' ? globalThis : window);
