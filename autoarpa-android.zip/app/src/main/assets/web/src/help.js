/* Texto de Ayuda en los cinco idiomas. */
(function (g) {
  'use strict';
  const AH = g.AH = g.AH || {};
  AH.HELP = {
    es: `
<h3>Qué hace este programa</h3>
<p>Simula una autoarpa de 36 cuerdas y, además de tocar los acordes de cada barra, busca acordes que el layout no trae de fábrica combinando tres mecanismos físicamente reales: <b>intersección</b> (presionar 2 o 3 barras a la vez: solo suenan las cuerdas libres en todas), <b>zona de rasgueo</b> (rasguear solo una parte del encordado) y <b>pinch</b> (rasguear con barras, soltarlas y pulsar 1 o 2 cuerdas sueltas; el acorde queda arpegiado y por eso nunca puntúa 100 %).</p>
<h3>Animación paso a paso y Tu turno</h3>
<p>En la Tabla de acordes o el Buscador, cada forma de tocar trae <b>Ver animación</b>: el texto de cada paso se queda fijo, el modo paso a paso se detiene al final de cada paso y la línea de tiempo muestra cuándo se presiona y se suelta cada barra y qué hace la otra mano. <b>Tu turno</b> te pide tocarlo y revisa barras, zona y pinch.</p>
<h3>Modo canción</h3>
<p>Escribe los acordes en orden; la app marca la barra actual y la siguiente y avanza sola cuando rasgueas con las barras correctas.</p>
<h3>Porcentaje de parecido</h3>
<p>65 % de cobertura funcional (fundamental y tercera pesan 1.0, séptima 0.8, extensiones 0.6, quinta 0.4; penaliza notas ajenas y el bajo ajeno) y 35 % de similitud espectral. Mismas notas = 100 % (Exacto); ≥85 % Funcional; ≥70 % Sustituto; menos, Color.</p>
<h3>Colores de las cuerdas</h3>
<p>En el estilo Clásico, rojo marca las cuerdas Do y azul las Fa, como guía de orientación; gris son las cuerdas que el fieltro de las barras presionadas tapa. El estilo se cambia en Ajustes.</p>
<h3>Teclado (escritorio)</h3>
<p>Fila 1 de botones: <code>1…0</code> · Fila 2: <code>Q…P</code> · Fila 3: <code>A…Ñ</code> · Espacio: rasguear (o play/pausa durante un ejemplo) · Esc: apagar todo.</p>
<h3>Fieltrado y afinación</h3>
<p>Punto verde en una barra = fieltrado real documentado. Afinación cromática estándar de 36 cuerdas (F2–C6); el bajo no es cromático, por eso algunos acordes quedan con el bajo invertido.</p>`,
    en: `
<h3>What this program does</h3>
<p>It simulates a 36-string autoharp and, besides playing each bar's chord, finds chords the layout lacks by combining three physically real mechanisms: <b>intersection</b> (pressing 2 or 3 bars at once: only strings open in all of them sound), <b>strum zone</b> (strumming only part of the strings) and <b>pinch</b> (strum with bars, release them and pluck 1 or 2 open strings; the chord is arpeggiated, so it never scores 100%).</p>
<h3>Step-by-step animation and Your turn</h3>
<p>In the Chord table or Chord finder each way to play has <b>Watch animation</b>: each step's text stays on screen, step-by-step mode stops at the end of each step and the timeline shows when each bar is pressed and released and what the other hand does. <b>Your turn</b> asks you to play it and checks bars, zone and pinch.</p>
<h3>Song mode</h3>
<p>Type the chords in order; the app marks the current and next bars and moves on when you strum with the right bars.</p>
<h3>Similarity percentage</h3>
<p>65% functional coverage (root and third weigh 1.0, seventh 0.8, extensions 0.6, fifth 0.4; foreign notes and a foreign bass are penalized) and 35% spectral similarity. Same notes = 100% (Exact); ≥85% Functional; ≥70% Substitute; lower, Color.</p>
<h3>String colours</h3>
<p>In the Classic style red marks the C strings and blue the F strings as orientation guides; grey strings are covered by the felt of the pressed bars. Change the style in Settings.</p>
<h3>Keyboard (desktop)</h3>
<p>Button row 1: <code>1…0</code> · Row 2: <code>Q…P</code> · Row 3: <code>A…;</code> · Space: strum (or play/pause during an example) · Esc: mute all.</p>
<h3>Felting and tuning</h3>
<p>A green dot on a bar = documented real felting. Standard 36-string chromatic tuning (F2–C6); the bass is not chromatic, so some chords end up with an inverted bass.</p>`,
    pt: `
<h3>O que este programa faz</h3>
<p>Simula uma autoharpa de 36 cordas e, além de tocar o acorde de cada barra, encontra acordes que o layout não tem combinando três mecanismos fisicamente reais: <b>interseção</b> (pressionar 2 ou 3 barras juntas: só soam as cordas livres em todas), <b>zona de rasgueado</b> (rasguear só parte das cordas) e <b>pinch</b> (rasguear com barras, soltá-las e tocar 1 ou 2 cordas soltas; o acorde fica arpejado e por isso nunca chega a 100 %).</p>
<h3>Animação passo a passo e Sua vez</h3>
<p>Na Tabela de acordes ou no Buscador, cada forma traz <b>Ver animação</b>: o texto de cada passo fica fixo, o modo passo a passo para no fim de cada passo e a linha do tempo mostra quando cada barra é pressionada e solta e o que a outra mão faz. <b>Sua vez</b> pede que você toque e confere barras, zona e pinch.</p>
<h3>Modo música</h3>
<p>Escreva os acordes em ordem; o app marca a barra atual e a próxima e avança quando você rasgueia com as barras certas.</p>
<h3>Porcentagem de semelhança</h3>
<p>65 % de cobertura funcional (fundamental e terça pesam 1.0, sétima 0.8, extensões 0.6, quinta 0.4; penaliza notas estranhas e baixo estranho) e 35 % de semelhança espectral. Mesmas notas = 100 % (Exato); ≥85 % Funcional; ≥70 % Substituto; abaixo, Cor.</p>
<h3>Cores das cordas</h3>
<p>No estilo Clássico, vermelho marca as cordas Dó e azul as Fá, como guia; cinza são as cordas cobertas pelo feltro das barras pressionadas. O estilo muda em Ajustes.</p>
<h3>Teclado (computador)</h3>
<p>Fila 1: <code>1…0</code> · Fila 2: <code>Q…P</code> · Fila 3: <code>A…Ç</code> · Espaço: rasguear (ou play/pausa num exemplo) · Esc: abafar tudo.</p>
<h3>Feltragem e afinação</h3>
<p>Ponto verde numa barra = feltragem real documentada. Afinação cromática padrão de 36 cordas (F2–C6); o baixo não é cromático, por isso alguns acordes ficam com baixo invertido.</p>`,
    fr: `
<h3>Ce que fait ce programme</h3>
<p>Il simule une autoharpe de 36 cordes et, en plus de jouer l'accord de chaque barre, trouve des accords absents de la disposition en combinant trois mécanismes physiquement réels : <b>intersection</b> (appuyer sur 2 ou 3 barres : seules les cordes libres dans toutes sonnent), <b>zone de grattage</b> (gratter une partie des cordes) et <b>pinch</b> (gratter avec les barres, les relâcher et pincer 1 ou 2 cordes libres ; l'accord est arpégé, il n'atteint donc jamais 100 %).</p>
<h3>Animation pas à pas et À vous</h3>
<p>Dans le Tableau des accords ou la Recherche, chaque forme propose <b>Voir l'animation</b> : le texte de chaque étape reste affiché, le mode pas à pas s'arrête à la fin de chaque étape et la chronologie montre quand chaque barre est enfoncée et relâchée et ce que fait l'autre main. <b>À vous</b> vous demande de le jouer et vérifie barres, zone et pinch.</p>
<h3>Mode chanson</h3>
<p>Saisissez les accords dans l'ordre ; l'appli marque la barre actuelle et la suivante et avance quand vous grattez avec les bonnes barres.</p>
<h3>Pourcentage de ressemblance</h3>
<p>65 % de couverture fonctionnelle (fondamentale et tierce pèsent 1.0, septième 0.8, extensions 0.6, quinte 0.4 ; notes et basse étrangères pénalisées) et 35 % de ressemblance spectrale. Mêmes notes = 100 % (Exact) ; ≥85 % Fonctionnel ; ≥70 % Substitut ; en dessous, Couleur.</p>
<h3>Couleurs des cordes</h3>
<p>Dans le style Classique, le rouge marque les cordes Do et le bleu les Fa comme repères ; le gris indique les cordes couvertes par le feutre des barres enfoncées. Le style se change dans Réglages.</p>
<h3>Clavier (ordinateur)</h3>
<p>Rangée 1 : <code>1…0</code> · Rangée 2 : <code>Q…P</code> · Rangée 3 : <code>A…M</code> · Espace : gratter (ou lecture/pause pendant un exemple) · Échap : tout étouffer.</p>
<h3>Feutrage et accord</h3>
<p>Point vert sur une barre = feutrage réel documenté. Accord chromatique standard de 36 cordes (F2–C6) ; la basse n'est pas chromatique, d'où certains accords à basse renversée.</p>`,
    de: `
<h3>Was dieses Programm macht</h3>
<p>Es simuliert eine Autoharp mit 36 Saiten und findet neben den Akkorden jeder Leiste auch Akkorde, die das Layout nicht hat, mit drei physikalisch echten Mechanismen: <b>Schnittmenge</b> (2 oder 3 Leisten gleichzeitig: nur Saiten, die in allen frei sind, klingen), <b>Streichzone</b> (nur einen Teil der Saiten streichen) und <b>Pinch</b> (mit Leisten streichen, loslassen und 1 oder 2 freie Saiten zupfen; der Akkord ist arpeggiert und erreicht daher nie 100 %).</p>
<h3>Schritt-für-Schritt-Animation und Du bist dran</h3>
<p>In der Akkordtabelle oder Akkordsuche hat jede Spielweise <b>Animation ansehen</b>: Der Text jedes Schritts bleibt stehen, der Schrittmodus hält am Ende jedes Schritts an und die Zeitleiste zeigt, wann jede Leiste gedrückt und losgelassen wird und was die andere Hand tut. <b>Du bist dran</b> lässt dich spielen und prüft Leisten, Zone und Pinch.</p>
<h3>Liedmodus</h3>
<p>Gib die Akkorde der Reihe nach ein; die App markiert die aktuelle und die nächste Leiste und geht weiter, wenn du mit den richtigen Leisten streichst.</p>
<h3>Ähnlichkeit in Prozent</h3>
<p>65 % funktionale Abdeckung (Grundton und Terz 1.0, Septime 0.8, Erweiterungen 0.6, Quinte 0.4; fremde Töne und fremder Bass werden abgezogen) und 35 % spektrale Ähnlichkeit. Gleiche Töne = 100 % (Exakt); ≥85 % Funktional; ≥70 % Ersatz; darunter Farbe.</p>
<h3>Saitenfarben</h3>
<p>Im klassischen Stil markiert Rot die C-Saiten und Blau die F-Saiten zur Orientierung; grau sind Saiten, die der Filz der gedrückten Leisten abdeckt. Der Stil wird in den Einstellungen gewählt.</p>
<h3>Tastatur (Computer)</h3>
<p>Tastenreihe 1: <code>1…0</code> · Reihe 2: <code>Q…P</code> · Reihe 3: <code>A…Ö</code> · Leertaste: streichen (oder Start/Pause im Beispiel) · Esc: alles abdämpfen.</p>
<h3>Befilzung und Stimmung</h3>
<p>Grüner Punkt auf einer Leiste = dokumentierte echte Befilzung. Chromatische Standardstimmung mit 36 Saiten (F2–C6); der Bass ist nicht chromatisch, daher haben manche Akkorde einen umgekehrten Bass.</p>`
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
